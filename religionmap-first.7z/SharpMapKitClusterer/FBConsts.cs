﻿//
//  FBConsts.cs
//
//  Created by Filip Bec on 06/01/14.
//  Translated to C# by Dnote Software (www.dnote.nl) on Jan 4th, 2015
//  Copyright (c) 2014 Infinum Ltd. All rights reserved.
//
using System;

namespace SharpMapKitClusterer
{
    public class FBConsts
    {
        public const int kNodeCapacity = 8;
    }
}

