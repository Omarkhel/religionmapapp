﻿using Client;
using Client.Models.Json;
using Foundation;
using I18NPortable;
using relig_ios.Helpers;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios
{
    public partial class ConfessionViewController : UIViewController
    {
        List<Confess> confess { get; set; }

        public ConfessionViewController(IntPtr handle) : base(handle)
        {
        }


        void Go(Confess data)
        {
            var hKController = this.Storyboard.InstantiateViewController("ConfItemController") as ConfItemController;
            hKController.Data = data;
            this.NavigationController.PushViewController(hKController, true);
        }



        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            this.NavigationController.SetNavigationBarHidden(false, false);

            var app = new App();
            I18N.Current.Locale = Settings.Lang;
            NavigationController.TopViewController.NavigationItem.Title = "str_cofesss".Translate();

            btnHris.SetTitle("str_hrist".Translate(), UIControlState.Normal);
            btnHris.TouchDown += (s, e) =>
            {
                Go(confess[1]);
            };

            btnIslam.SetTitle("str_islam".Translate(), UIControlState.Normal);
            btnIslam.TouchDown += (s, e) =>
            {
                Go(confess[0]);
            };
            btnBud.SetTitle("str_b".Translate(), UIControlState.Normal);
            btnBud.TouchDown += (s, e) =>
            {
                Go(confess[2]);
            };
            btnIud.SetTitle("str_iud".Translate(), UIControlState.Normal);
            btnIud.TouchDown += (s, e) =>
            {
                Go(confess[3]);
            };
            btnNew.SetTitle("str_newr".Translate(), UIControlState.Normal);
            btnNew.TouchDown += (s, e) =>
            {
                Go(confess[4]); ;
            };

            var ui = new UIHelper();




            LoadingOverlay loadPop;


            var bounds = UIScreen.MainScreen.Bounds;

            loadPop = new LoadingOverlay(bounds);
            View.Add(loadPop);
            var logic = new Logic();
            confess = await logic.GetConfessions(Settings.Lang);
            var subconfess = await logic.GetSubConfessions(Settings.Lang);

            loadPop.Hide();

            if (subconfess == null) return;

            foreach (var item in subconfess)
            {
                if (item.Protest == 0)
                {
                    var btn = ui.Button(0, item.Name);
                    btn.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                    btn.TouchDown += (s, e) =>
                     {
                         Go(new Confess { Image = item.Image, Name = item.Name, Short_text = item.Short_text, Full_text = item.Full_text });
                     };
                    vHris.AddArrangedSubview(btn);
                }

                if (item.Protest == 1)
                {
                    var btn = ui.Button(0, item.Name);
                    btn.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
                    btn.TouchDown += (s, e) =>
                    {
                        Go(new Confess { Image = item.Image, Name = item.Name, Short_text = item.Short_text, Full_text = item.Full_text });

                    };
                    vNew.AddArrangedSubview(btn);
                }
            }

        }
    }
}