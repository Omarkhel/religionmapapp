﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace relig_ios
{
    [Register ("MenuController")]
    partial class MenuController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnAbout { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnConfes { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnFaq { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnFeedBack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnMissioner { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnNews { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnRelig { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSetting { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblDescription { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblDescription2 { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnAbout != null) {
                btnAbout.Dispose ();
                btnAbout = null;
            }

            if (btnConfes != null) {
                btnConfes.Dispose ();
                btnConfes = null;
            }

            if (btnFaq != null) {
                btnFaq.Dispose ();
                btnFaq = null;
            }

            if (btnFeedBack != null) {
                btnFeedBack.Dispose ();
                btnFeedBack = null;
            }

            if (btnMissioner != null) {
                btnMissioner.Dispose ();
                btnMissioner = null;
            }

            if (btnNews != null) {
                btnNews.Dispose ();
                btnNews = null;
            }

            if (btnRelig != null) {
                btnRelig.Dispose ();
                btnRelig = null;
            }

            if (btnSetting != null) {
                btnSetting.Dispose ();
                btnSetting = null;
            }

            if (lblDescription != null) {
                lblDescription.Dispose ();
                lblDescription = null;
            }

            if (lblDescription2 != null) {
                lblDescription2.Dispose ();
                lblDescription2 = null;
            }
        }
    }
}