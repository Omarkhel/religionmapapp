﻿using Client;
using Client.Models;
using Foundation;
using System;
using UIKit;

namespace relig_ios
{
    public partial class SettingCell : UITableViewCell
    {
        public SettingCell (IntPtr handle) : base (handle)
        {
        }

        internal void UpdateCell(LangModel Item)
        {
            Title.Text = Item.Title;

            if (Settings.Lang == Item.Lng)
            {
                image.Image = UIImage.FromBundle("ic_ok_1.png");
            }

        
        }
    }
}