﻿using Client;
using Foundation;
using I18NPortable;
using relig_ios.Helpers;
using System;
using UIKit;

namespace relig_ios
{
    public partial class WebController : UIViewController
    {
        public WebController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            var app = new App();
            I18N.Current.Locale = Settings.Lang;

            this.NavigationController.SetNavigationBarHidden(false, false);
            NavigationController.TopViewController.NavigationItem.Title = "str_missioner".Translate();

            var url = "http://religionmap.kz/ru/pages/missioners";
            web.LoadRequest(new NSUrlRequest(new NSUrl(url)));

            LoadingOverlay loadPop;


            var bounds = UIScreen.MainScreen.Bounds;

            loadPop = new LoadingOverlay(bounds);
            View.Add(loadPop);

            web.LoadFinished += (sender, e) => {
                loadPop.Hide();
            };


        }
    }
}