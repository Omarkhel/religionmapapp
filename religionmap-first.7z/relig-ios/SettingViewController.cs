﻿using Client;
using Client.Models;
using I18NPortable;
using relig_ios.Helpers;
using relig_ios.Table;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios
{
    public partial class SettingViewController : UIViewController
    {
        public SettingViewController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);

            var app = new App();
            I18N.Current.Locale = Settings.Lang;

            this.NavigationController.SetNavigationBarHidden(false, false);
            NavigationController.TopViewController.NavigationItem.Title = "str_select_lang".Translate();

            //    Lang.Text = "str_lang".Translate();
            //    var list = new List<LangModel> {
            //    new LangModel{ Title = "str_rus".Translate(),Lng = "ru" },
            //    new LangModel{ Title = "str_lan_kaz".Translate(),Lng = "kz" }
            //};
            //    var pickerModel = new SettingModel(Lang, list);


            //    picLang.Model = pickerModel;
            //    picLang.Select(1, 0, false);


            var list = new List<LangModel>
            {
                new LangModel {Title = "str_lan_kaz".Translate(),Lng = "kz" },
                new LangModel {Title = "str_rus".Translate(),Lng = "ru" }
            };

            SettingTable.Source = new SettingTableSource(list);

            SettingTableSource.RowClicked += (s, e) =>
             {
                 var item = s as LangModel;
                 Settings.Lang = item.Lng;
                 AppDelegate.refr();
             };

        }
    }
}