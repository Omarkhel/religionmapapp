﻿using Client;
using Client.Models;
using Client.Models.Json;
using Foundation;
using I18NPortable;
using System;
using System.Collections.Generic;
using System.Linq;
using UIKit;

namespace relig_ios
{
    public partial class FilterViewController : UIViewController, IUIPopoverPresentationControllerDelegate, IUIAdaptivePresentationControllerDelegate
    {
        public event EventHandler SearchClicked = delegate { };
        public event EventHandler OnMapClicked = delegate { };

        Search data = new Search
        {
            Confession = new Confess { Id = -1 },
            Region = new Region { Id = -1 },
            Type = new TypeConstruction { Id = -1 }
        };


        public FilterViewController(IntPtr handle) : base(handle)
        {
            ModalPresentationStyle = UIModalPresentationStyle.Popover;
            PopoverPresentationController.Delegate = this;

            var width = UIScreen.MainScreen.Bounds.Size.Width;
            var height = UIScreen.MainScreen.Bounds.Size.Height;
            var newh = height / 2;

            PreferredContentSize = new CoreGraphics.CGSize(350, 300);
        }


        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            //var app = new App();
            //I18N.Current.Locale = Settings.Lang;
            //string space = "                                    ";
            //lblConfes.Text = "str_confession".Translate();
            //lblType.Text = "str_type".Translate();
            //lblRegion.Text = "str_area".Translate();
            //btnConfes.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);

            //btnType.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);
            //btnRegion.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);
            //btnConfes.SemanticContentAttribute = UISemanticContentAttribute.ForceRightToLeft;
            //btnType.SemanticContentAttribute = UISemanticContentAttribute.ForceRightToLeft;
            //btnRegion.SemanticContentAttribute = UISemanticContentAttribute.ForceRightToLeft;

            //btnSearch.BackgroundColor = Colors.ColorGrenDark;
            //btnSearch.SetTitle("str_find".Translate().ToUpper() + space, UIControlState.Normal);

            //btnOnMap.BackgroundColor = Colors.ColorPrimary;
            //btnOnMap.SetTitle("str_show_on_map".Translate().ToUpper() + space, UIControlState.Normal);

            //Filters filters = null;

            //var logic = new Logic();

            //if (filters == null)
            //    filters = await logic.GetFilters(Settings.Lang);

            //btnConfes.TouchDown += (s, e) =>
            // {
            //     if (filters != null)
            //     {
            //         var list = filters.Confess.Select(c =>
            //    new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

            //         var array = filters.Confess.Select(c => c.Name).ToArray();
            //         UIActionSheet option;

            //         option = new UIActionSheet("str_confession".Translate(), null, null, null, array);

            //         option.ShowInView(View);

            //         option.Clicked += (btn_sender, args) =>

            //         {

            //             var ind = Convert.ToInt32(args.ButtonIndex);

            //             btnConfes.SetTitle(list[ind].Name, UIControlState.Normal);

            //             data.Confession = new Confess
            //             {
            //                 Id = list[ind].Id,
            //                 Name = list[ind].Name,
            //                 Name_kz = list[ind].Name_Kz
            //             };

            //         };
            //     }
            // };

            //btnType.TouchDown += (s, e) =>
            //{
            //    if (filters != null)
            //    {
            //        var list = filters.Type.Select(c =>
            //   new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

            //        var array = filters.Type.Select(c => c.Name).ToArray();
            //        UIActionSheet option;

            //        option = new UIActionSheet("str_confession".Translate(), null, null, null, array);

            //        option.ShowInView(View);

            //        option.Clicked += (btn_sender, args) =>

            //        {

            //            var ind = Convert.ToInt32(args.ButtonIndex);

            //            btnType.SetTitle(list[ind].Name, UIControlState.Normal);

            //            data.Type = new TypeConstruction
            //            {
            //                Id = list[ind].Id,
            //                Name = list[ind].Name,
            //                Name_kz = list[ind].Name_Kz
            //            };

            //        };
            //    }
            //};


            //btnRegion.TouchDown += (s, e) =>
            //{
            //    if (filters != null)
            //    {
            //        var list = filters.Region.Select(c =>
            //   new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

            //        var array = filters.Region.Select(c => c.Name).ToArray();
            //        UIActionSheet option;

            //        option = new UIActionSheet("str_confession".Translate(), null, null, null, array);

            //        option.ShowInView(View);

            //        option.Clicked += (btn_sender, args) =>

            //        {

            //            var ind = Convert.ToInt32(args.ButtonIndex);

            //            btnRegion.SetTitle(list[ind].Name, UIControlState.Normal);

            //            data.Region = new Region
            //            {
            //                Id = list[ind].Id,
            //                Name = list[ind].Name,
            //                Name_kz = list[ind].Name_Kz
            //            };

            //        };
            //    }
            //};
            //btnSearch.TouchDown += (s, e) =>
            //{
            //    SearchClicked(data, null);
            //};

            //btnOnMap.TouchDown += (s, e) =>
            //{
            //    OnMapClicked(data, null);
            //};

        }

        public override bool ShouldAutorotateToInterfaceOrientation(UIInterfaceOrientation toInterfaceOrientation)
        {
            return true;
        }

        [Export("adaptivePresentationStyleForPresentationController:traitCollection:")]
        public UIModalPresentationStyle GetAdaptivePresentationStyle(UIPresentationController controller, UITraitCollection traitCollection)
        {
            return UIModalPresentationStyle.None;
        }
    }
}