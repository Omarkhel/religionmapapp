﻿using Client;
using I18NPortable;
using System;
using UIKit;

namespace relig_ios
{
    partial class MenuController : BaseController
    {
        public MenuController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);

        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            Translate();

            btnRelig.TouchUpInside += (o, e) => {
                var contentController = (MapController)Storyboard.InstantiateViewController("MapController");

                if (NavController.TopViewController as MapController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };

            btnMissioner.TouchUpInside += (o, e) => {
                var contentController = (WebController)Storyboard.InstantiateViewController("WebController");

                if (NavController.TopViewController as WebController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };

            btnAbout.TouchUpInside += (o, e) => {
                var contentController = (AboutController)Storyboard.InstantiateViewController("AboutController");

                if (NavController.TopViewController as AboutController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };

            btnNews.TouchUpInside += (o, e) => {
                var contentController = (NewsTableController)Storyboard.InstantiateViewController("NewsTableController");

                if (NavController.TopViewController as NewsTableController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };

            btnFaq.TouchUpInside += (o, e) => {
                var contentController = (FAQTableViewController)Storyboard.InstantiateViewController("FAQTableViewController");

                if (NavController.TopViewController as FAQTableViewController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };

            btnConfes.TouchUpInside += (o, e) => {
                var contentController = (ConfessionViewController)Storyboard.InstantiateViewController("ConfessionViewController");

                if (NavController.TopViewController as ConfessionViewController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };

            btnSetting.TouchUpInside += (o, e) => {
                var contentController = (SettingViewController)Storyboard.InstantiateViewController("SettingViewController");

                if (NavController.TopViewController as SettingViewController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };

            btnFeedBack.TouchUpInside += (o, e) => {
                var contentController = (FeedBackViewController)Storyboard.InstantiateViewController("FeedBackViewController");

                if (NavController.TopViewController as FeedBackViewController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };
        }


        public static void reload()
        {
        
        }

        public void Translate()
        {
            var app = new App();
            I18N.Current.Locale = Settings.Lang;

            btnRelig.AddLinearGradientToView(Colors.ColorGrenDark, Colors.ColorPrimary);


            var ab = "str_about".Translate();

            lblDescription.Text = "str_description".Translate();
            lblDescription2.Text = "str_region".Translate();

            btnRelig.SetTitle("       " + "str_relig_socium".Translate(), UIControlState.Normal);
            btnRelig.VerticalAlignment = UIControlContentVerticalAlignment.Center;
          

            btnAbout.SetTitle(" " + "str_about".Translate(), UIControlState.Normal);
            btnAbout.SetTitleColor(Colors.ColorText, UIControlState.Normal);

            btnNews.SetTitle(" " + "str_news".Translate(), UIControlState.Normal);
            btnNews.SetTitleColor(Colors.ColorText, UIControlState.Normal);

            btnMissioner.SetTitle(" " + "str_missioner".Translate(), UIControlState.Normal);
            btnMissioner.SetTitleColor(Colors.ColorText, UIControlState.Normal);

            btnFaq.SetTitleColor(Colors.ColorText, UIControlState.Normal);

            btnSetting.SetTitle(" " + "str_setting".Translate(), UIControlState.Normal);
            btnSetting.SetTitleColor(Colors.ColorText, UIControlState.Normal);

            btnFeedBack.SetTitle(" " + "str_bid".Translate(), UIControlState.Normal);
            btnFeedBack.SetTitleColor(Colors.ColorPrimary, UIControlState.Normal);

            btnConfes.SetTitle(" " + "str_cofesss".Translate(), UIControlState.Normal);

            btnConfes.SetTitleColor(Colors.ColorText, UIControlState.Normal);


        }
    }
}