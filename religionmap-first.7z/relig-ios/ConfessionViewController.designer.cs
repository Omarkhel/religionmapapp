﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace relig_ios
{
    [Register ("ConfessionViewController")]
    partial class ConfessionViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnBud { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnHris { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnIslam { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnIud { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnNew { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIStackView vHris { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIStackView vNew { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnBud != null) {
                btnBud.Dispose ();
                btnBud = null;
            }

            if (btnHris != null) {
                btnHris.Dispose ();
                btnHris = null;
            }

            if (btnIslam != null) {
                btnIslam.Dispose ();
                btnIslam = null;
            }

            if (btnIud != null) {
                btnIud.Dispose ();
                btnIud = null;
            }

            if (btnNew != null) {
                btnNew.Dispose ();
                btnNew = null;
            }

            if (vHris != null) {
                vHris.Dispose ();
                vHris = null;
            }

            if (vNew != null) {
                vNew.Dispose ();
                vNew = null;
            }
        }
    }
}