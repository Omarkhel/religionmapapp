﻿using Client;
using Client.Helper;
using Client.Models.Json;
using CoreGraphics;
using Foundation;
using I18NPortable;
using SDWebImage;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios
{
    public partial class NewsItemController : UIViewController
    {
        public News News { get; set; }





        public NewsItemController(IntPtr handle) : base(handle)
        {


        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();



            var height = UIScreen.MainScreen.Bounds.Size.Height;
            var width = UIScreen.MainScreen.Bounds.Size.Width;

            if (News == null) return;


            var image = new UIImageView();
            image.Frame = new CGRect(0, 0, width, 200);

            try
            {
                var uri = new Uri($"http://religionmap.kz{News.Image}");
                var nsurl = new NSUrl(uri.GetComponents(UriComponents.HttpRequestUrl, UriFormat.UriEscaped));

                image.SetImage(
                    url: nsurl,
                    placeholder: UIImage.FromBundle("placeholder.png"),
                    options: SDWebImageOptions.RefreshCached
                );
            }
            catch (Exception ex)
            {
                image.Image = UIImage.FromBundle("placeholder.png");
            }
           
      
    
            var text = HtmlClean.GetText(News.Detail_text);

            var label = new UILabel();
            label.TextColor = Colors.ColorText;
            label.Text = text;
            label.Lines = 0;

            label.Frame = new CGRect(5, 200, width - 5, height);

            label.SizeToFit();
            label.LayoutIfNeeded();
            label.Font.WithSize(12);



            var date = new UILabel();
            date.TextColor = Colors.ColorText;
            date.TextAlignment = UITextAlignment.Center;
            date.Text = "str_added".Translate() + " " + News.Date;
            date.Lines = 0;

            date.Frame = new CGRect(5, label.Frame.Height + 200, width - 5, 30);

            label.Font.WithSize(14);

            var scrollView = new UIScrollView
            {
                Frame = new CGRect(0, 0, width, height),
                ContentSize = new CGSize(width, label.Frame.Height + 230),
                BackgroundColor = UIColor.White,
                AutoresizingMask = UIViewAutoresizing.FlexibleHeight
            };

            scrollView.AddSubview(image);
            scrollView.AddSubview(label);
            scrollView.AddSubview(date);
            View.AddSubview(scrollView);


            if (News.Detail_text.Contains("https://www.youtube.com"))
            {
                UIAlertView alert = new UIAlertView()
                {
                    Title = "",
                    Message = "str_open_video".Translate()
                };
                alert.AddButton("str_yes".Translate());
                alert.AddButton("str_no".Translate());
                alert.Clicked += (s, e) =>
                {
                   switch(e.ButtonIndex)
                    {
                        case 0:
                            UIApplication.SharedApplication.OpenUrl(new NSUrl(News.Detail_text));
                            break;

                        case 1:

                            break;
                    }
                };
                alert.Show();
            }
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            this.NavigationController.SetNavigationBarHidden(false, false);

            var app = new App();
            I18N.Current.Locale = Settings.Lang;
            //NavigationController.TopViewController.NavigationItem.Title = "str_news".Translate();
        }
    }
}