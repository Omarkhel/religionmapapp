﻿using Client;
using Foundation;
using I18NPortable;
using System;
using UIKit;

namespace relig_ios
{
    public partial class WelcomeController : BaseController
    {
        public WelcomeController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);

            NavigationController.SetNavigationBarHidden(true, true);
            btnNext.Hidden = true;

            if (!Settings.FirstStart)
            {
                var hKController = this.Storyboard.InstantiateViewController("MapController") as MapController;

                this.NavigationController.PushViewController(hKController, true);
            }
            else
            {

                var app = new App();
                I18N.Current.Locale = Settings.Lang;


                lblReligionmap.Text = "RELIGIONMAP";
                blW1.Text = "str_welcome_1".Translate().ToUpper();
                lblw2.Text = "str_welcome_2".Translate().ToUpper();
                lblDes.Text = "str_app_description".Translate();
                btnNext.SetTitle("str_next".Translate(), UIControlState.Normal);
                btnNext.Layer.BorderWidth = 1;
                btnNext.Layer.BorderColor = Colors.BtnGreen.CGColor;
                btnNext.SetTitleColor(Colors.BtnGreen, UIControlState.Normal);
                btnNext.TintColor = Colors.BtnGreen;
                btnNext.SemanticContentAttribute = UISemanticContentAttribute.ForceRightToLeft;
                btnNext.Hidden = false;

            }
        }
    }
}