﻿using Client.Helper;
using Client.Models.Json;
using Foundation;
using SDWebImage;
using System;
using UIKit;

namespace relig_ios
{
    public partial class ConfItemController : UIViewController
    {
        public Confess Data { get; set; }
        public ConfItemController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            NavigationController.TopViewController.NavigationItem.Title = Data.Name;

            lblText.Text = Data.Name;
            lblDesc.Text = HtmlClean.GetText(Data.Full_text);

            try
            {
                var uri = new Uri($"http://religionmap.kz{Data.Image}");
                var nsurl = new NSUrl(uri.GetComponents(UriComponents.HttpRequestUrl, UriFormat.UriEscaped));

                img.SetImage(
                    url: nsurl,
                    placeholder: UIImage.FromBundle("placeholder.png"),
                    options: SDWebImageOptions.RefreshCached
                );
            }
            catch (Exception ex)
            {
                img.Image = UIImage.FromBundle("placeholder.png");
            }

            scroll.DirectionalLockEnabled = true;
            scroll.AlwaysBounceHorizontal = true;
        }
    }
}