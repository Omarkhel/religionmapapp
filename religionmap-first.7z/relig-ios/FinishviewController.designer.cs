﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace relig_ios
{
    [Register ("FinishviewController")]
    partial class FinishviewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnFinish { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblfinish { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnFinish != null) {
                btnFinish.Dispose ();
                btnFinish = null;
            }

            if (lblfinish != null) {
                lblfinish.Dispose ();
                lblfinish = null;
            }
        }
    }
}