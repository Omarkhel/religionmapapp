﻿using Client;
using Client.Models.Json;
using relig_ios.Helpers;
using relig_ios.Table;
using System;
using UIKit;

namespace relig_ios
{
    public partial class FAQTableViewController : UITableViewController
    {
        public FAQTableViewController(IntPtr handle) : base(handle)
        {
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();
            LoadingOverlay loadPop;

            this.NavigationController.SetNavigationBarHidden(false, false);
            NavigationController.TopViewController.NavigationItem.Title = "FAQ";


            var bounds = UIScreen.MainScreen.Bounds;

            loadPop = new LoadingOverlay(bounds);
            View.Add(loadPop);


            var logic = new Logic();
            var list = await logic.GetFaqList(Settings.Lang);
            if (list != null)
            {
                TableFaq.Source = new FaqTableViewSourse(list);
            }


            FaqTableViewSourse.RowClicked += (object sender, EventArgs e) =>
            {
                var item = sender as Faq;

                var hKController = this.Storyboard.InstantiateViewController("FAQItemController") as FAQItemController;
                hKController.FAQ = item;
                if (NavigationController != null)
                    this.NavigationController.PushViewController(hKController, true);
            };
            TableFaq.EstimatedRowHeight = 40f;
            loadPop.Hide();
        }
    }


}