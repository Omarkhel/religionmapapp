﻿using Client.Models.Json.Models;
using Foundation;
using SDWebImage;
using System;
using UIKit;

namespace relig_ios
{
    public partial class LocCell : UITableViewCell
    {
        public LocCell (IntPtr handle) : base (handle)
        {
        }

        internal void UpdateCell(Loc loc)
        {
            lblName.Text = loc.Name;

            try
            {
                var uri = new Uri($"http://religionmap.kz{loc.Image}");
                var nsurl = new NSUrl(uri.GetComponents(UriComponents.HttpRequestUrl, UriFormat.UriEscaped));

                image.SetImage(
                    url: nsurl,
                    placeholder: UIImage.FromBundle("placeholder.png"),
                    options: SDWebImageOptions.RefreshCached
                );
            }
            catch (Exception ex)
            {
                image.Image = UIImage.FromBundle("placeholder.png");
            }

        }
    }
}