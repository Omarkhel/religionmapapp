﻿using Client;
using Client.Models.Json.Models;
using Foundation;
using I18NPortable;
using MapKit;
using relig_ios.Helpers;
using SDWebImage;
using System;
using UIKit;

namespace relig_ios
{
    public partial class ConfessinItemViewController : UIViewController
    {
        public Loc Data { get; set; }
        public ConfessinItemViewController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            btnRuk.TouchDown += (s, e) =>
            {
                var hKController = this.Storyboard.InstantiateViewController("UserViewController") as UserViewController;
                hKController.Data = Data;
                this.NavigationController.PushViewController(hKController, true);
            };
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            this.NavigationController.SetNavigationBarHidden(false, false);
            NavigationController.TopViewController.NavigationItem.Title = Data.Confession;


            var app = new App();
            I18N.Current.Locale = Settings.Lang;
            lblRuk.Text = "str_leaders".Translate();

            btnRoute.SetTitle("str_route".Translate(), UIControlState.Normal);


            lblDescription.BackgroundColor = Colors.ColorPrimary;
            lblDescription.Text = Data.Name;
            btnAddres.SetTitle(Data.Address, UIControlState.Normal);
            lblEmail.Text = Data.email;
            lblPhone.Text = Data.phone;


            if (Data.People.Count > 0)
            {
                btnRuk.SetTitle(Data.People[0].Name, UIControlState.Normal);
            }



            btnRoute.TouchDown += (s, e) =>
            {
                try
                {
                    string url = $"http://maps.apple.com/?daddr={Data.Map}";
                    url = url.Replace(" ", "%20");
                    if (UIApplication.SharedApplication.CanOpenUrl(new NSUrl(url)))
                    {
                        UIApplication.SharedApplication.OpenUrl(new NSUrl(url));
                    }
                    else
                    {
                        new UIAlertView("Error", "Maps is not supported on this device", null, "Ok").Show();
                    }

                    //var arr = Data.Map.Split(',');
                    //var coordinate = new CoreLocation.CLLocationCoordinate2D(Convert.ToDouble(arr[0]), Convert.ToDouble(arr[1]));
                    //var address = new MKPlacemarkAddress();
                    //var mapPlcae = new MKPlacemark(coordinate, address);
                    //var mapItem = new MKMapItem(mapPlcae);
                    //mapItem.Name = Data.Name;
                    //mapItem.OpenInMaps(null);
                }
                catch (Exception ex)
                {

                    new UIAlertView("str_map_error".Translate(), "", null, "OK", null).Show();
                }
            };

            btnAddres.TouchDown += (s, e) =>
        {
            var hKController = this.Storyboard.InstantiateViewController("MapController") as MapController;
            hKController.Data = Data;
            this.NavigationController.PushViewController(hKController, true);
        };




            imgConf.Image = UIImage.FromBundle(GetIcon.Get(Data.Confess_id));

            try
            {
                var uri = new Uri("http://religionmap.kz/" + Data.Image);
                var nsurl = new NSUrl(uri.GetComponents(UriComponents.HttpRequestUrl, UriFormat.UriEscaped));

                image.SetImage(url: nsurl,
               placeholder: UIImage.FromBundle("placeholder.png"),
               options: SDWebImageOptions.RefreshCached
           );

            }
            catch (Exception) { }

        }
    }
}