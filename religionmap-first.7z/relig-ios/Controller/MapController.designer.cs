﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace relig_ios
{
    [Register ("MapController")]
    partial class MapController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView bottomIconPanel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCompass { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnConfes { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnFeedBack { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnFilter { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnFloatMenu { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnHris { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnIslam { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnIud { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnMinus { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnNav { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnOnMap { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnOtherRelig { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnPlus { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnRegion { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnReset { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSearch { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnShowBottomPanel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnType { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblConfes { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblFinded { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblHris { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblIslam { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblIud { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblOtherRelig { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblRegion { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblType { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        MapKit.MKMapView map { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISearchBar searchBar { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISearchBar searchBarBottom { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIStackView searchTopBar { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIStackView ss { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tableLoc { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView tableSearch { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewFilter { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView viewFinded { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (bottomIconPanel != null) {
                bottomIconPanel.Dispose ();
                bottomIconPanel = null;
            }

            if (btnCompass != null) {
                btnCompass.Dispose ();
                btnCompass = null;
            }

            if (btnConfes != null) {
                btnConfes.Dispose ();
                btnConfes = null;
            }

            if (btnFeedBack != null) {
                btnFeedBack.Dispose ();
                btnFeedBack = null;
            }

            if (btnFilter != null) {
                btnFilter.Dispose ();
                btnFilter = null;
            }

            if (btnFloatMenu != null) {
                btnFloatMenu.Dispose ();
                btnFloatMenu = null;
            }

            if (btnHris != null) {
                btnHris.Dispose ();
                btnHris = null;
            }

            if (btnIslam != null) {
                btnIslam.Dispose ();
                btnIslam = null;
            }

            if (btnIud != null) {
                btnIud.Dispose ();
                btnIud = null;
            }

            if (btnMinus != null) {
                btnMinus.Dispose ();
                btnMinus = null;
            }

            if (btnNav != null) {
                btnNav.Dispose ();
                btnNav = null;
            }

            if (btnOnMap != null) {
                btnOnMap.Dispose ();
                btnOnMap = null;
            }

            if (btnOtherRelig != null) {
                btnOtherRelig.Dispose ();
                btnOtherRelig = null;
            }

            if (btnPlus != null) {
                btnPlus.Dispose ();
                btnPlus = null;
            }

            if (btnRegion != null) {
                btnRegion.Dispose ();
                btnRegion = null;
            }

            if (btnReset != null) {
                btnReset.Dispose ();
                btnReset = null;
            }

            if (btnSearch != null) {
                btnSearch.Dispose ();
                btnSearch = null;
            }

            if (btnShowBottomPanel != null) {
                btnShowBottomPanel.Dispose ();
                btnShowBottomPanel = null;
            }

            if (btnType != null) {
                btnType.Dispose ();
                btnType = null;
            }

            if (lblConfes != null) {
                lblConfes.Dispose ();
                lblConfes = null;
            }

            if (lblFinded != null) {
                lblFinded.Dispose ();
                lblFinded = null;
            }

            if (lblHris != null) {
                lblHris.Dispose ();
                lblHris = null;
            }

            if (lblIslam != null) {
                lblIslam.Dispose ();
                lblIslam = null;
            }

            if (lblIud != null) {
                lblIud.Dispose ();
                lblIud = null;
            }

            if (lblOtherRelig != null) {
                lblOtherRelig.Dispose ();
                lblOtherRelig = null;
            }

            if (lblRegion != null) {
                lblRegion.Dispose ();
                lblRegion = null;
            }

            if (lblType != null) {
                lblType.Dispose ();
                lblType = null;
            }

            if (map != null) {
                map.Dispose ();
                map = null;
            }

            if (searchBar != null) {
                searchBar.Dispose ();
                searchBar = null;
            }

            if (searchBarBottom != null) {
                searchBarBottom.Dispose ();
                searchBarBottom = null;
            }

            if (searchTopBar != null) {
                searchTopBar.Dispose ();
                searchTopBar = null;
            }

            if (ss != null) {
                ss.Dispose ();
                ss = null;
            }

            if (tableLoc != null) {
                tableLoc.Dispose ();
                tableLoc = null;
            }

            if (tableSearch != null) {
                tableSearch.Dispose ();
                tableSearch = null;
            }

            if (viewFilter != null) {
                viewFilter.Dispose ();
                viewFilter = null;
            }

            if (viewFinded != null) {
                viewFinded.Dispose ();
                viewFinded = null;
            }
        }
    }
}