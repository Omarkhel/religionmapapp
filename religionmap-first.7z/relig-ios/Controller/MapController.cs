﻿using Client;
using Client.Models;
using Client.Models.Json;
using Client.Models.Json.Models;
using CoreGraphics;
using CoreLocation;
using Foundation;
using I18NPortable;
using MapKit;
using relig_ios.Helpers;
using relig_ios.Table;
using SDWebImage;
using SharpMapKitClusterer;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using UIKit;

namespace relig_ios
{
    partial class MapController : BaseController
    {
        public Loc Data { get; set; }

        public bool isSearched { get; set; } = false;
        public MapController(IntPtr handle) : base(handle)
        {
        }
        FBClusteringManager clusteringManager { get; set; }
        private List<Loc> LocationList { get; set; }
        CLLocationManager locationManager = new CLLocationManager();
        Filters filters = null;

        UIView alertBackground;

        private const string kClusterAnnotationId = "REUSABLE_CLUSTER_ANNOTATION_ID";
        private const string kPinAnnotationId = "REUSABLE_PIN_ANNOTATION_ID";
        private const int kTagClusterLabel = 1;


        static int CalculateZoomLevel(MKMapView mapView)
        {
            var zoomLevel = 20; // max zoom level
            var zoomScale = mapView.VisibleMapRect.Size.Width / mapView.Bounds.Size.Width;
            double zoomExponent = Math.Log(zoomScale);
            zoomLevel = (int)(20 - Math.Ceiling(zoomExponent));

            return zoomLevel;
        }

        protected void OnMapTapped(UIGestureRecognizer sender)
        {
            var d = "";
            //CLLocationCoordinate2D tappedLocationCoord = mapView.ConvertPoint(sender.LocationInView(mapView), mapView);
            //... add code here to add MKAnnotation to map using 'tappedLocationCoord' as annotation co - ordinate...
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();
            var logic = new Logic();
            tableLoc.Hidden = true;

            LoadingOverlay loadPop;


            map.ShowsUserLocation = true;


            Design();

          

            NavButtonHide(true);

            Search data = new Search
            {
                Confession = new Confess { Id = -1 },
                Region = new Region { Id = -1 },
                Type = new TypeConstruction { Id = -1 }
            };



            #region BTN

            btnNav.TouchUpInside += BtnNav_TouchUpInside;
            btnFloatMenu.TouchUpInside += BtnNav_TouchUpInside;



           // if (filters == null)
                filters = await logic.GetFilters(Settings.Lang);

            btnConfes.TouchDown += (ss, ee) =>
            {
                if (filters != null)
                {
                    var list = filters.Confess.Select(c =>
               new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

                    var array = filters.Confess.Select(c => c.Name).ToArray();
                    UIActionSheet option;

                    option = new UIActionSheet("str_confession".Translate(), null, null, null, array);

                    option.ShowInView(View);

                    option.Clicked += (btn_sender, args) =>

                    {

                        var ind = Convert.ToInt32(args.ButtonIndex);

                        btnConfes.SetTitle(list[ind].Name, UIControlState.Normal);

                        data.Confession = new Confess
                        {
                            Id = list[ind].Id,
                            Name = list[ind].Name,
                            Name_kz = list[ind].Name_Kz
                        };

                    };
                }
            };

            btnType.TouchDown += (ss, ee) =>
            {
                if (filters != null)
                {
                    var list = filters.Type.Select(c =>
               new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

                    var array = filters.Type.Select(c => c.Name).ToArray();
                    UIActionSheet option;

                    option = new UIActionSheet("str_confession".Translate(), null, null, null, array);

                    option.ShowInView(View);

                    option.Clicked += (btn_sender, args) =>

                    {

                        var ind = Convert.ToInt32(args.ButtonIndex);

                        btnType.SetTitle(list[ind].Name, UIControlState.Normal);

                        data.Type = new TypeConstruction
                        {
                            Id = list[ind].Id,
                            Name = list[ind].Name,
                            Name_kz = list[ind].Name_Kz
                        };

                    };
                }
            };


            btnRegion.TouchDown += (ss, ee) =>
            {
                if (filters != null)
                {
                    var list = filters.Region.Select(c =>
               new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

                    var array = filters.Region.Select(c => c.Name).ToArray();
                    UIActionSheet option;

                    option = new UIActionSheet("str_confession".Translate(), null, null, null, array);

                    option.ShowInView(View);

                    option.Clicked += (btn_sender, args) =>

                    {

                        var ind = Convert.ToInt32(args.ButtonIndex);

                        btnRegion.SetTitle(list[ind].Name, UIControlState.Normal);

                        data.Region = new Region
                        {
                            Id = list[ind].Id,
                            Name = list[ind].Name,
                            Name_kz = list[ind].Name_Kz
                        };

                    };
                }
            };
            btnSearch.TouchDown += async (ss, ee) =>
            {
                var bounds = UIScreen.MainScreen.Bounds;

                loadPop = new LoadingOverlay(bounds);
                View.Add(loadPop);
                //var item = ss as Search;
                var res = await logic.GetLocations(Settings.Lang, data);
                if (res == null) return;
                loadPop.Hide();
                tableLoc.Hidden = false;
                tableLoc.Source = new LocTable(res);
                lblFinded.Text = "str_finded".Translate() + ": " + res.Count().ToString();
                LocTable.RowClicked += (sss, eee) =>
                {
                    var item2 = sss as Loc;
                    var hKController = this.Storyboard.InstantiateViewController("ConfessinItemViewController") as ConfessinItemViewController;
                    hKController.Data = item2;
                    this.NavigationController.PushViewController(hKController, true);
                };

                tableLoc.ReloadData();
                viewFilter.Hidden = true;
            };

            btnOnMap.TouchDown += async (ss, eq) =>
            {
                var bounds = UIScreen.MainScreen.Bounds;

                loadPop = new LoadingOverlay(bounds);
                View.Add(loadPop);
                var res = await logic.GetLocations(Settings.Lang, data);
                loadPop.Hide();
                if (res == null) return;
                LocationList = res;
                MarkresCreate(LocationList);
                viewFilter.Hidden = true;
            };

            btnReset.TouchDown += (s, e) =>
            {
                //string space = "                                    ";
                string space = "";

                data = new Search
                {
                    Confession = new Confess { Id = -1 },
                    Region = new Region { Id = -1 },
                    Type = new TypeConstruction { Id = -1 }
                };

                btnConfes.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);
                btnType.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);
                btnRegion.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);

            };

            // FILTER CLICK
            btnFilter.TouchUpInside += async (s, e) =>
            {
                viewFilter.Hidden = !viewFilter.Hidden;
                View.BringSubviewToFront(viewFilter);

            };

            // ZOOM PLUS
            btnPlus.TouchUpInside += delegate
            {
                var region = map.Region;
                region.Span.LatitudeDelta -= 0.01f;
                region.Span.LongitudeDelta -= 0.01f;
                if (region.Span.LatitudeDelta < 0 || region.Span.LongitudeDelta < 0)
                    return;
                InvokeOnMainThread(() =>
                {
                    map.SetRegion(region, false);
                });
            };

            // ZOOM MINUS
            btnMinus.TouchUpInside += delegate
            {
                var region = map.Region;
                region.Span.LatitudeDelta += 0.01f;
                region.Span.LongitudeDelta += 0.01f;

                InvokeOnMainThread(() =>
                {
                    map.SetRegion(region, false);
                });
            };

            // COMPASS
            btnCompass.TouchUpInside += delegate
            {
                //try
                //{
                //    locationManager = new CLLocationManager();

                //    locationManager.RequestWhenInUseAuthorization();
                //}
                //catch (Exception ex)
                //{
                //    var Text = "Error: " + ex;
                //}

                locationManager.RequestWhenInUseAuthorization();
                if (CLLocationManager.Status == CLAuthorizationStatus.AuthorizedWhenInUse)
                {
                    locationManager.StartUpdatingLocation();


                    locationManager.LocationsUpdated += (object ff, CLLocationsUpdatedEventArgs e) =>
                    {
                        map.ShowsUserLocation = true;
                        var Lat = locationManager.Location.Coordinate.Latitude;
                        var Lon = locationManager.Location.Coordinate.Longitude;

                        var region = map.Region;
                        region.Center.Latitude = Lat;
                        region.Center.Longitude = Lon;
                        InvokeOnMainThread(() =>
                        {
                            map.SetRegion(region, false);
                        });
                    };
                }
            };

            // SHOW BOTTOM PANEL
            btnShowBottomPanel.TouchUpInside += delegate
            {
                NavButtonHide(true);
            };

            // FEEDBACK
            btnFeedBack.TouchUpInside += (o, e) =>
            {
                var contentController = (FeedBackViewController)Storyboard.InstantiateViewController("FeedBackViewController");

                if (NavController.TopViewController as FeedBackViewController == null)
                    NavController.PushViewController(contentController, false);
                SidebarController.CloseMenu();
            };

            // OTHER RELIG
            btnOtherRelig.TouchUpInside += async delegate
            {
                var bounds = UIScreen.MainScreen.Bounds;
                loadPop = new LoadingOverlay(bounds);
                View.Add(loadPop);
                LocationList = await logic.GetFilteredLocations(Settings.Lang, 7);
                if (LocationList == null) return;
                var res2 = await logic.GetFilteredLocations(Settings.Lang, 5);
                if (res2 != null)
                    LocationList.AddRange(res2);
                MarkresCreate(LocationList);
                loadPop.Hide();
            };

            // IUDAIZM RELIG
            btnIud.TouchUpInside += async delegate
            {
                var bounds = UIScreen.MainScreen.Bounds;
                loadPop = new LoadingOverlay(bounds);
                View.Add(loadPop);
                LocationList = await logic.GetFilteredLocations(Settings.Lang, 6);
                if (LocationList == null) return;
                MarkresCreate(LocationList);
                loadPop.Hide();
            };

            // ISLAM RELIG
            btnIslam.TouchUpInside += async delegate
            {
                var bounds = UIScreen.MainScreen.Bounds;
                loadPop = new LoadingOverlay(bounds);
                View.Add(loadPop);
                LocationList = await logic.GetFilteredLocations(Settings.Lang, 1);
                if (LocationList == null) return;
                MarkresCreate(LocationList);
                loadPop.Hide();
            };

            // HRISTIAN RELIG
            btnHris.TouchUpInside += async delegate
            {
                var bounds = UIScreen.MainScreen.Bounds;
                loadPop = new LoadingOverlay(bounds);
                View.Add(loadPop);
                LocationList = await logic.GetFilteredLocations(Settings.Lang, 2);
                if (LocationList == null) return;
                MarkresCreate(LocationList);
                loadPop.Hide();
            };

            #endregion

            #region MAP

            // MAP CHANGED
            map.RegionChanged += (object sender, MKMapViewChangeEventArgs e) =>
            {
                if (clusteringManager != null)
                {

                    double scale = map.Bounds.Size.Width / map.VisibleMapRect.Size.Width;
                    List<IMKAnnotation> annotationsToDisplay = clusteringManager.ClusteredAnnotationsWithinMapRect(map.VisibleMapRect, scale);
                    clusteringManager.DisplayAnnotations(annotationsToDisplay, map);
                }
            };

            // ON MAP CHANGE
            map.RegionWillChange += (s, e) =>
             {
                 searchBar.ResignFirstResponder();
                 searchBarBottom.ResignFirstResponder();

                 tableLoc.Hidden = true;
                 tableSearch.Hidden = true;

                 NavButtonHide(false);
                 if (alertBackground == null) return;
                 alertBackground.RemoveFromSuperview();

             };

            // CUSTOM CLUSTERS AND MARKERS
            map.GetViewForAnnotation += (mapView, annotation) =>
            {
                MKAnnotationView anView;
                if (annotation is FBAnnotationCluster)
                {
                    FBAnnotationCluster annotationcluster = (FBAnnotationCluster)annotation;
                    anView = (MKAnnotationView)mapView.DequeueReusableAnnotation(kClusterAnnotationId);

                    UILabel label = null;
                    if (anView == null)
                    {
                        anView = new MKAnnotationView(annotation, kClusterAnnotationId);
                        anView.Image = UIImage.FromBundle("cluster");
                        label = new UILabel(new CGRect(0, 0, anView.Image.Size.Width, anView.Image.Size.Height));
                        label.Tag = kTagClusterLabel;
                        label.TextAlignment = UITextAlignment.Center;
                        label.TextColor = UIColor.White;
                        anView.AddSubview(label);
                        anView.CanShowCallout = false;
                    }
                    else
                    {
                        label = (UILabel)anView.ViewWithTag(kTagClusterLabel);
                    }
                    label.Text = annotationcluster.Annotations.Count.ToString();
                    return anView;
                }
                else
                {
                    var customAnotation = new MKAnnotationView
                    {
                        Annotation = annotation
                    };

                    customAnotation.Image = (annotation.GetSubtitle() == null) ? null : UIImage.FromBundle(annotation.GetSubtitle());

                    return customAnotation;
                }
            };

            // SELECT PIN
            map.DidSelectAnnotationView += (object sender, MKAnnotationViewEventArgs e) =>
            {
                tableLoc.Hidden = true;
                      //map.DeselectAnnotation(e.View.Annotation, false);
                      Loc item = null;

                var annoList = map.SelectedAnnotations;
                foreach (IMKAnnotation a in annoList)
                {
                    try
                    {
                        var sd = a.GetTitle();
                        item = LocationList.Where(s => s.Address == a.GetTitle()).FirstOrDefault();
                    }
                    catch (Exception)
                    {
                    }
                }
                if (item == null)
                    return;

                //var height = UIScreen.MainScreen.Bounds.Size.Height;
                var height = 260;
                var width = UIScreen.MainScreen.Bounds.Size.Width;
                var fullHeight = UIScreen.MainScreen.Bounds.Size.Height;


                alertBackground = new UIView(new CGRect(0, fullHeight - height - 50, width, height));


                alertBackground.BackgroundColor = UIColor.White;
                var alert = new UIView(new CGRect(0, 0, 100, 100));

                var label = new UILabel(new CGRect(20, 0, width - 40, 50));
                label.Lines = 2;
                label.TextAlignment = UITextAlignment.Center;

                var image = new UIImageView(new CGRect(0, label.Frame.Height + 10, width, 150));
                image.HeightAnchor.ConstraintEqualTo(image.WidthAnchor, 16.0f);

                try
                {
                    var uri = new Uri("http://religionmap.kz/" + item.Image);
                    var nsurl = new NSUrl(uri.GetComponents(UriComponents.HttpRequestUrl, UriFormat.UriEscaped));

                    image.SetImage(url: nsurl,
                   placeholder: UIImage.FromBundle("placeholder.png"),
                   options: SDWebImageOptions.RefreshCached
               );
                }
                catch (Exception) { }


                label.Text = item.Name;


                var button = new UIButton(new CGRect(0, label.Frame.Height + 10 + image.Frame.Height, width, 50));
                button.SetTitle("str_more".Translate(), UIControlState.Normal);
                button.SetTitleColor(UIColor.Black, UIControlState.Normal);
                button.TouchDown += (s, ee) =>
                {
                    var hKController = this.Storyboard.InstantiateViewController("ConfessinItemViewController") as ConfessinItemViewController;
                    hKController.Data = item;
                    this.NavigationController.PushViewController(hKController, true);
                };
                alertBackground.AddSubview(label);
                alertBackground.AddSubview(image);
                alertBackground.AddSubview(button);

                btnFeedBack.Hidden = false;
               

                this.View.AddSubview(alertBackground);
                View.BringSubviewToFront(alertBackground);
                View.BringSubviewToFront(btnFeedBack);
            };


            #endregion

            #region SEARCH

            SearchTableViewSourse.RowClicked += (object sender, EventArgs e) =>
            {
                var item2 = sender as Loc;
                var hKController = this.Storyboard.InstantiateViewController("ConfessinItemViewController") as ConfessinItemViewController;
                hKController.Data = item2;
                this.NavigationController.PushViewController(hKController, true);
            };

            // SEARCH TEXT
            searchBar.TextChanged += async (s, e) =>
            {

             

                if (btnFilter.Hidden)
                {
                    btnFilter.Hidden = false;

                    //constrSearchHeight.Active = false;
                }
                string text = e.SearchText.ToLower();

                if (text.Length < 3)
                {
                    tableSearch.Hidden = true;
                    return;
                }

                var res = await logic.SearchLocations(Settings.Lang, text);
                if (res == null || res.Count == 0)
                {
                    tableSearch.Hidden = true;
                    return;
                }
                tableSearch.Source = new SearchTableViewSourse(res);
                tableSearch.Hidden = false;
                tableSearch.ReloadData();


            };

            #endregion

            if (Data != null)
            {
                var list = new List<Loc> { Data};
                LocationList = list;
                MarkresCreate(list);
                return;
            }


            var locat = await logic.GetLocations(Settings.Lang, data);
            if (locat != null)
            {
                LocationList = locat;
                MarkresCreate(LocationList);
            }


        }

        // CREATE MARKERS
        private void MarkresCreate(List<Loc> list)
        {
            List<IMKAnnotation> sampleAnnotations = new List<IMKAnnotation>();

            foreach (var item in list)
            {
                var l = item.Map.Split(',');
                sampleAnnotations.Add(new MKPointAnnotation()
                {
                    Title = item.Address,
                    Subtitle = GetIcon.Get(item.Confess_id),
                    Coordinate = new CLLocationCoordinate2D(double.Parse(l[0], CultureInfo.InvariantCulture), double.Parse(l[1], CultureInfo.InvariantCulture)),
                });

            }

            var annotations = map.Annotations;
            if (annotations.Length > 0)
                map.RemoveAnnotations(annotations);

            var region = map.Region;
            region.Span.LatitudeDelta += 0.00001f;
            InvokeOnMainThread(() =>
            {
                map.SetRegion(region, true);
            });

            clusteringManager = new FBClusteringManager(sampleAnnotations);
        }

        // OPEN SLIDE MENU
        private void BtnNav_TouchUpInside(object sender, EventArgs e)
        {
            SidebarController.ToggleMenu();
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

        }

        public async override void ViewWillAppear(bool animated)
        {

            this.NavigationController.SetNavigationBarHidden(true, false);
    

            map.RegionChanged += (object sender, MKMapViewChangeEventArgs e) =>
            {
                double scale = map.Bounds.Size.Width / map.VisibleMapRect.Size.Width;
            };


            // Display a custom icon for the clusters

        }


        // DESIGN ELEMENTS
        private void Design()
        {
            var app = new App();
            I18N.Current.Locale = Settings.Lang;





            btnNav.Frame = new RectangleF(0, 0, 50, 50);

            searchBar.Layer.BorderWidth = 0.5f;
            searchBar.Layer.BorderColor = UIColor.LightGray.CGColor;
            searchBar.Placeholder = "str_search".Translate();

            searchBarBottom.Layer.BorderWidth = 0.5f;
            searchBarBottom.Layer.BorderColor = UIColor.LightGray.CGColor;
            searchBarBottom.Placeholder = "str_search".Translate();

            searchBarBottom.OnEditingStarted += (s, e) =>
             {
                 NavButtonHide(false);
                 searchBar.BecomeFirstResponder();
             };



            btnNav.Layer.BorderWidth = 0.5f;
            btnNav.Layer.BorderColor = UIColor.LightGray.CGColor;

            btnFeedBack.Layer.BackgroundColor = Colors.ColorPrimary.CGColor;
            btnFeedBack.SetTitle("str_bid".Translate(), UIControlState.Normal);


            lblOtherRelig.TextColor = Colors.ColorText;
            lblOtherRelig.Text = "str_other_relig".Translate();

            lblIud.TextColor = Colors.ColorText;
            lblIud.Text = "str_iud".Translate();

            lblIslam.TextColor = Colors.ColorText;
            lblIslam.Text = "str_islam".Translate();

            lblHris.TextColor = Colors.ColorText;
            lblHris.Text = "str_hrist".Translate();

            btnFilter.Layer.BorderColor = UIColor.LightGray.CGColor;
            btnFilter.Layer.BorderWidth = 0.5f;





            //string space = "                                    ";
            string space = "";
            lblConfes.Text = "str_confession".Translate();
            lblType.Text = "str_type".Translate();
            lblRegion.Text = "str_area".Translate();
            btnConfes.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);

            btnType.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);
            btnRegion.SetTitle("str_select".Translate().ToUpper() + space, UIControlState.Normal);
            btnConfes.SemanticContentAttribute = UISemanticContentAttribute.ForceRightToLeft;
            btnType.SemanticContentAttribute = UISemanticContentAttribute.ForceRightToLeft;
            btnRegion.SemanticContentAttribute = UISemanticContentAttribute.ForceRightToLeft;

            btnSearch.BackgroundColor = Colors.ColorGrenDark;
            btnSearch.SetTitle("str_find".Translate().ToUpper(), UIControlState.Normal);


            btnOnMap.BackgroundColor = Colors.ColorPrimary;
            btnOnMap.SetTitle("str_show_on_map".Translate().ToUpper(), UIControlState.Normal);
            btnReset.SetTitle("str_reset_filter".Translate().ToUpper(), UIControlState.Normal);

            //btnFilter.Hidden = true;
            //btnFilter.SetTitle("str_filter".Translate(), UIControlState.Normal);


            // CHANGE TO FIRST POSITION
            var region = new MKCoordinateRegion();
            region.Center.Latitude = Syst.Lat;
            region.Center.Longitude = Syst.Lon;
            region.Span.LatitudeDelta = 0.1f;
            region.Span.LongitudeDelta = 0.1f;
            InvokeOnMainThread(() =>
            {
                map.SetRegion(region, false);
            });
        }

        // HIDE/SHOW NAV BUTTONS
        private void NavButtonHide(bool visible)
        {
            btnMinus.Hidden = visible;
            btnPlus.Hidden = visible;
            btnCompass.Hidden = visible;
            btnShowBottomPanel.Hidden = visible;
            searchTopBar.Hidden = visible;
            btnFloatMenu.Hidden = !visible;
            bottomIconPanel.Hidden = !visible;
        }
    }
}