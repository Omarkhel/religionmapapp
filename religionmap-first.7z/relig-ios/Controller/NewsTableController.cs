﻿using Client;
using Client.Models.Json;
using I18NPortable;
using relig_ios.Helpers;
using relig_ios.Table;
using System;
using UIKit;

namespace relig_ios
{
    public partial class NewsTableController : UITableViewController
    {
        Logic logic = new Logic();
        LoadingOverlay loadPop;

        public NewsTableController (IntPtr handle) : base (handle)
        {
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            var bounds = UIScreen.MainScreen.Bounds;

            loadPop = new LoadingOverlay(bounds);
            View.Add(loadPop);

            var res = await logic.GetNewsList(Settings.Lang);
            loadPop.Hide();
            if (res == null)
            {
                return;
            }

            tableNews.Source = new NewsTableViewSourse(res);

            NewsTableViewSourse.RowClicked += (object sender, EventArgs e) =>
            {
                var item = sender as News;

                var hKController = this.Storyboard.InstantiateViewController("NewsItemController") as NewsItemController;
                hKController.News = item;
                this.NavigationController.PushViewController(hKController, true);
            };
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            this.NavigationController.SetNavigationBarHidden(false, false);

            var app = new App();
            I18N.Current.Locale = Settings.Lang;
            NavigationController.TopViewController.NavigationItem.Title = "str_news".Translate();
        }
    }
}