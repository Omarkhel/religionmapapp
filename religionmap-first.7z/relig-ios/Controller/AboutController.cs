﻿using Client;
using CoreGraphics;
using I18NPortable;
using relig_ios.Helpers;
using System;
using System.Drawing;
using UIKit;

namespace relig_ios
{
    public partial class AboutController : UIViewController
    {
        UIHelper uIHelper = new UIHelper();

        float margin = 10;
        nfloat height = UIScreen.MainScreen.Bounds.Size.Height;
        nfloat width = UIScreen.MainScreen.Bounds.Size.Width;
        nfloat Y = 20;

        public AboutController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            this.NavigationController.SetNavigationBarHidden(false, false);
            Design();
        }

        // DESIGN ELEMENTS
        private void Design()
        {
            var app = new App();
            I18N.Current.Locale = Settings.Lang;

            NavigationController.TopViewController.NavigationItem.Title = "str_about".Translate();

            var l1 = uIHelper.Label(Y,"RELIGION MAP", UIColor.Black, UITextAlignment.Center, UIFont.SystemFontOfSize(27, UIFontWeight.Bold));

            l1.Frame = new CGRect((int)(UIScreen.MainScreen.Bounds.GetMidX() - l1.Bounds.Width / 2), Y, l1.Bounds.Width, l1.Bounds.Height);


            Y = Y + l1.Frame.Height + 20;
            var l2 = uIHelper.Label(Y,"str_app_description".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l2.Frame.Height + 20;

            var s1 = uIHelper.ImgText(Y,"ic_1", "str_p1".Translate());
            Y = Y + s1.Frame.Height + 20;

            var s2 = uIHelper.ImgText(Y, "ic2", "str_p2".Translate());
            Y = Y + s2.Frame.Height + 20;

            var s3 = uIHelper.ImgText(Y, "ic_3", "str_p3".Translate());
            Y = Y + s3.Frame.Height + 20;

            var s4 = uIHelper.ImgText(Y, "ic_4", "str_p4".Translate());
            Y = Y + s4.Frame.Height + 20;

          //  var t = uIHelper.Text(Colors.ColorPrimary, "str_about".Translate(),Y);
            var t = uIHelper.Text(Colors.ColorPrimary, "str_about".Translate(),Y);
            Y = Y + t.Frame.Height + 18;

            var l3 = uIHelper.Label(Y, "str_op_cel".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17,UIFontWeight.Bold));
            l3.Frame = new CGRect((int)(UIScreen.MainScreen.Bounds.GetMidX() - l3.Bounds.Width / 2), Y, l3.Bounds.Width, l3.Bounds.Height);

            Y = Y + l3.Frame.Height + 20;

            var l4 = uIHelper.Label(Y, "str_ab1".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l4.Frame.Height + 20;

            var l5 = uIHelper.Label(Y, "str_ab2".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l5.Frame.Height + 20;

            var l6 = uIHelper.Label(Y, "str_ab3".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l6.Frame.Height + 20;

            var l7 = uIHelper.Label(Y, "str_ab4".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l7.Frame.Height + 20;

            var l8 = uIHelper.Label(Y, "str_ab5".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l8.Frame.Height + 20;

            var l9 = uIHelper.Label(Y, "str_ab6".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l9.Frame.Height + 20;

            var l10 = uIHelper.Label(Y, "str_ab7".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l10.Frame.Height + 20;

            var l11 = uIHelper.Label(Y, "str_ab8".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l11.Frame.Height + 20;


            var t1 = uIHelper.Text(Colors.ColorPrimary, "str_gor_sit".Translate().ToUpper(), Y);
            Y = Y + t1.Frame.Height + 20;

            var l13 = uIHelper.Label(Y, "str_g1".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l13.Frame.Height + 20;

            var l14 = uIHelper.Label(Y, "str_g2".Translate(), Colors.ColorText, UITextAlignment.Center, UIFont.SystemFontOfSize(17));
            Y = Y + l14.Frame.Height + 20;

            var b = uIHelper.Block(Colors.ColorPrimary,new string[] { "str_pp_title".Translate().ToUpper(), "str_abtvupr".Translate(), "str_str_abtvupr2".Translate() },Y);
            Y = Y + b.Frame.Height + 20;


            var scrollView = new UIScrollView
            {
                Frame = new CGRect(0, 20, width, height),
                ContentSize = new CGSize(width, Y),
                BackgroundColor = UIColor.White,
                AutoresizingMask = UIViewAutoresizing.FlexibleHeight
            };

            scrollView.AddSubview(l1);
            scrollView.AddSubview(l2);
            scrollView.AddSubview(s1);
            scrollView.AddSubview(s2);
            scrollView.AddSubview(s3);
            scrollView.AddSubview(s4);
            scrollView.AddSubview(t);
            scrollView.AddSubview(l3);
            scrollView.AddSubview(l4);
            scrollView.AddSubview(l5);
            scrollView.AddSubview(l6);
            scrollView.AddSubview(l7);
            scrollView.AddSubview(l8);
            scrollView.AddSubview(l9);
            scrollView.AddSubview(l10);
            scrollView.AddSubview(l11);
            scrollView.AddSubview(t1);
            scrollView.AddSubview(l13);
            scrollView.AddSubview(l14);
            scrollView.AddSubview(b);


            View.AddSubview(scrollView);

        }


    }
}