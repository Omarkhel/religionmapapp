﻿using System;
using Client;
using Client.Models.Json.Models;
using Foundation;
using I18NPortable;
using SDWebImage;
using UIKit;

namespace relig_ios
{
    public partial class PopoverContentViewController : BaseController, IUIPopoverPresentationControllerDelegate, IUIAdaptivePresentationControllerDelegate
    {
        public Loc Data { get; set; }
        public event EventHandler RowClicked = delegate { };

        public PopoverContentViewController(IntPtr handle) : base(handle)
        {
            ModalPresentationStyle = UIModalPresentationStyle.Popover;
            PopoverPresentationController.Delegate = this;
            PreferredContentSize = new CoreGraphics.CGSize(300, 200);
        }


        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            var app = new App();
            I18N.Current.Locale = Settings.Lang;

            lblName.Text = Data.Name;
            lblName.LineBreakMode = UILineBreakMode.WordWrap;


            btnOpen.SetTitle("str_more".Translate(), UIControlState.Normal);
            btnOpen.TouchUpInside += (s, e) =>
            {
                RowClicked(null, null);
                this.DismissViewController(true, null);
            };

            try
            {
                var uri = new Uri("http://religionmap.kz/" + Data.Image);
                var nsurl = new NSUrl(uri.GetComponents(UriComponents.HttpRequestUrl, UriFormat.UriEscaped));

                img.SetImage(url: nsurl,
               placeholder: UIImage.FromBundle("placeholder.png"),
               options: SDWebImageOptions.RefreshCached
           );
                
            }
            catch (Exception) { }
        }

        public override bool ShouldAutorotateToInterfaceOrientation(UIInterfaceOrientation toInterfaceOrientation)
        {
            return true;
        }

        [Export("adaptivePresentationStyleForPresentationController:traitCollection:")]
        public UIModalPresentationStyle GetAdaptivePresentationStyle(UIPresentationController controller, UITraitCollection traitCollection)
        {
            return UIModalPresentationStyle.None;
        }

        static UIImage FromUrl(string uri)
        {
            using (var url = new NSUrl(uri))
            using (var data = NSData.FromUrl(url))
                return UIImage.LoadFromData(data);
        }
    }
}