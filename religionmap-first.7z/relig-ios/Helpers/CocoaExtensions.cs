﻿using CoreAnimation;
using System.Drawing;
using UIKit;

namespace relig_ios
{
    public static class CocoaExtensions
    {
        public static void AddLinearGradientToView(this UIView view, UIColor topColor, UIColor bottomColor)
        {
            if (view.Layer.Sublayers != null)
            {
                foreach (CALayer layer in view.Layer.Sublayers)
                {
                    if (layer is CAGradientLayer)
                        layer.RemoveFromSuperLayer();
                }
            }

            var f = view.Bounds;
            f.Width = 280;
            f.Height = 35;
            var gradientLayer = new CAGradientLayer()
            {
                StartPoint = new PointF { X = 0, Y = 0 },
                EndPoint = new PointF { X = 1, Y = 1 },
                Frame = f,
                Colors = new[] { topColor.CGColor, bottomColor.CGColor }
            };


            if (view.Layer.Sublayers != null)
            {
                if (view.Layer.Sublayers.Length > 0)
                {
                    view.Layer.InsertSublayer(gradientLayer, view.Layer.Sublayers.Length - 2);
                }
                else
                {
                    view.Layer.AddSublayer(gradientLayer);
                }

            }
            else
            {
                view.Layer.AddSublayer(gradientLayer);
            }
        }
    }
}