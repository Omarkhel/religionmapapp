﻿namespace relig_ios.Helpers
{
    public class GetIcon
    {
        public static string Get(string id)
        {
            string icon = "ic_pin_other";

            switch (id)
            {
                case "5":
                    icon = "ic__new";
                    break;
                case "7":
                    icon = "ic__new";
                    break;
                case "6":
                    icon = "icon_iud";
                    break;
                case "1":
                    icon = "m_1";
                    break;
                case "2":
                    icon = "m_2";
                    break;
            }
            return icon;
        }
    }
}