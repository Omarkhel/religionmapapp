﻿using Client;
using Client.Models;
using SidebarNavigation;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios.Helpers
{
    public class SettingModel : UIPickerViewModel
    {
   
        private UILabel personLabel;
        private List<LangModel> list { get; set; }

        public SettingModel(UILabel personLabel, List<LangModel> list)
        {
            this.personLabel = personLabel;
            this.list = list;
        }

        //public override nint GetComponentCount(UIPickerView pickerView)
        //{
        //    return 2;
        //}

        public override nint GetRowsInComponent(UIPickerView pickerView, nint component)
        {
            return list.Count;
        }

        public override string GetTitle(UIPickerView pickerView, nint row, nint component)
        {
            if (component == 0)
                return list[(int)row].Title;
            else
                return row.ToString();
        }

        public override void Selected(UIPickerView pickerView, nint row, nint component)
        {
            personLabel.Text = list[(int)pickerView.SelectedRowInComponent(0)].Title;
            Settings.Lang = list[(int)pickerView.SelectedRowInComponent(0)].Lng;
            //new AppDelegate().refr();
        }

        public override nfloat GetComponentWidth(UIPickerView picker, nint component)
        {
            if (component == 0)
                return 240f;
            else
                return 40f;
        }

        public override nfloat GetRowHeight(UIPickerView picker, nint component)
        {
            return 40f;
        }
    }
}