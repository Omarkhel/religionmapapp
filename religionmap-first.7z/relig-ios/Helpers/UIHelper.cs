﻿using CoreGraphics;
using System;
using UIKit;

namespace relig_ios.Helpers
{
    public class UIHelper
    {
        nfloat Width = UIScreen.MainScreen.Bounds.Size.Width;

        public UILabel Label(nfloat Y, string text, UIColor color, UITextAlignment textAlignment, UIFont Font)
        {
            return Label(0,Y,Width, text,color,textAlignment,Font);
        }

        public UIButton Button(nfloat Y,string text)
        {
            var button = new UIButton(new CGRect(20, Y, Width - 40, 20));
            button.SetTitle(text, UIControlState.Normal);
            button.SetTitleColor(Colors.ColorPrimary, UIControlState.Normal);
            return button;
        }

        public UITextField TextField(nfloat Y)
        {
            var textField = new UITextField(new CGRect(15, Y, Width -30, 30));
            textField.Layer.BorderColor = Colors.ColorText.CGColor;
            textField.Layer.CornerRadius = 15;
            textField.BorderStyle = UITextBorderStyle.RoundedRect;

            return textField;
        }

        public UILabel Label(nfloat x,nfloat Y,nfloat width, string text, UIColor color, UITextAlignment textAlignment, UIFont Font)
        {

            var label = new UILabel();
            label.TextColor = color;
            label.Text = text;
            label.Lines = 0;

            label.Frame = new CGRect(x, Y, width, 15);
            label.TextAlignment = textAlignment;
            label.Font = Font;
            label.SizeToFit();
            label.LayoutIfNeeded();
            return label;
        }


        public UITextField Textf(nfloat x, nfloat Y, nfloat width, string text, UIColor color)
        {

            var textf = new UITextField();
            //label.TextColor = color;
            //label.Text = text;
            //label.Lines = 0;

            textf.Frame = new CGRect(x, Y, width, 15);
            //label.TextAlignment = textAlignment;
            //label.Font = Font;
            //label.SizeToFit();
            //label.LayoutIfNeeded();
            return textf;
        }

        public UIImageView ImageView(string path)
        {
            var image = new UIImageView();
            image.Image = UIImage.FromBundle(path);
            image.Frame = new CGRect(0, 0, 100, 100);

            return image;
        }

        public UIView Text(UIColor background,string text, nfloat Y)
        {
            var lbl = Label(0, 10, Width - 120, text, UIColor.White, UITextAlignment.Center, UIFont.SystemFontOfSize(26, UIFontWeight.Bold));
            lbl.Frame = new CGRect((int)(UIScreen.MainScreen.Bounds.GetMidX() - lbl.Bounds.Width / 2), 20, lbl.Bounds.Width, lbl.Bounds.Height);

            var view = new UIView();
            view.Frame = new CGRect(0, Y, Width, lbl.Frame.Height + 30);
            view.BackgroundColor = background;

            view.AddSubview(lbl);
            return view;
        }

        public UIView Block(UIColor background, string[] text, nfloat Y)
        {
            nfloat y = 10;
            var lbl = Label(0, y, Width - 120, text[0], UIColor.White, UITextAlignment.Center, UIFont.SystemFontOfSize(26, UIFontWeight.Bold));
            lbl.Frame = new CGRect((int)(UIScreen.MainScreen.Bounds.GetMidX() - lbl.Bounds.Width / 2), lbl.Bounds.Height / 2, lbl.Bounds.Width, lbl.Bounds.Height);
            y = y + lbl.Frame.Height + 20;

            var lb2 = Label(0, y, Width - 120, text[1], UIColor.White, UITextAlignment.Center, UIFont.SystemFontOfSize(17, UIFontWeight.Bold));
            lb2.Frame = new CGRect((int)(UIScreen.MainScreen.Bounds.GetMidX() - lb2.Bounds.Width / 2), y, lb2.Bounds.Width, lb2.Bounds.Height);

            y = y + lb2.Frame.Height + 20;

            var lb3 = Label(0, y, Width - 120, " — ", UIColor.White, UITextAlignment.Center, UIFont.SystemFontOfSize(17, UIFontWeight.Bold));
            lb3.Frame = new CGRect((int)(UIScreen.MainScreen.Bounds.GetMidX() - lb3.Bounds.Width / 2), y, lb3.Bounds.Width, lb3.Bounds.Height);

            y = y + lb3.Frame.Height + 20;

            var lb4 = Label(0, y, Width - 120, text[2], UIColor.White, UITextAlignment.Center, UIFont.SystemFontOfSize(17, UIFontWeight.Bold));
            lb4.Frame = new CGRect((int)(UIScreen.MainScreen.Bounds.GetMidX() - lb4.Bounds.Width / 2), y, lb4.Bounds.Width, lb4.Bounds.Height);


            var view = new UIView();
            view.Frame = new CGRect(0, Y, Width, lbl.Frame.Height + 30 + lb2.Frame.Height + 30 + lb3.Frame.Height + 30 + lb4.Frame.Height + 30);
            view.BackgroundColor = background;

            view.AddSubview(lbl);
            view.AddSubview(lb2);
            view.AddSubview(lb3);
            view.AddSubview(lb4);
            return view;
        }

        public UIView ImgText(nfloat Y, string Image, string text)
        {
            var view = new UIView();
            view.Frame = new CGRect(0, Y, Width, 120);

            view.SizeToFit();
            view.LayoutIfNeeded();

            var img = ImageView(Image);
            var lbl = Label(110,10, Width - 120, text, Colors.ColorText, UITextAlignment.Left, UIFont.SystemFontOfSize(17));
            //lbl.Frame = new CGRect(110, (int)(120 - lbl.Bounds.Height / 2), lbl.Bounds.Width, lbl.Bounds.Height);

            view.AddSubview(img);
            view.AddSubview(lbl);

            return view;
        }
    }
}