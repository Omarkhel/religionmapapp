﻿using Client;
using CoreGraphics;
using I18NPortable;
using MapKit;
using relig_ios.Helpers;
using System;
using UIKit;
using Plugin.Media;
using System.Collections.Generic;
using System.IO;
using CoreLocation;
using Plugin.Media.Abstractions;

namespace relig_ios
{
    public partial class FeedBackViewController : UIViewController
    {
        MKMapView map;
        MKPointAnnotation annotation;
        CLLocationManager locationManager;

        string Location = "";

        public FeedBackViewController(IntPtr handle) : base(handle)
        {
        }

        nfloat height = UIScreen.MainScreen.Bounds.Size.Height;
        nfloat width = UIScreen.MainScreen.Bounds.Size.Width;
        nfloat Y = 20;
        UIScrollView scrollView;


        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            var notification = UIKeyboard.Notifications.ObserveWillShow(KeyboardWillShow);
            Design();
        }


        void KeyboardWillShow(object sender, UIKit.UIKeyboardEventArgs args)
        {
            var gg = args.FrameEnd.Size.Height;
            if (scrollView != null)
            {
                UIView.Animate(1, 0.6, UIViewAnimationOptions.BeginFromCurrentState, () =>
                  {
                      scrollView.SetContentOffset(new CGPoint(0, View.Bounds.Height + gg), false);
                  }, null);
            }
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);



        }

        private void OnTap(UITapGestureRecognizer recognizer)
        {
            if (map == null) return;
            var cgPoint = recognizer.LocationInView(map);
            var location = ((MKMapView)map).ConvertPoint(cgPoint, map);
            Location = $"{location.Latitude},{location.Longitude}";
            if (annotation != null)
                map.RemoveAnnotation(annotation);
            annotation = new MKPointAnnotation()
            {
                //Title = "MyAnnotation",
                Coordinate = new CLLocationCoordinate2D(location.Latitude, location.Longitude)
            };

            map.AddAnnotations(annotation);
        }


        // DESIGN ELEMENTS
        private async void Design()
        {
            var FilesList = new List<string>();

            var app = new App();
            I18N.Current.Locale = Settings.Lang;

            var uIHelper = new UIHelper();
            this.NavigationController.SetNavigationBarHidden(false, false);
            NavigationController.TopViewController.NavigationItem.Title = "str_feedback".Translate();
            try
            {
                locationManager = new CLLocationManager();

                locationManager.RequestWhenInUseAuthorization();
            }
            catch (Exception ex)
            {
                var Text = "Error: " + ex;
            }

            var l1 = uIHelper.Label(Y, "str_feedback".Translate(), Colors.ColorText, UITextAlignment.Left, UIFont.SystemFontOfSize(27, UIFontWeight.Bold));
            l1.Frame = new CGRect(15, Y, width - 30, l1.Frame.Height);
            Y = Y + l1.Frame.Height + 20;

            var l2 = uIHelper.Label(Y, "str_feedback_title".Translate(), Colors.ColorText, UITextAlignment.Left, UIFont.SystemFontOfSize(17));
            l2.Frame = new CGRect(15, Y, width - 30, l2.Frame.Height);
            Y = Y + l2.Frame.Height + 20;

            map = new MKMapView(new CGRect(0, Y, width, 200));
            map.ShowsUserLocation = true;
            var region = new MKCoordinateRegion();
            region.Center.Latitude = Syst.Lat;
            region.Center.Longitude = Syst.Lon;
            region.Span.LatitudeDelta = 0.1f;
            region.Span.LongitudeDelta = 0.1f;
            InvokeOnMainThread(() =>
            {
                map.SetRegion(region, false);
            });

            Y = Y + map.Frame.Height + 20;

            var ges = new UITapGestureRecognizer(OnTap);
            map.AddGestureRecognizer(ges);

            var l3 = uIHelper.Label(Y, "str_fedback_name".Translate(), Colors.ColorPrimary, UITextAlignment.Left, UIFont.SystemFontOfSize(17));
            l3.Frame = new CGRect(15, Y, width - 30, l3.Frame.Height);
            Y = Y + l3.Frame.Height + 20;

            var t1 = uIHelper.TextField(Y);
            Y = Y + t1.Frame.Height + 20;

            var l4 = uIHelper.Label(Y, "Email", Colors.ColorPrimary, UITextAlignment.Left, UIFont.SystemFontOfSize(17));
            l4.Frame = new CGRect(15, Y, width - 30, l4.Frame.Height);
            Y = Y + l3.Frame.Height + 20;

            var t2 = uIHelper.TextField(Y);
            Y = Y + t2.Frame.Height + 20;


            var l5 = uIHelper.Label(Y, "str_feedback_num".Translate(), Colors.ColorPrimary, UITextAlignment.Left, UIFont.SystemFontOfSize(17));
            l5.Frame = new CGRect(15, Y, width - 30, l5.Frame.Height);
            Y = Y + l3.Frame.Height + 20;

            var t3 = uIHelper.TextField(Y);
            Y = Y + t3.Frame.Height + 20;

            var l6 = uIHelper.Label(Y, "str_message".Translate(), Colors.ColorPrimary, UITextAlignment.Left, UIFont.SystemFontOfSize(17));
            l6.Frame = new CGRect(15, Y, width - 30, l6.Frame.Height);
            Y = Y + l3.Frame.Height + 20;

            var t4 = uIHelper.TextField(Y);
            t4.Frame = new CGRect(15, Y, width - 30, t4.Frame.Height + 50);


            Y = Y + t4.Frame.Height + 20;

            var l7 = uIHelper.Label(Y, "", Colors.ColorText, UITextAlignment.Left, UIFont.SystemFontOfSize(12));
            l7.Frame = new CGRect(15, Y, width - 30, 50);
            l7.Lines = 5;
            Y = Y + l7.Frame.Height + 20;

            var b1 = uIHelper.Button(Y, "str_attach".Translate());
            b1.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
            Y = Y + b1.Frame.Height + 20;

            b1.TouchDown += async (s, e) =>
             {
                 try
                 {
                     //var file1 = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions());

                     var file = await CrossMedia.Current.PickPhotoAsync();
                     if (file == null)
                         return;

                     string fileName = file.Path;
                     // string contents = System.Text.Encoding.UTF8.GetString(fileData.DataArray);



                     if (FilesList.Contains(fileName))
                     {
                         new UIAlertView("str_file_exists".Translate(), "", null, "OK", null).Show();
                         // Snackbar.Make(view, "str_file_exists".Translate(), Snackbar.LengthLong).Show();
                         return;
                     }
                     if (FilesList.Count > 2)
                     {
                         new UIAlertView("str_file_count".Translate(), "", null, "OK", null).Show();

                         //Snackbar.Make(view, "str_file_count".Translate(), Snackbar.LengthLong).Show();
                         return;
                     }
                     l7.Text += Path.GetFileName(fileName) + "\r\n";
                     FilesList.Add(fileName);
                 }
                 catch (Exception ex)
                 {
                     System.Console.WriteLine("Exception choosing file: " + ex.ToString());
                 }
             };

            var bc = uIHelper.Button(Y, "str_photo".Translate());
            bc.HorizontalAlignment = UIControlContentHorizontalAlignment.Left;
            Y = Y + bc.Frame.Height + 20;

            bc.TouchDown += async (s, e) =>
            {
                try
                {
                    var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions());

                    if (file == null)
                        return;

                    string fileName = file.Path;
                    // string contents = System.Text.Encoding.UTF8.GetString(fileData.DataArray);



                    if (FilesList.Contains(fileName))
                    {
                        new UIAlertView("str_file_exists".Translate(), "", null, "OK", null).Show();
                        // Snackbar.Make(view, "str_file_exists".Translate(), Snackbar.LengthLong).Show();
                        return;
                    }
                    if (FilesList.Count > 2)
                    {
                        new UIAlertView("str_file_count".Translate(), "", null, "OK", null).Show();

                        //Snackbar.Make(view, "str_file_count".Translate(), Snackbar.LengthLong).Show();
                        return;
                    }
                    l7.Text += Path.GetFileName(fileName) + "\r\n";
                    FilesList.Add(fileName);
                }
                catch (Exception ex)
                {
                    System.Console.WriteLine("Exception choosing file: " + ex.ToString());
                }
            };



            var b2 = uIHelper.Button(Y, "str_send".Translate());
            b2.BackgroundColor = Colors.ColorPrimary;
            b2.SetTitleColor(UIColor.White, UIControlState.Normal);
            b2.Frame = new CGRect(0, Y, width, b2.Frame.Height + 30);
            Y = Y + b2.Frame.Height + 20;

            b2.TouchDown += async (s, e) =>
             {
                 if (Location == "")
                 {
                     new UIAlertView("str_locat".Translate(), "", null, "OK", null).Show();
                     return;
                 }

                 if (t1.Text.Length == 0)
                 {
                     new UIAlertView("str_field".Translate() + l3.Text + "str_req2".Translate(), "", null, "OK", null).Show();
                     return;
                 }
                 if (t2.Text.Length == 0)
                 {
                     new UIAlertView("str_field".Translate() + l4.Text + "str_req2".Translate(), "", null, "OK", null).Show();
                     return;
                 }
                 if (t2.Text.Length == 0)
                 {
                     new UIAlertView("str_field".Translate() + l4.Text + "str_req2".Translate(), "", null, "OK", null).Show();
                     return;
                 }
                 if (t3.Text.Length == 0)
                 {
                     new UIAlertView("str_field".Translate() + l5.Text + "str_req2".Translate(), "", null, "OK", null).Show();
                     return;
                 }
                 if (t4.Text.Length == 0)
                 {
                     new UIAlertView("str_field".Translate() + l6.Text + "str_req2".Translate(), "", null, "OK", null).Show();
                     return;
                 }



                 List<KeyValuePair<String, String>> pair = new List<KeyValuePair<string, string>>
                 {
                     new KeyValuePair<string, string>("location",Location),
                     new KeyValuePair<string, string>("full_name",t1.Text),
                     new KeyValuePair<string, string>("mail",t2.Text),
                     new KeyValuePair<string, string>("phone",t3.Text),
                     new KeyValuePair<string, string>("text",t4.Text),
                 };

                 t4.EditingChanged += (s2, e2) =>
                 {
                     t4.BecomeFirstResponder();
                 };

                 t4.EditingDidBegin += (s2, e2) =>
                 {
                     t4.BecomeFirstResponder();
                 };

                 t4.Started += (s2, e2) =>
                 {
                     t4.BecomeFirstResponder();
                 };

                 t4.TouchDown += (s2, e2) =>
                 {
                     t4.BecomeFirstResponder();
                 };

                 t4.TouchUpInside += (s2, e2) =>
                 {
                     t4.BecomeFirstResponder();
                 };

                 t4.ValueChanged += (s2, e2) =>
                 {
                     t4.BecomeFirstResponder();
                 };

                 t4.AllEditingEvents += (s2, e2) =>
                 {
                     t4.BecomeFirstResponder();
                 };

                 LoadingOverlay loadPop;


                 var bounds = UIScreen.MainScreen.Bounds;

                 loadPop = new LoadingOverlay(bounds);
                 View.Add(loadPop);

                 var logic = new Logic();
                 var res = await logic.FeedBack(pair, FilesList);
                 loadPop.Hide();

                 if (res == null || res.Result == false)
                 {
                     new UIAlertView("str_notsend".Translate(), "", null, "OK", null).Show();

                 }
                 else
                 {
                     new UIAlertView("str_send_ok".Translate(), "", null, "OK", null).Show();
                 }

             };
            scrollView = new UIScrollView
            {
                Frame = new CGRect(0, 20, width, height),
                ContentSize = new CGSize(width, Y),
                BackgroundColor = UIColor.White,
                AutoresizingMask = UIViewAutoresizing.FlexibleHeight
            };


            UITapGestureRecognizer taps = new UITapGestureRecognizer();
            taps.CancelsTouchesInView = false;
            taps.AddTarget(() => scrollView.EndEditing(true));
            scrollView.AddGestureRecognizer(taps);


            scrollView.AddSubview(l1);
            scrollView.AddSubview(l2);
            scrollView.AddSubview(map);
            scrollView.AddSubview(l3);
            scrollView.AddSubview(t1);
            scrollView.AddSubview(l4);
            scrollView.AddSubview(t2);

            scrollView.AddSubview(l5);
            scrollView.AddSubview(t3);

            scrollView.AddSubview(l6);
            scrollView.AddSubview(t4);
            scrollView.AddSubview(b1);
            scrollView.AddSubview(bc);
            scrollView.AddSubview(l7);
            scrollView.AddSubview(b2);

            View.AddSubview(scrollView);

        }
    }
}