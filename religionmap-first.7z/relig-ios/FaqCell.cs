﻿using Client.Models.Json;
using System;
using UIKit;

namespace relig_ios
{
    public partial class FaqCell : UITableViewCell
    {
        public FaqCell(IntPtr handle) : base(handle)
        {
        }

        internal void UpdateCell(Faq faq)
        {
            title.Text = faq.Title;
        }
    }
}