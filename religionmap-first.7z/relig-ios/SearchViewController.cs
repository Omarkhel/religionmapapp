﻿using Client.Models.Json.Models;
using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios
{
    public partial class SearchViewController : UIViewController, IUIPopoverPresentationControllerDelegate, IUIAdaptivePresentationControllerDelegate
    {
        public event EventHandler RowClicked = delegate { };

        public List<Loc> Data { get; set; }

        public SearchViewController(IntPtr handle) : base(handle)
        {
            var height = UIScreen.MainScreen.Bounds.Size.Height;
            var width = UIScreen.MainScreen.Bounds.Size.Width;

            ModalPresentationStyle = UIModalPresentationStyle.Popover;
            PopoverPresentationController.Delegate = this;
            PreferredContentSize = new CoreGraphics.CGSize(width - 60, height /2 );
        }

        public override bool ShouldAutorotateToInterfaceOrientation(UIInterfaceOrientation toInterfaceOrientation)
        {
            return true;
        }

        [Export("adaptivePresentationStyleForPresentationController:traitCollection:")]
        public UIModalPresentationStyle GetAdaptivePresentationStyle(UIPresentationController controller, UITraitCollection traitCollection)
        {
            return UIModalPresentationStyle.None;
        }


        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            if (Data.Count == 0)
                this.DismissViewController(true, null);
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            SearchTableView.Source = new SearchTableViewSourse(Data);

            SearchTableViewSourse.RowClicked += (object sender, EventArgs e) =>
            {
                RowClicked(sender, EventArgs.Empty);
                this.DismissViewController(true, null);
            };


        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }
}