﻿using UIKit;

namespace relig_ios
{
    public class Colors
    {
        public static UIColor ColorPrimary = new UIColor(red: 0.52f, green: 0.71f, blue: 0.15f, alpha: 1.0f);
        public static UIColor ColorGrenDark = new UIColor(red: 0.33f, green: 0.55f, blue: 0.29f, alpha: 1.0f);
        public static UIColor ColorText = new UIColor(red: 0.40f, green: 0.41f, blue: 0.41f, alpha: 1.0f);
        public static UIColor BtnGreen = new UIColor(red: 0.38f, green: 0.71f, blue: 0.75f, alpha: 1.0f);
    }
}