﻿using Client.Helper;
using Client.Models.Json;
using CoreGraphics;
using Foundation;
using relig_ios.Helpers;
using System;
using UIKit;

namespace relig_ios
{
    public partial class FAQItemController : UIViewController
    {
        public Faq FAQ { get; set; }
        public FAQItemController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            nfloat height = UIScreen.MainScreen.Bounds.Size.Height;
            nfloat width = UIScreen.MainScreen.Bounds.Size.Width;

            this.NavigationController.SetNavigationBarHidden(false, false);
            NavigationController.TopViewController.NavigationItem.Title = "FAQ";

            var uIHelper = new UIHelper();

            var l1 = uIHelper.Label(0, HtmlClean.GetText(FAQ.Text), UIColor.Black, UITextAlignment.Center, UIFont.SystemFontOfSize(17));

            l1.Frame = new CGRect((int)(UIScreen.MainScreen.Bounds.GetMidX() - l1.Bounds.Width / 2), 0, l1.Bounds.Width, l1.Bounds.Height);
            var scrollView = new UIScrollView
            {
                Frame = new CGRect(0, 20, width, height),
                ContentSize = new CGSize(width, l1.Frame.Height),
                BackgroundColor = UIColor.White,
                AutoresizingMask = UIViewAutoresizing.FlexibleHeight
            };

            scrollView.AddSubview(l1);


            View.AddSubview(scrollView);



        }
    }
}