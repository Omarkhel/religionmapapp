﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace relig_ios
{
    [Register ("SelectLangController")]
    partial class SelectLangController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnRus { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblSelectLang { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblStep { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView root { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton tnKaz { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnRus != null) {
                btnRus.Dispose ();
                btnRus = null;
            }

            if (lblSelectLang != null) {
                lblSelectLang.Dispose ();
                lblSelectLang = null;
            }

            if (lblStep != null) {
                lblStep.Dispose ();
                lblStep = null;
            }

            if (root != null) {
                root.Dispose ();
                root = null;
            }

            if (tnKaz != null) {
                tnKaz.Dispose ();
                tnKaz = null;
            }
        }
    }
}