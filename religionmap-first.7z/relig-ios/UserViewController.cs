﻿using Client;
using Client.Helper;
using Client.Models.Json.Models;
using Foundation;
using I18NPortable;
using relig_ios.Helpers;
using SDWebImage;
using System;
using UIKit;

namespace relig_ios
{
    public partial class UserViewController : UIViewController
    {
        public Loc Data { get; set; }

        public UserViewController(IntPtr handle) : base(handle)
        {
        }

        public async override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            NavigationController.TopViewController.NavigationItem.Title = Data.People[0].Name;


            var app = new App();
            I18N.Current.Locale = Settings.Lang;
            lblGr.Text = "str_citizenship".Translate();
            lblDol.Text = "str_post".Translate();
            lblConf.Text = "str_confession".Translate();
            lblSt.Text = "str_exp".Translate();

            var logic = new Logic();
            LoadingOverlay loadPop;


            var bounds = UIScreen.MainScreen.Bounds;

            loadPop = new LoadingOverlay(bounds);
            View.Add(loadPop);


       

            var res = await logic.GetPeopleItem(Settings.Lang, Data.People[0].Id);
            loadPop.Hide();
            if (res == null) return;

            try
            {
                var uri = new Uri("http://religionmap.kz/" + res.Image);
                var nsurl = new NSUrl(uri.GetComponents(UriComponents.HttpRequestUrl, UriFormat.UriEscaped));

                image.SetImage(url: nsurl,
               placeholder: UIImage.FromBundle("placeholder.png"),
               options: SDWebImageOptions.RefreshCached
           );

            }
            catch (Exception) { }


            image.Layer.CornerRadius = image.Frame.Size.Width / 2;
            image.ClipsToBounds = true;


            lblName.Text = Data.People[0].Name;
            lblGr1.Text = Data.People[0].Gr;
            lblDol2.Text = Data.People[0].Position;
            lblConf2.Text = ConfesHelper.Get(Data.People[0].confess_id.ToString());
            lblMore.Text = HtmlClean.GetText(res.Description);
            lblSt2.Text = Data.People[0].Exp;

        }
    }
}