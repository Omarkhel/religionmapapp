﻿using Client;
using CoreAnimation;
using Foundation;
using I18NPortable;
using System;
using UIKit;

namespace relig_ios
{
    public partial class SelectLangController : UIViewController
    {
        public SelectLangController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);


            var app = new App();
            I18N.Current.Locale = Settings.Lang;

            var gradientLayer = new CAGradientLayer();
            gradientLayer.Colors = new[] { Colors.ColorPrimary.CGColor, Colors.ColorGrenDark.CGColor };
            gradientLayer.Locations = new NSNumber[] { 0, 1 };
            gradientLayer.Frame = View.Frame;

            View.BackgroundColor = UIColor.Clear;
            View.Layer.InsertSublayer(gradientLayer, 0);

            lblStep.Text = "str_step1".Translate();
            lblSelectLang.Text = "str_select_lang".Translate();

            btnRus.SetTitle("str_rus".Translate(), UIControlState.Normal);
            tnKaz.SetTitle("str_lan_kaz".Translate(), UIControlState.Normal);
            btnRus.Layer.BorderWidth = 1;
            tnKaz.Layer.BorderWidth = 1;
            btnRus.TintColor = UIColor.White;
            tnKaz.TintColor = UIColor.White;
            btnRus.Layer.BorderColor = UIColor.White.CGColor;
            tnKaz.Layer.BorderColor = UIColor.White.CGColor;


            btnRus.TouchDown +=(s,e) =>
            {
                Settings.Lang = "ru";
                Next();
            };

            tnKaz.TouchDown += (s, e) =>
            {
                Settings.Lang = "kz";
                Next();
            };

            void Next()
            {
                var hKController = this.Storyboard.InstantiateViewController("FinishviewController") as FinishviewController;

                this.NavigationController.PushViewController(hKController, true);
            }


        }


    }
}