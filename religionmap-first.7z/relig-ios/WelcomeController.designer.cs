﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace relig_ios
{
    [Register ("WelcomeController")]
    partial class WelcomeController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel blW1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnNext { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblDes { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblReligionmap { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblw2 { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (blW1 != null) {
                blW1.Dispose ();
                blW1 = null;
            }

            if (btnNext != null) {
                btnNext.Dispose ();
                btnNext = null;
            }

            if (lblDes != null) {
                lblDes.Dispose ();
                lblDes = null;
            }

            if (lblReligionmap != null) {
                lblReligionmap.Dispose ();
                lblReligionmap = null;
            }

            if (lblw2 != null) {
                lblw2.Dispose ();
                lblw2 = null;
            }
        }
    }
}