﻿using Client.Models.Json.Models;
using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios
{
    public class SearchTableViewSourse : UITableViewSource
    {
        public static event EventHandler RowClicked = delegate { };
        private List<Loc> list;

        public SearchTableViewSourse(List<Loc> list)
        {
            this.list = list;
        }

        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            var cell = new UITableViewCell(UITableViewCellStyle.Default, "");
            cell.TextLabel.Text = list[indexPath.Row].Name;
            return cell;
        }

        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return list.Count;
        }

        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            RowClicked(list[indexPath.Row], EventArgs.Empty);
        }
    }
}