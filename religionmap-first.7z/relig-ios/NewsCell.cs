﻿using Client.Models.Json;
using Foundation;
using SDWebImage;
using System;
using UIKit;

namespace relig_ios
{
    public partial class NewsCell : UITableViewCell
    {
        public NewsCell(IntPtr handle) : base(handle)
        {
        }

        internal void UpdateCell(News NewItem)
        {
            lblTitle.Text = NewItem.Title;
           // lblDate.Text = NewItem.Date;

            try
            {
                var uri = new Uri($"http://religionmap.kz{NewItem.Image}");
                var nsurl = new NSUrl(uri.GetComponents(UriComponents.HttpRequestUrl, UriFormat.UriEscaped));

                image.SetImage(
                    url: nsurl,
                    placeholder: UIImage.FromBundle("placeholder.png"),
                    options: SDWebImageOptions.RefreshCached
                );
            }
            catch (Exception ex)
            {
                image.Image = UIImage.FromBundle("placeholder.png");
            }
        }
    }

}