﻿using SidebarNavigation;
using UIKit;

namespace relig_ios
{
    public partial class RootViewController : UIViewController
    {
        private UIStoryboard _storyboard;


        // the sidebar controller for the app
        public SidebarNavigation.SidebarController SidebarController { get; private set; }

        // the navigation controller
        public NavController NavController { get; private set; }

        // the storyboard
        public override UIStoryboard Storyboard
        {
            get
            {
                if (_storyboard == null)
                    _storyboard = UIStoryboard.FromName("Main", null);
                return _storyboard;
            }
        }

        public RootViewController() : base(null, null)
        {

        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            //var mapController = (MapController)Storyboard.InstantiateViewController("MapController");
            var mapController = (WelcomeController)Storyboard.InstantiateViewController("WelcomeController");
            var menuController = (MenuController)Storyboard.InstantiateViewController("MenuController");

            // create a slideout navigation controller with the top navigation controller and the menu view controller
            NavController = new NavController();
            NavController.PushViewController(mapController, false);
            SidebarController = new SidebarNavigation.SidebarController(this, NavController, menuController);
            SidebarController.MenuWidth = 280;
            SidebarController.ReopenOnRotate = false;
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
        }
    }
}