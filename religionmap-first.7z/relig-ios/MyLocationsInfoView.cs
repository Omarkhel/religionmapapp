﻿using Foundation;
using UIKit;

namespace relig_ios
{
    public partial class MyLocationsInfoView : UIViewController, IUIPopoverPresentationControllerDelegate, IUIAdaptivePresentationControllerDelegate
    {
        public MyLocationsInfoView() : base("MyLocationsInfoView", null)
        {
            ModalPresentationStyle = UIModalPresentationStyle.Popover;
            PopoverPresentationController.Delegate = this;
            PreferredContentSize = new CoreGraphics.CGSize(300, 100);
        }

        [Export("adaptivePresentationStyleForPresentationController:traitCollection:")]
        public UIModalPresentationStyle GetAdaptivePresentationStyle(UIPresentationController controller, UITraitCollection traitCollection)
        {
            return UIModalPresentationStyle.None;
        }

        public override void AwakeFromNib()
        {
            base.AwakeFromNib();

            // Set the initial value for the label
           //ClickedLabel.StringValue = "Button has not been clicked yet.";
        }
    }
}