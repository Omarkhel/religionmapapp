﻿using Client;
using CoreAnimation;
using Foundation;
using I18NPortable;
using System;
using UIKit;

namespace relig_ios
{
    public partial class FinishviewController : UIViewController
    {
        public FinishviewController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);


            var app = new App();
            I18N.Current.Locale = Settings.Lang;

            var gradientLayer = new CAGradientLayer();
            gradientLayer.Colors = new[] { Colors.ColorPrimary.CGColor, Colors.ColorGrenDark.CGColor };
            gradientLayer.Locations = new NSNumber[] { 0, 1 };
            gradientLayer.Frame = View.Frame;

            View.BackgroundColor = UIColor.Clear;
            View.Layer.InsertSublayer(gradientLayer, 0);

            lblfinish.Text = "str_finish".Translate();

            btnFinish.SetTitle("str_main".Translate(), UIControlState.Normal);
            btnFinish.Layer.BorderWidth = 1;

            btnFinish.TintColor = UIColor.White;

            btnFinish.Layer.BorderColor = UIColor.White.CGColor;


            btnFinish.TouchDown += (s, e) =>
            {
                Settings.FirstStart = false;
                Next();
            };

          

            void Next()
            {
                var hKController = this.Storyboard.InstantiateViewController("MapController") as MapController;

                this.NavigationController.PushViewController(hKController, true);
            }
        }
    }
}