﻿using Client.Models.Json;
using Client.Models.Json.Models;
using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios.Table
{
    internal class LocTable : UITableViewSource
    {

        private List<Loc> List;
        public static event EventHandler RowClicked = delegate { };

        public LocTable(List<Loc> _list)
        {
            this.List = _list;
        }

        

        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            RowClicked(List[indexPath.Row], EventArgs.Empty);
        }

        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            var cell = (LocCell)tableView.DequeueReusableCell("loc_cell", indexPath);
            var item = List[indexPath.Row];
            cell.UpdateCell(item);
            return cell;
        }

        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return List.Count;
        }

        public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
        {
            return 100f;
        }
    }
}