﻿using Client.Models.Json;
using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios.Table
{
    internal class FaqTableViewSourse : UITableViewSource
    {
        private List<Faq> list;
        public static event EventHandler RowClicked = delegate { };

        public FaqTableViewSourse(List<Faq> list)
        {
            this.list = list;
        }

        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            var cell = (FaqCell)tableView.DequeueReusableCell("faq_cell", indexPath);
            var faq = list[indexPath.Row];
            cell.UpdateCell(faq);
            return cell;
        }

        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return list.Count;
        }

        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            RowClicked(list[indexPath.Row], EventArgs.Empty);
        }
    }
}