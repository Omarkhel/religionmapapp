﻿using Client.Models;
using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios.Table
{
    internal class SettingTableSource : UITableViewSource
    {

        private List<LangModel> List;
        public static event EventHandler RowClicked = delegate { };

        public SettingTableSource(List<LangModel> _list)
        {
            this.List = _list;
        }

        

        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            RowClicked(List[indexPath.Row], EventArgs.Empty);
        }

        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            var cell = (SettingCell)tableView.DequeueReusableCell("setting_id", indexPath);
            var item = List[indexPath.Row];
            cell.UpdateCell(item);
            return cell;
        }

        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return List.Count;
        }

        public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
        {
            return 50f;
        }
    }
}