﻿using Client.Models.Json.Models;
using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios.Table
{
    public class SearchTableViewSourse : UITableViewSource
    {
        private List<Loc> list;
        public static event EventHandler RowClicked = delegate { };


        public SearchTableViewSourse(List<Loc> _list)
        {
            this.list = _list;
        }

        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            var cell = new UITableViewCell(UITableViewCellStyle.Default, "");
            cell.TextLabel.Text = list[indexPath.Row].Name;
            return cell;
        }

        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            RowClicked(list[indexPath.Row], EventArgs.Empty);
        }

        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return list.Count;
        }

   
    }

}