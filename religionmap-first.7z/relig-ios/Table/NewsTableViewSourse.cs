﻿using Client.Models.Json;
using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace relig_ios.Table
{
    internal class NewsTableViewSourse : UITableViewSource
    {
        private List<News> News;
        public static event EventHandler RowClicked = delegate { };

        public NewsTableViewSourse(List<News> News)
        {
            this.News = News;
        }

        

        public override void RowSelected(UITableView tableView, NSIndexPath indexPath)
        {
            RowClicked(News[indexPath.Row], EventArgs.Empty);
        }

        public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
        {
            var cell = (NewsCell)tableView.DequeueReusableCell("news_cell", indexPath);
            var NewItem = News[indexPath.Row];
            cell.UpdateCell(NewItem);
            return cell;
        }

        public override nint RowsInSection(UITableView tableview, nint section)
        {
            return News.Count;
        }

        public override nfloat GetHeightForRow(UITableView tableView, NSIndexPath indexPath)
        {
            return 80f;
        }
    }
}