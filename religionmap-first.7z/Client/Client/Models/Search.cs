﻿using Client.Models.Json;

namespace Client.Models
{
    public class Search
    {
        public bool isValide { get; set; }
        public Confess Confession { get; set; }
        public TypeConstruction Type { get; set; }
        public Region Region { get; set; }
    }
}
