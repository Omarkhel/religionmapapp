﻿namespace Client.Models.Json
{
    public class Feed
    {
        public bool Result { get; set; }
    }
}
