﻿namespace Client.Models.Json
{
    public class SubConfess
    {
        public int Id { get; set; }
        public int Protest { get; set; }
        public string Name { get; set; }
        public string Short_text { get; set; }
        public string Full_text { get; set; }
        public string Image { get; set; }
    }
}
