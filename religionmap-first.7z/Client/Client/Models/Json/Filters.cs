﻿using System.Collections.Generic;

namespace Client.Models.Json
{
    public class Filters
    {
        public List<Confess> Confess { get; set; }
        public List<TypeConstruction> Type { get; set; }
        public List<Region> Region { get; set; }
    }
}
