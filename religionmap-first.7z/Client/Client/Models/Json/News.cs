﻿namespace Client.Models.Json
{
    public class News
    {
        public int Id { get; set; }
        public int Created { get; set; }
        public int Updated { get; set; }
        public string Preview_text { get; set; }
        public string Preview_text_kz { get; set; }
        public string Title { get; set; }
        public string Title_kz { get; set; }
        public string Detail_text { get; set; }
        public string Detail_text_kz { get; set; }
        public string Date { get; set; }
        public int Active { get; set; }
        public int Type { get; set; }
        public string Image { get; set; }
    }
}
