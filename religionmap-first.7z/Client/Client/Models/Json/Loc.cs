﻿using System.Collections.Generic;

namespace Client.Models.Json.Models
{
	public class Loc
	{
		public int Id { get; set; }
		public int Status { get; set; }
		public string Name { get; set; }
		public string email { get; set; }
		public string phone { get; set; }
        public string Short_name { get; set; }
		public string Short_name_kz { get; set; }
		public string Confess_id { get; set; }
		public string Subconfess_id { get; set; }
		public string Address { get; set; }
		public string Contacts { get; set; }
		public int Region_id { get; set; }
		public int Type_id { get; set; }
		//public string Style_id { get; set; }
		//public string Icon_id { get; set; }
		public string Description { get; set; }
		public string Description_kz { get; set; }
		public string Hidden_text { get; set; }
		public string Hidden_text_kz { get; set; }
		public string Preview_text { get; set; }
		public string Preview_text_kz { get; set; }
		public string Missioners { get; set; }
		public string Map { get; set; }
		public string Image { get; set; }
		public string Iconpic { get; set; }
		public string Confession { get; set; }
        public List<People> People { get; set; }
	}
}