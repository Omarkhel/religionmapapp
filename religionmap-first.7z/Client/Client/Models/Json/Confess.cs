﻿namespace Client.Models.Json
{
    public class Confess
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Name_kz { get; set; }
        public string Short_text { get; set; }
        public string Short_text_kz { get; set; }
        public string Full_text { get; set; }
        public string Image { get; set; }
    }
}
