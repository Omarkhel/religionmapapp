﻿namespace Client.Models.Json
{
    public class TypeConstruction
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Name_kz { get; set; }
        public int Active { get; set; }
    }
}
