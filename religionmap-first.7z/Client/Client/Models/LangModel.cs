﻿namespace Client.Models
{
    public class LangModel
    {
        public string Title { get; set; }
        public string Lng { get; set; }
    }
}
