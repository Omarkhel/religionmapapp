﻿using I18NPortable;
using System.Diagnostics;
using System.Reflection;

namespace Client
{
    public class App
    {
        public App()
        {
            var currentAssembly = GetType().GetTypeInfo().Assembly;

            I18N
                .Current
                .SetLogger(text => Debug.WriteLine(text))
                .SetNotFoundSymbol("⛔")
                .SetFallbackLocale("en")
                .Init(currentAssembly);
        }
    }
}
