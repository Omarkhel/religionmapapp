﻿using Client.Models.Json;
using System.Collections.Generic;

namespace Client
{
    public class Syst
    {
        public static List<Confess> ConfessList(string lang)
        {
            var list = new List<Confess>();
            if (lang == "kz")
            {
                list.Add(new Confess { Id = 2, Name = "Христиандық" });
                list.Add(new Confess { Id = 5, Name = "Буддизм" });
                list.Add(new Confess { Id = 1, Name = "Ислам" });
                list.Add(new Confess { Id = 6, Name = "Иудей діні" });
                list.Add(new Confess { Id = 7, Name = "Жаңа діндер" });
                list.Add(new Confess { Id = 2, Name = "test" });
            }
            else
            {
                list.Add(new Confess { Id = 2, Name = "Христианство" });
                list.Add(new Confess { Id = 5, Name = "Буддизм" });
                list.Add(new Confess { Id = 1, Name = "Ислам" });
                list.Add(new Confess { Id = 6, Name = "Иудейская религия" });
                list.Add(new Confess { Id = 7, Name = "Новые религии" });
                list.Add(new Confess { Id = 2, Name = "test" });
            }
            return list;
        }

        public static double Lat = 43.25654;
        public static double Lon = 76.92848;

    }
}
