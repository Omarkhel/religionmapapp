﻿using Plugin.Settings;
using Plugin.Settings.Abstractions;

namespace Client
{
    public static class Settings
    {
        private static ISettings AppSettings
        {
            get
            {
                return CrossSettings.Current;
            }
        }

        #region Setting Constants

        private const string LangKey = "lang_key";
        private const string FirstStartKey = "first_key";

        #endregion


        public static bool FirstStart
        {
            get
            {
                return AppSettings.GetValueOrDefault(FirstStartKey, true);
            }
            set
            {
                AppSettings.AddOrUpdateValue(FirstStartKey, value);
            }
        }

        public static string Lang
        {
            get
            {
                return AppSettings.GetValueOrDefault(LangKey, "ru");
            }
            set
            {
                AppSettings.AddOrUpdateValue(LangKey, value);
            }
        }


    }
}
