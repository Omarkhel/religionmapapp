﻿namespace Client.Helper
{
    public class HtmlClean
    {
        public static string GetText(string html)
        {
            string res = html.Replace("&nbsp;", " ");
            res = res.Replace("&laquo;", "");
            res = res.Replace("&raquo;", "");
            res = res.Replace(@"\r\n\", "");
            res = res.Replace("&mdash;", "—");
            res = res.Replace("&thinsp;", "");
            res = res.Replace("&bdquo;", "„");
            res = res.Replace("&minus;", " - ");
            res = res.Replace("&ldquo;", "“");
            res = res.Replace("&ndash;", "—");
           


            return res;
        }
    }
}
