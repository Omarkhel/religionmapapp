﻿using I18NPortable;

namespace Client.Helper
{
    public class ConfesHelper
    {
        public static string Get(string id)
        {
            var app = new App();
            I18N.Current.Locale = Settings.Lang;


            string res = string.Empty;
            switch (id)
            {
                case "1":
                    res = "str_islam".Translate();
                    break;
                case "2":
                    res = "str_hrist".Translate();
                    break;
                case "6":
                    res = "str_iud".Translate();
                    break;
                case "7":
                    res = "str_newr".Translate();
                    break;
                case "5":
                    res = "str_b".Translate();
                    break;

            }
            return res;
        }

    }
}
