﻿using Client.Models;
using Client.Models.Json;
using Client.Models.Json.Models;
using Newtonsoft.Json;
using standart;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;


namespace Client
{
    public class Logic
    {
        private string Host = "http://religionmap.kz/";

        // FEEDBACK
        public Task<Feed> FeedBack(List<KeyValuePair<String, String>> pair, List<string> files)
        {
            return Task.Run(async () =>
            {
                string res = "";
                var url = $"{Host}css/api.php";
                using (var client = new HttpClient())
                {
                    var form = new MultipartFormDataContent();
                    foreach (var p in pair)
                    {
                        form.Add(new StringContent(p.Value), p.Key);
                    }
                    foreach (var file in files)
                    {
                        var streamContent = new StreamContent(File.OpenRead(file));
                        var imageContent = new ByteArrayContent(await streamContent.ReadAsByteArrayAsync());
                        imageContent.Headers.ContentType = MediaTypeHeaderValue.Parse("image/jpeg");
                        form.Add(imageContent, Path.GetFileName(file), Path.GetFileName(file));
                    }
                    var response = await client.PostAsync(url, form);
                    res = await response.Content.ReadAsStringAsync();
                }


                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<Feed>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // SEARCH LOCATIONS
        public Task<List<Loc>> SearchLocations(string lang, string q)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getloc?q={q}";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<List<Loc>>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET ITEM CONFESSION
        public Task<Confess> GetConfessItem(string lang, int Id)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getconf?id={Id}";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<Confess>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET ITEM PEOPLE
        public Task<People> GetPeopleItem(string lang, int Id)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getpeople?id={Id}";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<People>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET ITEM FAQ
        public Task<Faq> GetFaqItem(string lang, int Id)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getfaq?id={Id}";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<Faq>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET LIST FAQ
        public Task<List<Faq>> GetFaqList(string lang)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getfaq";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<List<Faq>>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET ITEM NEWS
        public Task<News> GetNewsItem(string lang, int id)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getnews?id={id}";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<News>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET LIST NEWS
        public Task<List<News>> GetNewsList(string lang)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getnews";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    var list = JsonConvert.DeserializeObject<List<News>>(res);
                    list = list.OrderByDescending(o => o.Id).ToList();
                    return list;
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET FILTERED LOCATIONS
        public Task<List<Loc>> GetFilteredLocations(string lang, int id)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getloc?confess_id={id}";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<List<Loc>>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET CONFESSIONS
        public Task<List<Confess>> GetConfessions(string lang)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getconf";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<List<Confess>>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET SUBCONFESSIONS
        public Task<List<SubConfess>> GetSubConfessions(string lang)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getsubconf";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<List<SubConfess>>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET LOCATION ITEM
        public Task<Loc> GetLocationItem(string lang, string id)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getloc?id={id}";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<Loc>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET LOCATIONS
        public Task<List<Loc>> GetLocations(string lang, Search param)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getloc?";

                url += param.Confession.Id == -1 ? "" : $"confess_id={param.Confession.Id}";
                url += param.Type.Id == -1 ? "" : $"&type_id={param.Type.Id}";
                url += param.Region.Id == -1 ? "" : $"&id={param.Region.Id}";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<List<Loc>>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        //// GET LOCATIONS
        //public Task<List<Loc>> GetConfessionsGroup(int group)
        //{
        //    var web = new Web();
        //    return Task.Run(async () =>
        //    {
        //        List<Loc> res = new List<Loc>();

        //        switch (group)
        //        {
        //            case 0:
        //                var l1 = await GetFilteredLocations(7);
        //                var l2 = await GetFilteredLocations(5);
        //                res.AddRange(l1);
        //                res.AddRange(l2);
        //                break;
        //        }

        //        return res;
        //    });
        //}


        // GET FILTERS
        public Task<Filters> GetFilters(string lang)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getfilters";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<Filters>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }

        // GET COORDINATES
        public Task<Filters> GetCoordinats(string lang)
        {
            var web = new Web();
            return Task.Run(async () =>
            {
                var url = $"{Host}{lang}/site/getfilters";
                var res = await web.GetRequestAsync(url);
                if (res == "error") return null;

                try
                {
                    return JsonConvert.DeserializeObject<Filters>(res);
                }
                catch (Exception ex)
                {
                    return null;
                }
            });
        }
    }

}
