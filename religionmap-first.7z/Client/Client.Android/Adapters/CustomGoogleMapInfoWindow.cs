﻿using Android.App;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Graphics;
using Android.Views;
using Android.Widget;
using FFImageLoading;
using FFImageLoading.Views;
using Square.Picasso;
using System.Threading.Tasks;

namespace Client.Droid.Adapters
{
    public class CustomGoogleMapInfoWindow : Java.Lang.Object, GoogleMap.IInfoWindowAdapter
    {
        private Activity m_context;
        private View m_View;
        private Marker m_currentMarker;


        public CustomGoogleMapInfoWindow(Activity context)
        {
            m_context = context;
            m_View = m_context.LayoutInflater.Inflate(Resource.Layout.custom_info_window, null);
        }

        public View GetInfoWindow(Marker marker)
        {
            //Use the default info window
            return null;
        }


        private Task<Bitmap> GetImg(string url)
        {
            return Task.Run(() =>
            {
                return Picasso
             .With(MainActivity._activity)
             .Load(url)
             .Resize(100, 100)
             .CenterInside()
             .OnlyScaleDown()
             .Get();
            });
        }

        public View GetInfoContents(Marker marker)
        {
            if (marker == null)
                return null;
            m_currentMarker = marker;

            var imgAction = (ImageView)m_View.FindViewById(Resource.Id.CustomGoogleMapInfoWindow_imageview);
            TextView textviewTitle = m_View.FindViewById<TextView>(Resource.Id.CustomGoogleMapInfoWindow_textview_title);


           var img =  GetImg("http://religionmap.kz" + marker.Snippet).Result;

            imgAction.SetImageBitmap(img);
            textviewTitle.Text = marker.Title;
            return m_View;
        }
    }
}