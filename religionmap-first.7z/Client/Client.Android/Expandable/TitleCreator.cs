﻿using System.Collections.Generic;
using Android.Content;

namespace Client.Droid.Expandable
{
    public class TitleCreator
    {
        static TitleCreator _titleCreator;
        List<TitleParent> _titleParents;

 

        public TitleCreator(Context _context)
        {
            _titleParents = new List<TitleParent>();
            for (int i = 1; i < 10; i++)
            {
                var title = new TitleParent
                {
                    Title = $"Caller {i}"
                };
                _titleParents.Add(title);
            }

        }


        public static TitleCreator Get(Context context)
        {
            if (_titleCreator == null)
                _titleCreator = new TitleCreator(context);
            return _titleCreator;
        }

        public List<TitleParent> GetAll
        {
            get { return _titleParents; }
        }
    }
}