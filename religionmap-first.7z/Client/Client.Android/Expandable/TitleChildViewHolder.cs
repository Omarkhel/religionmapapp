﻿using Android.Views;
using Android.Widget;
using XamDroid.ExpandableRecyclerView;

namespace Client.Droid.Expandable
{
    public class TitleChildViewHolder : ChildViewHolder
    {
        public TextView option1, option2;

        public TitleChildViewHolder(View itemView) : base(itemView)
        {
            option1 = itemView.FindViewById<TextView>(Resource.Id.childOption1);
            option2 = itemView.FindViewById<TextView>(Resource.Id.childOption2);
        }
    }
}