﻿namespace Client.Droid.Expandable
{
    public class TitleChild
    {
        public string Option1 { get; set; }
        public string Option2 { get; set; }

        public TitleChild(string option1,string option2)
        {
            Option1 = option1;
            Option2 = option2;
        }
    }
}