﻿using System.Collections.Generic;
using Android.Content;
using Android.Views;
using XamDroid.ExpandableRecyclerView;

namespace Client.Droid.Expandable
{
    public class MyExRecyclerViewAdapter : ExpandableRecyclerAdapter<TitleParentViewHolder, TitleChildViewHolder>
    {

        LayoutInflater inflater;

        public MyExRecyclerViewAdapter(Context context, List<IParentObject> itemList) : base(context, itemList)
        {
            inflater = LayoutInflater.From(context);
        }

        public override void OnBindChildViewHolder(TitleChildViewHolder childViewHolder, int position, object childObject)
        {
            var title = (TitleChild)childObject;
            childViewHolder.option1.Text = title.Option1;
            childViewHolder.option2.Text = title.Option2;
        }

        public override void OnBindParentViewHolder(TitleParentViewHolder parentViewHolder, int position, object parentObject)
        {
            var title = (TitleParent)parentObject;
            parentViewHolder._textView.Text = title.Title;
        }

        public override TitleChildViewHolder OnCreateChildViewHolder(ViewGroup childViewGroup)
        {
            var view = inflater.Inflate(Resource.Layout.list_child, childViewGroup, false);
            return new TitleChildViewHolder(view);
        }

        public override TitleParentViewHolder OnCreateParentViewHolder(ViewGroup parentViewGroup)
        {
            var view = inflater.Inflate(Resource.Layout.list_parent, parentViewGroup, false);
            return new TitleParentViewHolder(view);
        }

    }
}