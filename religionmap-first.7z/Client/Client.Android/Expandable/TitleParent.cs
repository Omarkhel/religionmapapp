﻿using System;
using System.Collections.Generic;
using XamDroid.ExpandableRecyclerView;

namespace Client.Droid.Expandable
{
    public class TitleParent : IParentObject
    {
        Guid _id;
        List<Object> _childrenList;

        public List<Object> ChildObjectList
        {
            get { return _childrenList; }
            set { _childrenList = value; }
        }

        public TitleParent()
        {
            _id = Guid.NewGuid();
        }

        public Guid Id
        {
            get { return _id; }
            private set { }
        }
        public string Title { get; set; }
    }
}