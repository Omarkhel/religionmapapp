﻿using Android.Views;
using Android.Widget;
using XamDroid.ExpandableRecyclerView;

namespace Client.Droid.Expandable
{
    public class TitleParentViewHolder : ParentViewHolder
    {
        public TextView _textView;
        public ImageButton _imageButton;

        public TitleParentViewHolder(View itemView) : base(itemView)
        {
            _textView = itemView.FindViewById<TextView>(Resource.Id.parentTitle);
            _imageButton = itemView.FindViewById<ImageButton>(Resource.Id.expandArrow);
        }
    }
}