using Android.Gms.Maps.Model;
using Com.Google.Maps.Android.Clustering;
using System;

namespace Client.Droid.Models
{
    public class ClusterItem : Java.Lang.Object, IClusterItem
    {
        public LatLng Position { get; set; }
        public string Snippet { get; set; }
        public string Title { get; set; }
        public int MarkerIcon { get; set; }
        public string Image { get; set; }


        public ClusterItem(double lat, double lon)
        {
            Position = new LatLng(lat, lon);
        }

        public ClusterItem(IntPtr handle, Android.Runtime.JniHandleOwnership transfer)
        : base(handle, transfer)
        {
        }
    }
}