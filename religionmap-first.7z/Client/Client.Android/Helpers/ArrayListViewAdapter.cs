﻿using System.Collections.Generic;
using Android.Content;
using Android.Views;
using Android.Widget;

namespace Client.Droid.Helpers
{
    public class ArrayListViewAdapter : BaseAdapter<string>
    {
        private List<string> mItems;
        private Context mContext;

        public ArrayListViewAdapter(Context context, List<string> items)
        {
            mItems = items;
            mContext = context;
        }

        public override int Count
        {
            get { return mItems.Count; }
        }

        public override long GetItemId(int position)
        {

            return position;
        }


        public override string this[int position]
        {
            get { return mItems[position]; }

        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {

            View row = convertView;
            if (row == null)
            {
                row = LayoutInflater.From(mContext).Inflate(Resource.Layout.listview_row, null, false);

            }
            TextView txName = row.FindViewById<TextView>(Resource.Id.arrayName);
            txName.Text = mItems[position];
            return row;
        }
    }

}