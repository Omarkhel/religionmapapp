﻿using System;
using System.Collections.Generic;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using Client.Models.Json;
using Client.Models.Json.Models;
using FFImageLoading;
using FFImageLoading.Views;
using I18NPortable;

namespace Client.Droid
{

    public class NewsAdapter : RecyclerView.Adapter
    {

        private List<News> dataSet;

        public event EventHandler<News> eventHandler;


        public class ViewHolder : RecyclerView.ViewHolder
        {
            public View view { get; set; }
            public TextView tvName,tvDate;
            public ImageViewAsync img;

            public ViewHolder(View v, Action<int> eventHandler) : base(v)
            {
                this.view = v;
                //view.FindViewById<TextView>(Resource.Id.NItvAdded).Text = "str_added".Translate();
                tvName = (TextView)v.FindViewById(Resource.Id.NtvName);
                tvDate = (TextView)v.FindViewById(Resource.Id.NtvDate);
                img = (ImageViewAsync)v.FindViewById(Resource.Id.Nimg);



                view.Click += (sender, e) => eventHandler(AdapterPosition);
            }
        }

        public NewsAdapter(List<News> dataSet)
        {
            this.dataSet = dataSet;
        }


        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup viewGroup, int position)
        {
            var animAlpha = AnimationUtils.LoadAnimation(MainActivity._activity, Resource.Animation.alpha);
            View v = LayoutInflater.From(viewGroup.Context)
                .Inflate(Resource.Layout.row_new, viewGroup, false);
            ViewHolder vh = new ViewHolder(v, clickEvent);

            return vh;
        }

        public void clickEvent(int position)
        {
            if (eventHandler != null)
                eventHandler(this, dataSet[position]);
        }


        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            var vh = (viewHolder as ViewHolder);

            vh.tvName.SetText(dataSet[position].Title, TextView.BufferType.Normal);
            vh.tvDate.SetText(dataSet[position].Date, TextView.BufferType.Normal);

            ImageService.Instance.LoadUrl($"http://religionmap.kz{dataSet[position].Image}")
    .Retry(3, 200)
    //.DownSample(100, 100)
    .LoadingPlaceholder("drawable/ic_placeholder.png", FFImageLoading.Work.ImageSource.CompiledResource)
    //.ErrorPlaceholder("Images/ic_error.png", FFImageLoading.Work.ImageSource.ApplicationBundle)
    .Into(vh.img);
        }

        public override int ItemCount
        {
            get { return dataSet.Count; }
        }
    }
}