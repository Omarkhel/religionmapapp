﻿using System;
using System.Collections.Generic;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using Client.Models.Json.Models;
using FFImageLoading;
using FFImageLoading.Views;

namespace Client.Droid
{

    public class ResultAdapter : RecyclerView.Adapter
    {

        private List<Loc> dataSet;

        public event EventHandler<Loc> eventHandler;


        public class ViewHolder : RecyclerView.ViewHolder
        {
            public View view { get; set; }
            public TextView tvName;
            public TextView tvAdress;
            public TextView tvPhone;
            public TextView tvDistance;
            public ImageViewAsync imgPhoto;

            public ViewHolder(View v, Action<int> eventHandler) : base(v)
            {
                this.view = v;
                tvName = (TextView)v.FindViewById(Resource.Id.RtvName);
                tvAdress = (TextView)v.FindViewById(Resource.Id.RtvAdsress);
                tvDistance = (TextView)v.FindViewById(Resource.Id.RtvDistance);
                tvPhone = (TextView)v.FindViewById(Resource.Id.RtvPhone);

                imgPhoto = (ImageViewAsync)v.FindViewById(Resource.Id.RimgPhoto);

                view.Click += (sender, e) => eventHandler(AdapterPosition);
            }
        }

        public ResultAdapter(List<Loc> dataSet)
        {
            this.dataSet = dataSet;
        }


        // Create new views (invoked by the layout manager)
        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup viewGroup, int position)
        {
            var animAlpha = AnimationUtils.LoadAnimation(MainActivity._activity, Resource.Animation.alpha);
            View v = LayoutInflater.From(viewGroup.Context)
                .Inflate(Resource.Layout.row_result, viewGroup, false);
            ViewHolder vh = new ViewHolder(v, clickEvent);

            return vh;
        }

        public void clickEvent(int position)
        {
            if (eventHandler != null)
                eventHandler(this, dataSet[position]);
        }


        public override void OnBindViewHolder(RecyclerView.ViewHolder viewHolder, int position)
        {
            var vh = (viewHolder as ViewHolder);

            vh.tvName.SetText(dataSet[position].Name, TextView.BufferType.Normal);
            vh.tvAdress.SetText(dataSet[position].Address, TextView.BufferType.Normal);
            vh.tvPhone.SetText(dataSet[position].Contacts, TextView.BufferType.Normal);
            vh.tvDistance.SetText(dataSet[position].Map, TextView.BufferType.Normal);

            try
            {
                ImageService.Instance.LoadUrl($"http://religionmap.kz{dataSet[position].Image}")
             .Retry(3, 200)
             .DownSample(100, 100)
             .LoadingPlaceholder("drawable/ic_placeholder.png", FFImageLoading.Work.ImageSource.CompiledResource)
             .Into(vh.imgPhoto);
            }
            catch (Exception) { }
        }

        public override int ItemCount
        {
            get { return dataSet.Count; }
        }
    }
}