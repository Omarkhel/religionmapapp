﻿using System;
using System.Collections.Generic;
using Android.Content;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Widget;
using Client.Models;
using FFImageLoading;
using FFImageLoading.Views;

namespace Client.Droid.Helpers
{
    //public class DiscountAdapter : RecyclerView.Adapter
    //{
    //    public event EventHandler<Discounts> ClickItem;
    //    public event EventHandler<Discounts> ClickCart;

    //    private List<object> lstData = new List<object>();
    //    private Context ctx;
    //    private static int TYPE_HEADER = 0;
    //    private static int TYPE_ITEM = 2;


    //    public DiscountAdapter(List<object> lstData, Context ctx)
    //    {
    //        this.lstData = lstData;
    //        this.ctx = ctx;
    //    }

    //    public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
    //    {
    //        if (lstData[position] is string)
    //        {
    //            HeaderViewHolder headerHolder = holder as HeaderViewHolder;
    //            headerHolder.headerTitle.Text = lstData[position].ToString();
    //        }
    //        else
    //        {
    //            RecyclerViewHolder viewHolder = holder as RecyclerViewHolder;
    //            var item = lstData[position] as Discounts;
    //            viewHolder.tvPrice.Text = $"{item.price} ₽";
    //            viewHolder.tvName.Text = item.name;
    //            viewHolder.imgCart.SetImageResource(item.img_cart);
    //            //viewHolder.tvDate.Text = item.;

    //            ImageService.Instance.LoadUrl(item.img)
    //         .Retry(3, 200)
    //         .DownSample(100, 100)
    //         .LoadingPlaceholder("drawable/ic_placeholder.png", FFImageLoading.Work.ImageSource.CompiledResource)
    //         .Into(viewHolder.imgMain);

    //        }
    //    }

    //    public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
    //    {

    //        if (viewType == TYPE_ITEM)
    //        {
    //            LayoutInflater inflater = LayoutInflater.From(parent.Context);
    //            View itemView = inflater.Inflate(Resource.Layout.row_discounts, parent, false);

    //            var vh = new RecyclerViewHolder(itemView, ctx, ItemClick);
    //            return vh;
    //        }
    //        else if (viewType == TYPE_HEADER)
    //        {
    //            LayoutInflater inflater = LayoutInflater.From(parent.Context);
    //            View itemView = inflater.Inflate(Resource.Layout.adapter_expandable_listview_header, parent, false);
    //            return new HeaderViewHolder(itemView, ctx);
    //        }
    //        else return null;
    //    }

    //    // Get Number Of Items
    //    public override int ItemCount
    //    {
    //        get { return lstData.Count; }
    //    }

    //    public override int GetItemViewType(int position)
    //    {
    //        if (lstData[position] is string)
    //        {
    //            return TYPE_HEADER;
    //        }
    //        else
    //        {
    //            return TYPE_ITEM;
    //        }
    //    }

    //    #region Events

    //    public void ItemClick(int id, int position)
    //    {
    //        if (ClickItem != null)
    //        {
    //            var item = lstData[position] as Discounts;
    //            switch (id)
    //            {
    //                case 0:
    //                    ClickItem(this, item);
    //                    break;
    //                case 1:
    //                    ClickCart(this, item);
    //                    break;
    //            }
    //        }
    //    }
    //    //public void CartClick(int position)
    //    //{
    //    //    if (ClickCart != null)
    //    //    {
    //    //        var item = lstData[position] as Discounts;
    //    //        ClickCart(this, item);
    //    //    }
    //    //}
    //    #endregion
    //}

    //// class for header
    //public class HeaderViewHolder : RecyclerView.ViewHolder
    //{
    //    public TextView headerTitle;
    //    public ImageView headerImageView;

    //    public HeaderViewHolder(View itemView, Context ctx) : base(itemView)
    //    {
    //        headerTitle = itemView.FindViewById<TextView>(Resource.Id.adapter_expandable_listview_header_textview);
    //    }
    //}

    //public class RecyclerViewHolder : RecyclerView.ViewHolder
    //{
    //    public ImageViewAsync imgMain { get; set; }

    //    public View view { get; set; }
    //    public ImageView imgCart { get; set; }
    //    public TextView tvName { get; set; }
    //    public TextView tvDate { get; set; }
    //    public TextView tvPrice { get; set; }
    //    private Context ctx;


    //    public RecyclerViewHolder(View itemView, Context ctx, Action<int, int> eventHandler) : base(itemView)
    //    {
    //        this.view = itemView;
    //        this.ctx = ctx;
    //        imgCart = itemView.FindViewById<ImageView>(Resource.Id.imgCart);
    //        imgMain = itemView.FindViewById<ImageViewAsync>(Resource.Id.imgDItem);
    //        tvName = itemView.FindViewById<TextView>(Resource.Id.tvDName);
    //        tvDate = itemView.FindViewById<TextView>(Resource.Id.tvDDate);
    //        tvPrice = itemView.FindViewById<TextView>(Resource.Id.tvDPrice);
    //        view.Click += (sender, e) => eventHandler(0, AdapterPosition);
    //        imgCart.Click += (sender, e) => eventHandler(1, AdapterPosition);
    //    }


    //}

}