﻿using Java.Util;

namespace Client.Droid.Helpers
{
    public class Lang
    {
        public static string Get1()
        {
            var lang = Locale.Default.Country.ToLower();
            return (lang == "kz")? "kz" : "ru";
        }
    }
}