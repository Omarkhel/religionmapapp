﻿using Android.App;
using I18NPortable;

namespace Client.Droid.Helpers
{
    public class Flip
    {
        ProgressDialog progress;

        public Flip()
        {
            progress = new ProgressDialog(MainActivity._activity);
            progress.SetMessage("str_wait".Translate());
            progress.SetCanceledOnTouchOutside(false);
            progress.SetProgressStyle(ProgressDialogStyle.Spinner);

        }


        public void Show()
        {
            progress.Show();
        }

        public void Dismis()
        {
            progress.Dismiss();
        }
    }
}