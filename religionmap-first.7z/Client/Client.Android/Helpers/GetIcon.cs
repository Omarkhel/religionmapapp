﻿namespace Client.Droid.Helpers
{
    public class GetIcon
    {
        public static int Get(string id)
        {
            int icon = Resource.Drawable.ic_pin_other;

            switch (id)
            {
                case "5":
                    icon = Resource.Drawable.ic__new;
                    break;
                case "7":
                    icon = Resource.Drawable.ic__new;
                    break;
                case "6":
                    icon = Resource.Drawable.icon_iud;
                    break;
                case "1":
                    icon = Resource.Drawable.m_1;
                    break;
                case "2":
                    icon = Resource.Drawable.m_2;
                    break;
            }
            return icon;
        }
    }
}