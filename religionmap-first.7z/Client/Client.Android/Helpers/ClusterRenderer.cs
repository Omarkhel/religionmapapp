﻿using Android.App;
using Android.Content;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Graphics;
using Android.Views;
using Android.Widget;
using Client.Droid.Models;
using Com.Google.Maps.Android.Clustering;
using Com.Google.Maps.Android.Clustering.View;
using Com.Google.Maps.Android.UI;

namespace Client.Droid.Helpers
{
    public class ClusterRenderer : DefaultClusterRenderer
    {
        private IconGenerator m_iconGeneratorForMarkerGroup;
        private ImageView m_imageviewForMarkerGroup;
        Context _context;

        public ClusterRenderer(Activity context, GoogleMap map, ClusterManager clusterManager)
            : base(context, map, clusterManager)
        {
            _context = context;


            InitViewForMarkerGroup(context);
        }

        private void InitViewForMarkerGroup(Activity context)
        {
            //Retrieve views from AXML to display groups of markers (clustering)
            View viewMarkerClusterGrouped = context.LayoutInflater.Inflate(Resource.Layout.marker_cluster_grouped, null);
            m_imageviewForMarkerGroup = viewMarkerClusterGrouped.FindViewById<ImageView>(Resource.Id.marker_cluster_grouped_imageview);

            //Configure the groups of markers icon generator with the view. The icon generator will be used to display the marker's picture with a text
            m_iconGeneratorForMarkerGroup = new IconGenerator(context);
            m_iconGeneratorForMarkerGroup.SetContentView(viewMarkerClusterGrouped);
            m_iconGeneratorForMarkerGroup.SetBackground(null);
        }

        //Draw a single marker
        protected override void OnBeforeClusterItemRendered(Java.Lang.Object p0, MarkerOptions markerOptions)
        {
            var p = p0 as ClusterItem;
            markerOptions.SetIcon(BitmapDescriptorFactory.FromResource(p.MarkerIcon));
            markerOptions.SetTitle(markerOptions.Title);
        }

        //Draw a grouped marker
        protected override void OnBeforeClusterRendered(ICluster p0, MarkerOptions markerOptions)
        {
            string sNumberOfMarkersGrouped = p0.Size.ToString();
            m_imageviewForMarkerGroup.SetImageResource(Resource.Drawable.ic_cluster);
            Bitmap icon = m_iconGeneratorForMarkerGroup.MakeIcon(sNumberOfMarkersGrouped);
            markerOptions.SetIcon(BitmapDescriptorFactory.FromBitmap(icon));
        }
    }
}