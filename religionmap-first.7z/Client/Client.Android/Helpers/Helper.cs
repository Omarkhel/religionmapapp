﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Client.Droid.Helpers
{
    public class Helper
    {

        public static string DB_PATH = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "base.db");


        //public ProgressDialog Progress(Context context)
        //{
        //    var progress = new ProgressDialog(context);
        //    progress.SetMessage(context.GetString(Resource.String.str_wait));
        //    progress.SetCanceledOnTouchOutside(false);
        //    progress.SetProgressStyle(ProgressDialogStyle.Spinner);
        //    return progress;
        //}


        //public AlertDialog Progress(Context context)

        //{
        //    var dlgAlert = (new AlertDialog.Builder(context)).Create();
        //    dlgAlert.SetCanceledOnTouchOutside(false);
        //    var MainLinear = new LinearLayout(context) { Orientation = Orientation.Horizontal };
        //    var PB = new ProgressBar(context);
        //    var Description = new TextView(context) { Text = context.GetString(Resource.String.str_wait)};
        //    var LayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WrapContent, ViewGroup.LayoutParams.WrapContent);
        //    LayoutParams.Gravity = GravityFlags.Center;
        //    LayoutParams.LeftMargin = 5;
        //    LayoutParams.TopMargin = 5;
        //    LayoutParams.BottomMargin = 5;
        //    PB.LayoutParameters = LayoutParams;
        //    Description.LayoutParameters = LayoutParams;
        //    MainLinear.AddView(PB);
        //    MainLinear.AddView(Description);
        //    dlgAlert.SetView(MainLinear);
        //    return dlgAlert;
        //}

        // SET EDITTEXT ERROR
        public void EdittextSetError(Context context, EditText et, string message)
        {
            Drawable img;
            if (Build.VERSION.SdkInt < BuildVersionCodes.LollipopMr1)
                img = context.Resources.GetDrawable(Resource.Drawable.ic_error);
            else
                img = context.GetDrawable(Resource.Drawable.ic_error);

            img.SetBounds(0, 0, 30, 30);
            et.SetCompoundDrawables(null, null, img, null);
            et.SetError(message, null);
        }

        // SET EDITTEXT ERROR
        public void EdittextSetError(EditText et, bool show)
        {
            if (!show)
            {
                et.SetCompoundDrawables(null, null, null, null);
            }
        }

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToLocalTime();
            return dtDateTime;
        }
    }
}