﻿using Android.App;
using Android.OS;
using Android.Content;
using Android.Support.V7.App;
using Android.Support.V4.Widget;
using Android.Views;
using Android.Support.Design.Widget;
using Android.Content.PM;
using Android.Support.V4.View;
using Android.Views.InputMethods;
using System.Collections.Generic;
using System.Linq;
using Android.Widget;
using I18NPortable;
using System;
using Plugin.CurrentActivity;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;

namespace Client.Droid
{
    [Activity(Label = "@string/app_name", LaunchMode = LaunchMode.SingleTop, Icon = "@drawable/logo")]
    public class MainActivity : AppCompatActivity
    {
        public DrawerLayout drawerLayout;
        NavigationView navigationView;
        public static MainActivity _activity;

        IMenuItem previousItem;
        public static Android.Support.V7.App.ActionBarDrawerToggle mDrawerToggle;
        public static List<Android.Support.V4.App.Fragment> ListFragments = new List<Android.Support.V4.App.Fragment>();

        private void Translate(View view)
        {
            try
            {
                view.FindViewById<TextView>(Resource.Id.navtvDescr).Text = "str_description".Translate();
                view.FindViewById<TextView>(Resource.Id.navtvRegion).Text = "str_region".Translate();
                view.FindViewById<Button>(Resource.Id.btnMenu).Text = "str_relig_socium".Translate();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void TranslateMenu(IMenu menu)
        {
            try
            {
                menu.FindItem(Resource.Id.nav_about).SetTitle("str_about".Translate());
                menu.FindItem(Resource.Id.nav_news).SetTitle("str_news".Translate());
                menu.FindItem(Resource.Id.nav_setting).SetTitle("str_setting".Translate());
                menu.FindItem(Resource.Id.nav_bid).SetTitle("str_bid".Translate());
                menu.FindItem(Resource.Id.nav_missioner).SetTitle("str_missioner".Translate());
                menu.FindItem(Resource.Id.nav_conf).SetTitle("str_cofesss".Translate());
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Android.Content.PM.Permission[] grantResults)
        {
            Plugin.Permissions.PermissionsImplementation.Current.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            _activity = this;

            AppCenter.Start("dba25754-d90f-4ce7-add5-e1561f5699fe",
                   typeof(Analytics), typeof(Crashes));
            AppCenter.Start("dba25754-d90f-4ce7-add5-e1561f5699fe", typeof(Analytics), typeof(Crashes));

            RequestedOrientation = ScreenOrientation.Portrait;

            //throw new System.ArgumentException("Parameter cannot be null", "original");

            var app = new App();
            I18N.Current.Locale = Settings.Lang;
            SetContentView(Resource.Layout.main);
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar);
            if (toolbar != null)
            {
                SetSupportActionBar(toolbar);
                SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                SupportActionBar.SetHomeButtonEnabled(true);
            }

            drawerLayout = FindViewById<DrawerLayout>(Resource.Id.drawer_layout);
            SupportActionBar.SetHomeAsUpIndicator(Resource.Drawable.ic_menu);
            mDrawerToggle = new Android.Support.V7.App.ActionBarDrawerToggle(this, drawerLayout, Resource.Drawable.ic_menu, Resource.Drawable.ic_back);
            navigationView = FindViewById<NavigationView>(Resource.Id.nav_view);

            CrossCurrentActivity.Current.Init(this, savedInstanceState);



            View headerView = navigationView.GetHeaderView(0);
            Translate(headerView);

            var menu = navigationView.Menu;
            TranslateMenu(menu);

            var btn = (Button)headerView.FindViewById(Resource.Id.btnMenu);
            btn.Click += (s, e) =>
            {
                ListItemClicked(0);
                drawerLayout.CloseDrawers();
            };

            navigationView.NavigationItemSelected += (sender, e) =>
            {
                if (previousItem != null)
                    previousItem.SetChecked(false);

                navigationView.SetCheckedItem(e.MenuItem.ItemId);

                previousItem = e.MenuItem;

                switch (e.MenuItem.ItemId)
                {

                    case Resource.Id.nav_about:
                        ListItemClicked(1);
                        break;
                    case Resource.Id.nav_news:
                        ListItemClicked(2);
                        break;
                    case Resource.Id.nav_faq:
                        ListItemClicked(3);
                        break;
                    case Resource.Id.nav_setting:
                        ListItemClicked(4);
                        break;
                    case Resource.Id.nav_bid:
                        ListItemClicked(5);
                        break;
                    case Resource.Id.nav_missioner:
                        ListItemClicked(6);
                        break;
                    case Resource.Id.nav_conf:
                        ListItemClicked(7);
                        break;
                }


                drawerLayout.CloseDrawers();
            };


            if (savedInstanceState == null)
            {
                //navigationView.SetCheckedItem(Resource.Id.nav_actions);
                ListItemClicked(0);
            }

        }

        protected override void OnResume()
        {
            base.OnResume();
            //SetAlarm(this);
        }

        int oldPosition = -1;
        private void ListItemClicked(int position)
        {
            if (position == oldPosition)
                return;

            oldPosition = position;


            Android.Support.V4.App.Fragment fragment = null;
            switch (position)
            {
                case -2:
                    fragment = Fragments.FragmentStart.NewInstance();
                    break;
                case 0:
                    fragment = Fragments.FragmentMaps.NewInstance();
                    break;
                case 1:
                    fragment = Fragments.FragmentAbout.NewInstance();
                    //fragment = Fragments.FragmentWeb.NewInstance("file:///android_asset/about.html", "str_about".Translate());
                    break;
                case 2:
                    fragment = Fragments.FragmentNews.NewInstance();
                    break;
                case 3:
                    fragment = Fragments.FragmentFaq.NewInstance();
                    break;
                case 4:
                    fragment = Fragments.FragmentSetting.NewInstance();
                    break;
                case 5:
                    fragment = Fragments.FragmentFeedback.NewInstance();
                    break;

                case 6:
                    fragment = Fragments.FragmentWeb.NewInstance("http://religionmap.kz/ru/pages/missioners", "str_missioner".Translate());

                    break;

                    case 7:
                        fragment = Fragments.FragmentConfess.NewInstance();
                        break;

            }
            SupportFragmentManager.BeginTransaction()
                .Replace(Resource.Id.content_frame, fragment)
                .Commit();
        }




        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    if (ListFragments.Count > 0)
                        OnBackPressed();
                    else
                        drawerLayout.OpenDrawer(GravityCompat.Start);
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }


        public override bool DispatchTouchEvent(MotionEvent ev)
        {
            if (ev.Action == MotionEventActions.Down)
            {
                var inputManager = (InputMethodManager)GetSystemService(Context.InputMethodService);
                var currentFocus = CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            return base.DispatchTouchEvent(ev);
        }


        public void Go(Android.Support.V4.App.Fragment fragment)
        {
            mDrawerToggle.DrawerIndicatorEnabled = false;
            var lastFragment = SupportFragmentManager.Fragments.Last();
            ListFragments.Add(lastFragment);
            SupportFragmentManager.BeginTransaction()
                .Replace(Resource.Id.content_frame, fragment)
                .Commit();
        }

        public void Frag(Android.Support.V4.App.Fragment fragment, int num)
        {
            navigationView.Menu.GetItem(num).SetChecked(true);
            SupportFragmentManager.BeginTransaction()
                .Replace(Resource.Id.content_frame, fragment)
                .Commit();
        }

        public override void OnBackPressed()
        {

            if (ListFragments.Count > 0)
            {
                var item = ListFragments.Last();
                SupportFragmentManager.BeginTransaction()
               .Replace(Resource.Id.content_frame, item)
               .Commit();
                ListFragments.Remove(ListFragments.Last());
            }
            if (ListFragments.Count == 0)
            {
                mDrawerToggle.DrawerIndicatorEnabled = true;
            }
        }



    }


}

