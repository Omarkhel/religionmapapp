using Android.Content;
using Android.Net;
using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using Client.Droid.Helpers;
using Client.Models.Json.Models;
using FFImageLoading;
using FFImageLoading.Views;
using I18NPortable;

namespace Client.Droid.Fragments
{
    public class FragmentConfessionItem : Fragment
    {
        private static Loc itemData;
        private static string Id { get; set; }

        ImageViewAsync image, icon;
        TextView tvTitle, tvAdress, tvEmail, tvRoute, tvPhone, tvLeader;


        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentConfessionItem NewInstance(Loc _loc, string id)
        {
            itemData = _loc;
            Id = id;
            var frag = new FragmentConfessionItem { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.CItvRoute).Text = "str_route".Translate();
            view.FindViewById<TextView>(Resource.Id.CItvLeader).Text = "str_leaders".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_confession_item, container, false);

            Translate(view);

            image = (ImageViewAsync)view.FindViewById(Resource.Id.CIimg);
            icon = (ImageViewAsync)view.FindViewById(Resource.Id.CIicon);
            tvTitle = (TextView)view.FindViewById(Resource.Id.CItvTitle);

            tvAdress = (TextView)view.FindViewById(Resource.Id.CItvAdress);

            tvRoute = (TextView)view.FindViewById(Resource.Id.CItvRoute);
            tvRoute.Click += (s, e) =>
             {

                 try
                 {
                     Intent intent = new Intent(Android.Content.Intent.ActionView, Uri.Parse("geo:" + itemData.Map));
                     StartActivity(intent);
                 }
                 catch (System.Exception)
                 {


                 }


             };



            tvEmail = (TextView)view.FindViewById(Resource.Id.CItvEmail);
            tvPhone = (TextView)view.FindViewById(Resource.Id.CItvPhone);

            tvLeader = (TextView)view.FindViewById(Resource.Id.CItvLeaders);

            tvLeader.Click += (s, e) =>
            {
                ((MainActivity)Activity).Go(FragmentLiderItem.NewInstance(itemData.People[0].Id, itemData.People[0].Name));

            };

            return view;
        }

        public async override void OnResume()
        {
            base.OnResume();
            if (itemData == null)
            {
                var logic = new Logic();
                var flip = new Flip();
                flip.Show();
                var res = await logic.GetLocationItem(Settings.Lang, Id);
                if (res == null)
                    return;
                itemData = res;
            }

            ((MainActivity)Activity).SupportActionBar.Show();
            ((MainActivity)Activity).SupportActionBar.Title = itemData.Confession;

            ImageService.Instance.LoadUrl($"http://religionmap.kz{itemData.Iconpic}")
            //.LoadingPlaceholder("drawable/ic_placeholder.png", FFImageLoading.Work.ImageSource.CompiledResource)
            .Into(icon);

            ImageService.Instance.LoadUrl($"http://religionmap.kz{itemData.Image}")
            .LoadingPlaceholder("drawable/ic_placeholder.png", FFImageLoading.Work.ImageSource.CompiledResource)
            .Into(image);

            tvLeader.Text = itemData.People[0].Name;
            tvTitle.Text = itemData.Name;
            tvAdress.Text = itemData.Address;


            tvPhone.Text = itemData.phone;
            tvEmail.Text = itemData.email;

        }
    }
}