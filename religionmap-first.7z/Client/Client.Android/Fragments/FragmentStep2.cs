using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using I18NPortable;

namespace Client.Droid.Fragments
{
    public class FragmentStep2 : Fragment
    {
        RecyclerView recyclerView;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentStep2 NewInstance()
        {
            var frag = new FragmentStep2 { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.step2tvNext).Text = "str_step2".Translate();
            view.FindViewById<Button>(Resource.Id.step2BtnNext).Text = "str_sled".Translate();
            view.FindViewById<TextView>(Resource.Id.step2Skip).Text = "str_skip".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_step2, container, false);
            var animAlpha = AnimationUtils.LoadAnimation(Context, Resource.Animation.alpha);
            var btnNext = view.FindViewById<Button>(Resource.Id.step2BtnNext);
            Translate(view);
            btnNext.Click += (s, e) =>
            {
                btnNext.StartAnimation(animAlpha);

                ((ActivityWelcome)Activity).Go(new FragmentFinish());
            };

            var btnSkip = view.FindViewById<TextView>(Resource.Id.step2Skip);

            btnSkip.Click += (s, e) =>
            {
                btnSkip.StartAnimation(animAlpha);
                Settings.FirstStart = false;
                Context.StartActivity(typeof(MainActivity));
            };

            return view;
        }



        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
        }


        public override void OnResume()
        {
            base.OnResume();
        }
    }
}