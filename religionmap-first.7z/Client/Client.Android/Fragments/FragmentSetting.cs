using Android.Content;
using Android.Content.Res;
using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using I18NPortable;
using Java.Util;
using System;


namespace Client.Droid.Fragments
{
    public class FragmentSetting : Fragment
    {
        Spinner spinLang;
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentSetting NewInstance()
        {
            var frag = new FragmentSetting { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.settvLang).Text = "str_lang".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_setting, container, false);
            Translate(view);
            spinLang = view.FindViewById<Spinner>(Resource.Id.spinLangSelect);
            return view;
        }

        public override void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Title = "str_setting".Translate();
            ((MainActivity)Activity).SupportActionBar.Show();
            var adapter = ArrayAdapter.CreateFromResource(
                    Activity, Resource.Array.lang_array, Android.Resource.Layout.SimpleSpinnerItem);

            adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            spinLang.Adapter = adapter;
            var s2 = Settings.Lang;
            int lang = (Settings.Lang == "ru") ? 0 : 1;
            spinLang.SetSelection(lang,false);
            spinLang.ItemSelected += (s, e) =>
             {
                 var spinner = s as Spinner;
                 switch (spinner.SelectedItemPosition)
                 {
                     case 0:
                         Settings.Lang = "ru";
                         break;
                     case 1:
                         Settings.Lang = "kz";
                         break;
                 }
                 Intent intent = new Intent(MainActivity._activity, typeof(MainActivity));
                 intent.AddFlags(ActivityFlags.NoAnimation);
                 MainActivity._activity.Finish();
                 StartActivity(intent);
                 //ChangeLang(Settings.Lang);
             };
        }
        private void ChangeLang(string lang)
        {
            Settings.Lang = lang;
            Settings.FirstStart = false;
            var locale = new Locale(lang);
            Locale.Default = locale;
            var config = new Configuration();
            config.Locale = locale;
            this.Resources.UpdateConfiguration(config, null);
            Intent intent = new Intent(MainActivity._activity, typeof(MainActivity));
            intent.AddFlags(ActivityFlags.NoAnimation);
            MainActivity._activity.Finish();
            StartActivity(intent);
        }
    }
}