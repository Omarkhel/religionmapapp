using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.App;
using Android.Support.V4.View;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using Client.Droid.Adapters;
using Client.Droid.Helpers;
using Client.Droid.Models;
using Client.Models;
using Client.Models.Json;
using Client.Models.Json.Models;
using Com.Google.Maps.Android.Clustering;
using I18NPortable;
using Plugin.Geolocator;
using Plugin.Geolocator.Abstractions;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Client.Droid.Fragments
{
    public class FragmentMaps : Fragment, IOnMapReadyCallback, ClusterManager.IOnClusterItemInfoWindowClickListener
    {
        private static bool SearchList { get; set; }

        private static List<Loc> Locations { get; set; }
        private static CameraUpdate camera { get; set; }
        private static ClusterRenderer m_ClusterRenderer;
        RecyclerView recyclerView;

        TextView tvFounded;
        static MapView mMapView;
        private static GoogleMap GMap;
        private Position _currentPosition;
        LinearLayout searchBar, bottomPanel, bottomPanelSearch, filterPanel;
        ImageView floatingMenu, floatingPlus, floatingMinus, floatingCompass, floatingShowBottom;
        Animation animAlpha, slide_down, slide_up;
        Logic logic = new Logic();
        AutoCompleteTextView etSearch;

        Search data = new Search
        {
            Confession = new Confess { Id = -1 },
            Region = new Region { Id = -1 },
            Type = new TypeConstruction { Id = -1 }
        };

        public override void OnViewStateRestored(Bundle savedInstanceState)
        {
            base.OnViewStateRestored(savedInstanceState);
            if (savedInstanceState == null)
                return;
            etSearch.Text = savedInstanceState.GetString("search");

        }


        private void Translate(View view)
        {
            try
            {
                view.FindViewById<AutoCompleteTextView>(Resource.Id.mainSearchBottom).Hint = "str_search".Translate();
                view.FindViewById<AutoCompleteTextView>(Resource.Id.mainSearch).Hint = "str_search".Translate();
                view.FindViewById<Button>(Resource.Id.MbtnOther).Text = "str_other_relig".Translate();
                view.FindViewById<Button>(Resource.Id.MbtnIud).Text = "str_iud".Translate();
                view.FindViewById<Button>(Resource.Id.MbtnIslam).Text = "str_islam".Translate();
                view.FindViewById<Button>(Resource.Id.MbtnHris).Text = "str_hrist".Translate();
                view.FindViewById<TextView>(Resource.Id.maptvFinded).Text = "str_finded".Translate();
                view.FindViewById<Button>(Resource.Id.MbtnBid).Text = "str_bid".Translate();
                view.FindViewById<Button>(Resource.Id.btnShowFilters).Text = "str_filter".Translate();

                view.FindViewById<TextView>(Resource.Id.stvConfess).Text = "str_confession".Translate();
                view.FindViewById<Button>(Resource.Id.btnConfess).Text = "str_select".Translate();
                view.FindViewById<TextView>(Resource.Id.stvType).Text = "str_type".Translate();
                view.FindViewById<Button>(Resource.Id.btnType).Text = "str_select".Translate();
                view.FindViewById<TextView>(Resource.Id.stvArea).Text = "str_area".Translate();
                view.FindViewById<Button>(Resource.Id.btnArea).Text = "str_select".Translate();
                view.FindViewById<Button>(Resource.Id.btnSearch).Text = "str_find".Translate();
                view.FindViewById<Button>(Resource.Id.btnOnMap).Text = "str_show_on_map".Translate();
                view.FindViewById<Button>(Resource.Id.btnClearFilter).Text = "str_reset_filter".Translate();
            }
            catch (Exception ex)
            {

                throw;
            }
        }



        // OPEN INFO WINDOW
        public void OnClusterItemInfoWindowClick(Java.Lang.Object p0)
        {
            ClusterItem itemClicked = (ClusterItem)p0;
            m_ClusterRenderer.GetMarker(itemClicked).HideInfoWindow();
        }

        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
            outState.PutString("search", etSearch.Text);
        }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

        }

        public static FragmentMaps NewInstance()
        {
            var frag = new FragmentMaps { Arguments = new Bundle() };
            return frag;
        }

        private void SearchRes(List<Loc> res)
        {
            var layoutManager = new LinearLayoutManager(Activity);
            recyclerView.SetLayoutManager(layoutManager);
            var adapter = new ResultAdapter(res);
            adapter.eventHandler += (sS, eS) =>
            {
                ((MainActivity)Activity).Go(FragmentConfessionItem.NewInstance(eS, ""));
            };

            recyclerView.SetAdapter(adapter);

            tvFounded.Text = res.Count.ToString();
            filterPanel.Visibility = ViewStates.Gone;
            var metrics = Resources.DisplayMetrics;
            var LayoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WrapContent, metrics.HeightPixels / 2);
            LayoutParams.AddRule(LayoutRules.Above, Resource.Id.MbtnBid);
            bottomPanelSearch.LayoutParameters = LayoutParams;
            bottomPanelSearch.StartAnimation(slide_up);
            bottomPanelSearch.Visibility = ViewStates.Visible;
            floatingCompass.Visibility = ViewStates.Gone;
            floatingMinus.Visibility = ViewStates.Gone;
            floatingShowBottom.Visibility = ViewStates.Gone;
            floatingPlus.Visibility = ViewStates.Gone;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {

            //setRetainInstance(true)
            var view = inflater.Inflate(Resource.Layout.fragment_map, container, false);
            base.OnCreateView(inflater, container, savedInstanceState);

            recyclerView = view.FindViewById<RecyclerView>(Resource.Id.RrvListShort);

            animAlpha = AnimationUtils.LoadAnimation(Context, Resource.Animation.alpha);
            slide_down = AnimationUtils.LoadAnimation(Context, Resource.Animation.slide_down);
            slide_up = AnimationUtils.LoadAnimation(Context, Resource.Animation.slide_up);

            Translate(view);

            tvFounded = view.FindViewById<TextView>(Resource.Id.RtvCountShort);

            // MINUS

            floatingMinus = view.FindViewById<ImageView>(Resource.Id.fabMinus);
            floatingMinus.Click += (s, e) =>
            {
                //floatingMinus.StartAnimation(animAlpha);
                GMap.AnimateCamera(CameraUpdateFactory.ZoomTo(GMap.CameraPosition.Zoom - 1));
            };

            // PLUS
            floatingPlus = view.FindViewById<ImageView>(Resource.Id.fabPlus);
            floatingPlus.Click += (s, e) =>
            {
                GMap.AnimateCamera(CameraUpdateFactory.ZoomTo(GMap.CameraPosition.Zoom + 1));
            };

            // COMAPSS
            floatingCompass = view.FindViewById<ImageView>(Resource.Id.fabCompass);
            floatingCompass.Click += (s, e) =>
            {
                if (_currentPosition != null)
                {
                    var latlng = new LatLng(_currentPosition.Latitude, _currentPosition.Longitude);
                    CameraUpdate camera = CameraUpdateFactory.NewLatLngZoom(latlng, GMap.CameraPosition.Zoom);
                    GMap.AnimateCamera(camera);
                }

            };

            // SHOW BOTTOM PANEL
            floatingShowBottom = view.FindViewById<ImageView>(Resource.Id.fabShowBottomBar);
            floatingShowBottom.Click += (s, e) =>
            {
                Show();
            };

            // FEEDBACK
            var btnFeedBack = view.FindViewById<Button>(Resource.Id.MbtnBid);
            btnFeedBack.Click += (s, e) =>
            {
                btnFeedBack.StartAnimation(animAlpha);
                ((MainActivity)Activity).Go(new FragmentFeedback());
            };

            #region FILTER
            Filters filters = null;

            // SHOW FILTER
            var btnMenuShowFilter = view.FindViewById<Button>(Resource.Id.btnShowFilters);
            btnMenuShowFilter.Click += async (s, e) =>
             {
                 btnMenuShowFilter.StartAnimation(animAlpha);

                 if (filters == null)
                     filters = await logic.GetFilters(Settings.Lang);
                 filterPanel.Visibility = (filterPanel.Visibility == ViewStates.Visible) ? ViewStates.Gone : ViewStates.Visible;
                 BtnsNavVisible(false);
             };

            filterPanel = view.FindViewById<LinearLayout>(Resource.Id.linFilter);




            // SELECT CONFESS
            var btnConfess = (Button)view.FindViewById(Resource.Id.btnConfess);
            btnConfess.Click += async (e, s) =>
            {
                //btnSearch.StartAnimation(animAlpha);
                if (filters != null)
                {
                    var list = filters.Confess.Select(c =>
                        new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

                    var str = string.Empty;
                    var dlgAlert = (new AlertDialog.Builder(MainActivity._activity)).Create();
                    var listView = new ListView(MainActivity._activity);
                    listView.Adapter = new AlertListViewAdapter(MainActivity._activity, list);
                    listView.ItemClick += (ss, ee) =>
                    {
                        btnConfess.Text = list[ee.Position].Name;
                        dlgAlert.Dismiss();
                        data.Confession = new Confess
                        {
                            Id = list[ee.Position].Id,
                            Name = list[ee.Position].Name,
                            Name_kz = list[ee.Position].Name_Kz
                        };
                    };

                    dlgAlert.SetView(listView);
                    dlgAlert.Show();
                }
            };

            // SELECT TYPE
            var btnType = (Button)view.FindViewById(Resource.Id.btnType);
            btnType.Click += async (e, s) =>
            {
                btnType.StartAnimation(animAlpha);
                if (filters != null)
                {
                    var list = filters.Type.Select(c =>
                        new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

                    var str = string.Empty;
                    var dlgAlert = (new AlertDialog.Builder(MainActivity._activity)).Create();
                    var listView = new ListView(MainActivity._activity);
                    listView.Adapter = new AlertListViewAdapter(MainActivity._activity, list);
                    listView.ItemClick += (ss, ee) =>
                    {
                        btnType.Text = list[ee.Position].Name;
                        dlgAlert.Dismiss();
                        data.Type = new TypeConstruction
                        {
                            Id = list[ee.Position].Id,
                            Name = list[ee.Position].Name,
                            Name_kz = list[ee.Position].Name_Kz
                        };
                    };

                    dlgAlert.SetView(listView);
                    dlgAlert.Show();
                }
            };

            // SELECT REGION
            var btnRegion = (Button)view.FindViewById(Resource.Id.btnArea);
            btnRegion.Click += async (e, s) =>
            {
                btnRegion.StartAnimation(animAlpha);
                if (filters != null)
                {
                    var list = filters.Region.Select(c =>
                        new RequestFilter { Id = c.Id, Name = c.Name, Name_Kz = c.Name_kz }).ToList();

                    var str = string.Empty;
                    var dlgAlert = (new AlertDialog.Builder(MainActivity._activity)).Create();
                    var listView = new ListView(MainActivity._activity);
                    listView.Adapter = new AlertListViewAdapter(MainActivity._activity, list);
                    listView.ItemClick += (ss, ee) =>
                    {
                        btnRegion.Text = list[ee.Position].Name;
                        dlgAlert.Dismiss();
                        data.Region = new Region
                        {
                            Id = list[ee.Position].Id,
                            Name = list[ee.Position].Name,
                            Name_kz = list[ee.Position].Name_Kz
                        };
                    };

                    dlgAlert.SetView(listView);
                    dlgAlert.Show();
                }
            };






            // START SEARCH
            var btnSearch = (Button)view.FindViewById(Resource.Id.btnSearch);
            btnSearch.Click += async (s, e) =>
            {
                btnSearch.StartAnimation(animAlpha);
                var flip = new Flip();
                flip.Show();
                Locations = await logic.GetLocations(Settings.Lang, data);
                flip.Dismis();
                if (Locations == null || Locations.Count == 0)
                {
                    Snackbar.Make(btnConfess, "str_notfound".Translate(), Snackbar.LengthLong).Show();
                    return;
                }
                SearchList = true;
                SearchRes(Locations);
            };

            // START SEARCH ON MAP
            var btnClearFilter = (Button)view.FindViewById(Resource.Id.btnClearFilter);
            btnClearFilter.Click += async (s, e) =>
            {
                data = new Search
                {
                    Confession = new Confess { Id = -1 },
                    Region = new Region { Id = -1 },
                    Type = new TypeConstruction { Id = -1 }
                };

                view.FindViewById<Button>(Resource.Id.btnConfess).Text = "str_select".Translate();
                view.FindViewById<Button>(Resource.Id.btnType).Text = "str_select".Translate();
                view.FindViewById<Button>(Resource.Id.btnArea).Text = "str_select".Translate();
            };

            var btnSearchMap = (Button)view.FindViewById(Resource.Id.btnOnMap);
            btnSearchMap.Click += async (s, e) =>
            {
                btnSearchMap.StartAnimation(animAlpha);
                var flip = new Flip();
                flip.Show();
                Locations = await logic.GetLocations(Settings.Lang, data);
                flip.Dismis();
                if (Locations == null || Locations.Count == 0)
                {
                    Snackbar.Make(btnConfess, "str_notfound".Translate(), Snackbar.LengthLong).Show();
                    return;
                }

                MarkresCreate(Locations, false);
                filterPanel.Visibility = ViewStates.Gone;
            };
            #endregion

            // MENU
            var btnMenu = view.FindViewById<ImageView>(Resource.Id.dMenu);
            floatingMenu = view.FindViewById<ImageView>(Resource.Id.fabMenu);
            btnMenu.Click += BtnMenu_Click;
            floatingMenu.Click += BtnMenu_Click;

            // TOP BAR
            searchBar = view.FindViewById<LinearLayout>(Resource.Id.toolbarSearch);
            etSearch = view.FindViewById<AutoCompleteTextView>(Resource.Id.mainSearch);
            var btnClear = view.FindViewById<ImageButton>(Resource.Id.dbtnClear);
            btnClear.Click += (s, e) =>
             {
                 etSearch.Text = string.Empty;
             };

            // SERCH TEXT
            etSearch.TextChanged += async (s, e) =>
            {
                btnMenuShowFilter.Visibility = ViewStates.Visible;
                var text = e.Text.ToString().ToLower();
                if (text.Length > 0)
                {
                    btnClear.Visibility = ViewStates.Visible;
                    etSearch.SetCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                }
                else
                {
                    etSearch.SetCompoundDrawablesWithIntrinsicBounds(0, 0, Resource.Drawable.ic_search, 0);
                    btnClear.Visibility = ViewStates.Gone;
                }
                Locations = await logic.SearchLocations(Settings.Lang, text);
                if (Locations != null)
                {
                    var items = Locations.Select(l => l.Name).ToList();
                    etSearch.Adapter = new ArrayAdapter<String>(Context, Android.Resource.Layout.SimpleListItem1, items);
                }
            };

            // CLICK SEARCH ITEM
            etSearch.ItemClick += async (ss, ee) =>
            {
                AutoCompleteTextView autoText = (AutoCompleteTextView)ss;
                var item = Locations.Where(l => l.Name == autoText.Text).FirstOrDefault();
                if (item != null)
                    MarkresCreate(new List<Loc> { item }, true);
            };


            // BOTTOM PANEL
            bottomPanel = view.FindViewById<LinearLayout>(Resource.Id.MbottomPanel);
            var etSearchBottom = view.FindViewById<AutoCompleteTextView>(Resource.Id.mainSearchBottom);
            etSearchBottom.TextChanged += (s, e) =>
            {
                etSearch.Text = e.Text.ToString();
                Hide();
            };

            bottomPanelSearch = view.FindViewById<LinearLayout>(Resource.Id.mapSearchResult);
            bottomPanelSearch.Visibility = ViewStates.Gone;
            //bottomPanelSearch.ScrollChange += (s, e) =>
            // {
            //     var ss = "";
            // };

            bottomPanelSearch.Click += (s, e) =>
            {
                SearchList = false;
                Hide();
            };

            // GET OTHER RELIG
            var btnOther = view.FindViewById<Button>(Resource.Id.MbtnOther);
            btnOther.Click += async (s, e) =>
            {
                btnOther.StartAnimation(animAlpha);
                var flip = new Flip();
                flip.Show();
                Locations = await logic.GetFilteredLocations(Settings.Lang, 7);
                if (Locations == null) return;
                var res2 = await logic.GetFilteredLocations(Settings.Lang, 5);
                if (res2 != null)
                    Locations.AddRange(res2);
                MarkresCreate(Locations, false);
                flip.Dismis();
            };

            // GET IUDAISM RELIG
            var btnIudaism = view.FindViewById<Button>(Resource.Id.MbtnIud);
            btnIudaism.Click += async (s, e) =>
            {
                btnIudaism.StartAnimation(animAlpha);
                var flip = new Flip();
                flip.Show();
                Locations = await logic.GetFilteredLocations(Settings.Lang, 6);
                if (Locations == null) return;
                MarkresCreate(Locations, false);
                flip.Dismis();
            };

            // GET ISLAM RELIG
            var btnIslam = view.FindViewById<Button>(Resource.Id.MbtnIslam);
            btnIslam.Click += async (s, e) =>
            {
                btnIslam.StartAnimation(animAlpha);
                var flip = new Flip();
                flip.Show();
                Locations = await logic.GetFilteredLocations(Settings.Lang, 1);
                if (Locations == null) return;
                MarkresCreate(Locations, false);
                flip.Dismis();
            };

            // GET HRISTIAN RELIG
            var btnHrist = view.FindViewById<Button>(Resource.Id.MbtnHris);
            btnHrist.Click += async (s, e) =>
            {
                btnHrist.StartAnimation(animAlpha);
                var flip = new Flip();
                flip.Show();
                Locations = await logic.GetFilteredLocations(Settings.Lang, 2);
                if (Locations == null) return;
                MarkresCreate(Locations, false);
                flip.Dismis();
            };

            mMapView = view.FindViewById<MapView>(Resource.Id.map);
            mMapView.OnCreate(savedInstanceState);
            mMapView.OnResume();
            try
            {
                MapsInitializer.Initialize(MainActivity._activity);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            mMapView.GetMapAsync(this);
            HasOptionsMenu = true;
            return view;
        }


        // SEARCH PAGE
        private void BtnSearchBottom_Click(object sender, EventArgs e)
        {
            ((MainActivity)Activity).Go(new FragmentSearch());
        }

        // OPEN MENU
        private void BtnMenu_Click(object sender, EventArgs e)
        {
            ((MainActivity)Activity).drawerLayout.OpenDrawer(GravityCompat.Start);
        }

        public async override void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Hide();


            try
            {
                var locator = CrossGeolocator.Current;
                if (!locator.IsGeolocationAvailable)
                {
                    _currentPosition = new Position(43.25654, 76.92848);
                }

                if (!locator.IsListening)
                {
                    var isListeninig = await locator.StartListeningAsync(TimeSpan.FromSeconds(10), 1, true);
                }
            }
            catch (Exception ex)
            {

                throw;
            }



        }

        public async void OnMapReady(GoogleMap googleMap)
        {
            GMap = googleMap;
            var latlng = new LatLng(43.25654, 76.92848);
            if (camera == null)
                camera = CameraUpdateFactory.NewLatLngZoom(latlng, 10);
            GMap.MoveCamera(camera);


            GMap.MapClick += (object sender, GoogleMap.MapClickEventArgs e) =>
            {
                List<ClusterItem> lsMarkers = new List<ClusterItem>();
                var newMarker = new ClusterItem(e.Point.Latitude, e.Point.Longitude);
                lsMarkers.Add(newMarker);
            };

            GMap.CameraMoveStarted += (s, e) =>
            {
                SearchList = false;
                Hide();
            };

            GMap.CameraChange += GMap_CameraChange;

            if (Locations == null)
                Locations = await logic.GetLocations(Settings.Lang, data);
            if (Locations != null)
            {
                if (SearchList)
                {
                    SearchRes(Locations);

                }
                MarkresCreate(Locations, false);
            }

        }

        private void GMap_CameraChange(object sender, GoogleMap.CameraChangeEventArgs e)
        {
            camera = CameraUpdateFactory.NewLatLngZoom(e.Position.Target, e.Position.Zoom);
        }

        private void Hide()
        {
            Animation slide_right = AnimationUtils.LoadAnimation(Context, Resource.Animation.slide_right);
            searchBar.Visibility = ViewStates.Visible;
            floatingMenu.Visibility = ViewStates.Gone;
            BtnsNavVisible(true);
            if (bottomPanel.Visibility == ViewStates.Visible)
            {
                bottomPanel.StartAnimation(slide_down);
                bottomPanel.Visibility = ViewStates.Gone;
            }

            if (bottomPanelSearch.Visibility == ViewStates.Visible)
            {
                bottomPanelSearch.StartAnimation(slide_down);
                bottomPanelSearch.Visibility = ViewStates.Gone;
            }
        }

        private void Show()
        {
            //Animation slide_right = AnimationUtils.LoadAnimation(Context, Resource.Animation.slide_right);
            searchBar.Visibility = ViewStates.Gone;
            floatingMenu.Visibility = ViewStates.Visible;

            BtnsNavVisible(false);

            if (bottomPanel.Visibility == ViewStates.Gone)
            {
                bottomPanel.StartAnimation(slide_up);
                bottomPanel.Visibility = ViewStates.Visible;
            }
        }

        // SHOW/HIDE NAV BUTTONS
        private void BtnsNavVisible(bool visible)
        {
            if (visible)
            {
                floatingShowBottom.Visibility = ViewStates.Visible;
                floatingCompass.Visibility = ViewStates.Visible;
                floatingPlus.Visibility = ViewStates.Visible;
                floatingMinus.Visibility = ViewStates.Visible;
            }
            else
            {
                floatingShowBottom.Visibility = ViewStates.Gone;
                floatingCompass.Visibility = ViewStates.Gone;
                floatingPlus.Visibility = ViewStates.Gone;
                floatingMinus.Visibility = ViewStates.Gone;
            }
        }

        // CREATE MARKERS
        private void MarkresCreate(List<Loc> list, bool Focus)
        {
            ClusterManager m_ClusterManager1 = new ClusterManager(MainActivity._activity, GMap);
            GMap.SetOnCameraIdleListener(m_ClusterManager1);

            GMap.Clear();

            m_ClusterRenderer = new ClusterRenderer(MainActivity._activity, GMap, m_ClusterManager1);
            m_ClusterManager1.Renderer = m_ClusterRenderer;

            m_ClusterManager1.MarkerCollection.SetOnInfoWindowAdapter(new CustomGoogleMapInfoWindow(MainActivity._activity));

            GMap.SetInfoWindowAdapter(m_ClusterManager1.MarkerManager);

            GMap.SetOnInfoWindowClickListener(m_ClusterManager1);
            m_ClusterManager1.SetOnClusterItemInfoWindowClickListener(this);

            GMap.InfoWindowClick += (s, e) =>
            {
                var item = list.Where(l => l.Image == e.Marker.Snippet).FirstOrDefault();
                if (item != null)
                {
                    ((MainActivity)Activity).Go(FragmentConfessionItem.NewInstance(item, ""));
                }
            };

            List<ClusterItem> lsMarkers = new List<ClusterItem>();
            foreach (var item in list)
            {
                var l = item.Map.Split(',');
                var newMarker = new ClusterItem(double.Parse(l[0], CultureInfo.InvariantCulture), double.Parse(l[1], CultureInfo.InvariantCulture));
                newMarker.Title = item.Name;
                newMarker.Snippet = item.Image;
                newMarker.MarkerIcon = GetIcon.Get(item.Confess_id);
                lsMarkers.Add(newMarker);
            }
            m_ClusterManager1.AddItems(lsMarkers);
            m_ClusterManager1.Cluster();

            if (Focus)
            {
                if (lsMarkers != null)
                {
                    var itm = lsMarkers.FirstOrDefault();
                    if (itm != null)
                    {
                        LatLng latlng = new LatLng(itm.Position.Latitude, itm.Position.Longitude);
                        CameraUpdate camera = CameraUpdateFactory.NewLatLngZoom(latlng, 15);
                        GMap.MoveCamera(camera);
                    }

                }
            }





        }


    }
}