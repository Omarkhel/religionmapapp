using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using Client.Helper;
using Client.Models.Json;
using FFImageLoading;
using FFImageLoading.Views;

namespace Client.Droid.Fragments
{
    public class FragmentConfessIt : Fragment
    {
       static Confess data { get; set; }
        TextView title, text;
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentConfessIt NewInstance(Confess _data)
        {
            data = _data;
            var frag = new FragmentConfessIt { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            //view.FindViewById<TextView>(Resource.Id.ctvHris).Text = "str_hrist".Translate();
            //view.FindViewById<TextView>(Resource.Id.ctvIslam).Text = "str_islam".Translate();
            //view.FindViewById<TextView>(Resource.Id.ctvBud).Text = "str_b".Translate();
            //view.FindViewById<TextView>(Resource.Id.ctvIud).Text = "str_iud".Translate();
            //view.FindViewById<TextView>(Resource.Id.ctvNew).Text = "str_newr".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_confes_it, container, false);

            title = view.FindViewById<TextView>(Resource.Id.ctvTitle);
            text = view.FindViewById<TextView>(Resource.Id.ctvText);
            var image = view.FindViewById<ImageViewAsync>(Resource.Id.cImgLogo);
            ImageService.Instance.LoadUrl($"http://religionmap.kz{data.Image}")
                   // .DownSample(200)
                   //.LoadingPlaceholder("drawable/ic_placeholder.png", FFImageLoading.Work.ImageSource.CompiledResource)
                   .Into(image);


            title.Text = data.Name;
            text.Text = HtmlClean.GetText(data.Full_text);

            Translate(view);
            return view;
        }



        public async override void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Title = data.Name;
            ((MainActivity)Activity).SupportActionBar.Show();

            
            
        }

    }
}