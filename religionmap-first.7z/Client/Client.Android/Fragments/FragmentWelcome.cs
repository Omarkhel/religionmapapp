using Android;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using I18NPortable;
using Plugin.Geolocator;
using Plugin.Permissions;

namespace Client.Droid.Fragments
{
    public class FragmentWelcome : Fragment
    {
        string[] PermissionsLocation =
{
  Manifest.Permission.AccessCoarseLocation,
  Manifest.Permission.AccessFineLocation
};

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentWelcome NewInstance()
        {
            var frag = new FragmentWelcome { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.wtvw1).Text = "str_welcome_1".Translate();
            view.FindViewById<TextView>(Resource.Id.wtvw2).Text = "str_welcome_2".Translate();
            view.FindViewById<TextView>(Resource.Id.startTvAppDesc).Text = "str_app_description".Translate();
            view.FindViewById<Button>(Resource.Id.startBtnNext).Text = "str_next".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_welcome, container, false);
            var btnNext = view.FindViewById<Button>(Resource.Id.startBtnNext);
            var animAlpha = AnimationUtils.LoadAnimation(Context, Resource.Animation.alpha);
            Translate(view);
            btnNext.Click += (s, e) =>
            {
                btnNext.StartAnimation(animAlpha);
                var fragment = new FragmentLang();
                ((ActivityWelcome)Activity).Go(fragment);
            };

            return view;
        }



        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
        }


        public async override void OnResume()
        {
            base.OnResume();

         

            var ff = "";


            // var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Plugin.Permissions.Abstractions.Permission.Location);


        }
    }
}