using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using I18NPortable;

namespace Client.Droid.Fragments
{
    public class FragmentFinish : Fragment
    {
        RecyclerView recyclerView;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentFinish NewInstance()
        {
            var frag = new FragmentFinish { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.finish).Text = "str_finish".Translate();
            view.FindViewById<Button>(Resource.Id.finishBtnMain).Text = "str_finish".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_finish, container, false);
            var btnFinish = view.FindViewById<Button>(Resource.Id.finishBtnMain);
            var animAlpha = AnimationUtils.LoadAnimation(Context, Resource.Animation.alpha);
            Translate(view);
            btnFinish.Click += (s, e) =>
            {
                btnFinish.StartAnimation(animAlpha);
                Settings.FirstStart = false;
                Context.StartActivity(typeof(MainActivity));
            };

            return view;
        }

   

        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
        }


        public override void OnResume()
        {
            base.OnResume();
        }
    }
}