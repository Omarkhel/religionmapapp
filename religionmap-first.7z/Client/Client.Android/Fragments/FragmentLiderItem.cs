using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using Client.Droid.Helpers;
using Client.Helper;
using I18NPortable;
using Refractored.Controls;
using Square.Picasso;

namespace Client.Droid.Fragments
{
    public class FragmentLiderItem : Fragment
    {
        TextView tvName, tvGraj, tvPost,tvExp, tvConfess,tvDescr;

        CircleImageView image;

        private static int LidearId { get; set; }
        private static string LidearName { get; set; }


        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentLiderItem NewInstance(int _leader,string _lidearName)
        {
            LidearName = _lidearName;
            LidearId = _leader;
            var frag = new FragmentLiderItem { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.LltvGr).Text = "str_citizenship".Translate();
            view.FindViewById<TextView>(Resource.Id.LltvPosit).Text = "str_post".Translate();
            view.FindViewById<TextView>(Resource.Id.LltvConfes).Text = "str_confession".Translate();
            view.FindViewById<TextView>(Resource.Id.LltvExp).Text = "str_exp".Translate();
            //view.FindViewById<TextView>(Resource.Id.LltvContacts1).Text = "str_contacts".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_leader_item, container, false);

            Translate(view);
            image = (CircleImageView)view.FindViewById(Resource.Id.Llimg);

            


            tvName = (TextView)view.FindViewById(Resource.Id.LltvName);
            tvDescr = (TextView)view.FindViewById(Resource.Id.LltvDescript);


            tvGraj = (TextView)view.FindViewById(Resource.Id.LltvCitizenship);
            tvExp = (TextView)view.FindViewById(Resource.Id.LltvExp2);

            

            tvPost = (TextView)view.FindViewById(Resource.Id.LltvPost);
            //tvDateB = (TextView)view.FindViewById(Resource.Id.LltvdateOfBirth);


            tvConfess = (TextView)view.FindViewById(Resource.Id.LltvConfession);
            //tvCongess.Text = 

            //tvEducation = (TextView)view.FindViewById(Resource.Id.LltvEducation);
            //tvEducation.Text = "��������";

            //tvSchool = (TextView)view.FindViewById(Resource.Id.LltvSchool);
            //tvSchool.Text = "��������";

            //tvYearsEd = (TextView)view.FindViewById(Resource.Id.LltvYearsEdu);
            //tvYearsEd.Text = "��������";

            //tvSpEdu = (TextView)view.FindViewById(Resource.Id.LltvSpiritEdu);
            //tvSpEdu.Text = "��������";

            //tvInstName = (TextView)view.FindViewById(Resource.Id.LltvInstitName);
            //tvInstName.Text = "��������";

            //tvYearEd = (TextView)view.FindViewById(Resource.Id.LltvYearsEduSpirit);
            //tvYearEd.Text = "��������";

            return view;
        }

        public override async void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Title = LidearName;

            var flip = new Flip();
            flip.Show();
            var logic = new Logic();
            var res = await logic.GetPeopleItem(Settings.Lang,LidearId);
            if (res != null)
            {
                tvName.Text = res.Name;
                //tvDateB.Text = res.BDate;
                tvPost.Text = res.Position;
                tvGraj.Text = res.Gr;

                Picasso.With(Context)
                .Load($"http://religionmap.kz{res.Image}")
                .Into(image);

                tvConfess.Text = ConfesHelper.Get(res.confess_id.ToString());

                //res.confess_id.ToString();
                tvDescr.Text = HtmlClean.GetText(res.Description);

                tvExp.Text = res.Exp;

                //var confess = await logic.GetConfessItem(res.confess_id);
                //if (confess != null)
                // tvCongess.Text = res
            }

            flip.Dismis();
        }
    }
}