using Android.OS;
using Android.Runtime;
using Android.Support.Design.Widget;
using Android.Support.V4.App;
using Android.Support.V7.App;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using Client.Droid.Helpers;
using Client.Models;
using Client.Models.Json;
using I18NPortable;
using System.Linq;

namespace Client.Droid.Fragments
{
    public class FragmentSearch : Fragment
    {
        Logic logic = new Logic();

        private Button btnConfess;
        Filters filters = new Filters();
        Search data = new Search();

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            data = new Search
            {
                Confession = new Confess { Id = -1 },
                Region = new Region { Id = -1 },
                Type = new TypeConstruction { Id = -1 }
            };
        }

        public static FragmentSearch NewInstance()
        {
            var frag = new FragmentSearch { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.stvConfess).Text = "str_confession".Translate();
            view.FindViewById<Button>(Resource.Id.btnConfess).Text = "str_select".Translate();
            view.FindViewById<TextView>(Resource.Id.stvType).Text = "str_type".Translate();
            view.FindViewById<Button>(Resource.Id.btnType).Text = "str_select".Translate();
            view.FindViewById<TextView>(Resource.Id.stvArea).Text = "str_area".Translate();
            view.FindViewById<Button>(Resource.Id.btnArea).Text = "str_select".Translate();
            view.FindViewById<Button>(Resource.Id.btnSearch).Text = "str_find".Translate();
            view.FindViewById<Button>(Resource.Id.btnOnMap).Text = "str_show_on_map".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_search, container, false);

            Translate(view);
            //var animAlpha = AnimationUtils.LoadAnimation(Context, Resource.Animation.alpha);










            //HasOptionsMenu = true;
            return view;
        }

        public async override void OnResume()
        {
            base.OnResume();
            //((MainActivity)Activity).SupportActionBar.Show();
            //var flip = new Flip();
            //flip.Show();
            //filters = await logic.GetFilters(Settings.Lang);
            //flip.Dismis();

            ////f.Wait().Dismiss();
            //if (filters == null)
            //{
            //    Snackbar.Make(btnConfess, GetString(Resource.String.str_internet_error), Snackbar.LengthLong).Show();
            //}
            //else
            //{
            //    btnConfess.Enabled = true;
            //}
        }



        public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
        {
            //    inflater.Inflate(Resource.Menu.m_search, menu);
            //    base.OnCreateOptionsMenu(menu, inflater);
            //    var searchItem = menu.FindItem(Resource.Id.action_search);

            //    var searchView = searchItem.ActionView as Android.Support.V7.Widget.SearchView;
            //    //searchView.Iconified = false;
            //    // searchView.TooltipText = GetString(Resource.String.str_search);
            //    searchView.QueryHint = GetString(Resource.String.str_search);

            //    var _search = searchView.JavaCast<Android.Support.V7.Widget.SearchView>();

            //    _search.QueryTextChange += (s, e) =>
            //    {
            //        //Toast.MakeText(MainActivity.globalContext, e.NewText, ToastLength.Short).Show();
            //    };
            //}
        }
    }
}