using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.Widget;
using Android.Views;
using Client.Droid.Expandable;
using Client.Droid.Helpers;
using Client.Helper;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using XamDroid.ExpandableRecyclerView;


namespace Client.Droid.Fragments
{
    public class FragmentFaq : Fragment
    {
        RecyclerView recyclerView;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentFaq NewInstance()
        {
            var frag = new FragmentFaq { Arguments = new Bundle() };
            return frag;
        }


        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_faq, container, false);
            recyclerView = view.FindViewById<RecyclerView>(Resource.Id.FrvList);
            return view;
        }

        private Task<List<IParentObject>> InitData()
        {
            return Task.Run(async () =>
           {
               var parentObject = new List<IParentObject>();
               var logic = new Logic();
               var res = await logic.GetFaqList(Settings.Lang);
               if (res != null)
               {
                   foreach (var item in res)
                   {
                       var title = new TitleParent();
                       var childList = new List<Object>();
                       childList.Add(new TitleChild(HtmlClean.GetText(item.Text), ""));
                       title.ChildObjectList = childList;
                       title.Title = HtmlClean.GetText(item.Title);
                       parentObject.Add(title);
                   }

               }
               return parentObject;
            });
        }

        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
            ((MyExRecyclerViewAdapter)recyclerView.GetAdapter()).OnSaveInstanceState(outState);
        }


        public override async void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Show();
            ((MainActivity)Activity).SupportActionBar.Title = GetString(Resource.String.str_faq);

            var flip = new Flip();
            flip.Show();

            var layoutManager = new LinearLayoutManager(Activity);
            recyclerView.SetLayoutManager(layoutManager);

            var adapter = new MyExRecyclerViewAdapter(Context, await InitData());
            adapter.CustomParentAnimationViewId = Resource.Id.expandArrow;
            
            adapter.SetParentClickableViewAnimationDefaultDuration();
            adapter.ParentAndIconExpandOnClick = true;

        

            recyclerView.SetAdapter(adapter);

            flip.Dismis();


        }
    }
}