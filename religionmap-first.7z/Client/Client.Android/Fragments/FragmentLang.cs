using Android.Content;
using Android.Content.Res;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using I18NPortable;
using Java.Util;

namespace Client.Droid.Fragments
{
    public class FragmentLang : Fragment
    {
        RecyclerView recyclerView;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentLang NewInstance()
        {
            var frag = new FragmentLang { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.langtvStep1).Text = "str_step1".Translate();
            view.FindViewById<TextView>(Resource.Id.langtvSelectL).Text = "str_select_lang".Translate();
            view.FindViewById<Button>(Resource.Id.langbtnRus).Text = "str_rus".Translate();
            view.FindViewById<Button>(Resource.Id.langbtnKaz).Text = "str_lan_kaz".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_lang, container, false);


            var animAlpha = AnimationUtils.LoadAnimation(Context, Resource.Animation.alpha);
            Translate(view);


            var btnRus = view.FindViewById<Button>(Resource.Id.langbtnRus);
            btnRus.Click += (s, e) =>
            {
                btnRus.StartAnimation(animAlpha);
                //ChangeLang("ru");
                ((ActivityWelcome)Activity).Go(new FragmentStep2());
            };

            var btnKaz = view.FindViewById<Button>(Resource.Id.langbtnKaz);
            btnKaz.Click += (s, e) =>
            {
                btnKaz.StartAnimation(animAlpha);
               // ChangeLang("kz");
                ((ActivityWelcome)Activity).Go(new FragmentStep2());
            };

            return view;
        }

        private void ChangeLang(string lang)
        {
            Settings.Lang = lang;
            Settings.FirstStart = false;
            var locale = new Locale(lang);
            Locale.Default = locale;
            var config = new Configuration();
            config.Locale = locale;
            this.Resources.UpdateConfiguration(config, null);
            Intent intent = new Intent(ActivityWelcome._activity, typeof(MainActivity));
            intent.AddFlags(ActivityFlags.NoAnimation);
            ActivityWelcome._activity.Finish();
            StartActivity(intent);
        }

        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
        }


        public override void OnResume()
        {
            base.OnResume();
        }
    }
}