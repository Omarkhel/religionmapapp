using Android.Content;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using Client.Droid.Helpers;
using Client.Helper;
using FFImageLoading;
using FFImageLoading.Views;
using I18NPortable;
using System;


namespace Client.Droid.Fragments
{
    public class FragmentNewItem : Fragment
    {

        TextView tvTitle, tvText, tvDate;
        ImageViewAsync image;

        static int id;
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentNewItem NewInstance(int _id)
        {
            id = _id;
            var frag = new FragmentNewItem { Arguments = new Bundle() };
            return frag;
        }


        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_new_item, container, false);
            image = view.FindViewById<ImageViewAsync>(Resource.Id.NIimg);
            tvTitle = view.FindViewById<TextView>(Resource.Id.NItvTitle);
            tvText = view.FindViewById<TextView>(Resource.Id.NItvText);
            tvDate = view.FindViewById<TextView>(Resource.Id.NItvAdded);
            return view;
        }

        public DateTime ToDateTime(long timestamp)
        {
            var dateTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTime.Now.Kind);
            return dateTime.AddSeconds(timestamp);
        }

        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
        }


        public override async void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Show();
            ((MainActivity)Activity).SupportActionBar.Title = "str_news".Translate();

            var flip = new Flip();
            flip.Show();
            var logic = new Logic();
            var res = await logic.GetNewsItem(Settings.Lang, id);
            if (res != null)
            {
                var sd = $"http://religionmap.kz{res.Image}";

                ImageService.Instance.LoadUrl(sd)
                    // .DownSample(200)
                    .LoadingPlaceholder("drawable/ic_placeholder.png", FFImageLoading.Work.ImageSource.CompiledResource)
                    .Into(image);

                tvTitle.Text = res.Title;
                tvText.Text = HtmlClean.GetText(res.Detail_text);

                if (res.Detail_text.Contains("youtube"))
                {

                    AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity._activity);
                    //alert.SetTitle("Confirm delete");
                    alert.SetMessage("str_open_video".Translate());
                    alert.SetPositiveButton("str_yes".Translate(), (senderAlert, args) => {
                        var uri = Android.Net.Uri.Parse(res.Detail_text);
                        var intent = new Intent(Intent.ActionView, uri);
                        StartActivity(intent);

                        //((MainActivity)Activity).Go(FragmentWeb.NewInstance(res.Detail_text, res.Title));
                    });

                    alert.SetNegativeButton("str_no".Translate(), (senderAlert, args) => {
                    });

                    var dialog = alert.Create();
                    dialog.Show();

                }
                //string date = ToDateTime(Convert.ToInt64(res.Created)).ToString("dd.MM.yyyy");
                tvDate.Text = $"{ "str_added".Translate()} {res.Date}";
            }
            flip.Dismis();
        }
    }
}