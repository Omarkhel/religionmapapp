using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.Widget;
using Android.Views;
using Client.Droid.Expandable;
using Client.Droid.Helpers;
using Client.Models.Json;
using I18NPortable;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using XamDroid.ExpandableRecyclerView;


namespace Client.Droid.Fragments
{
    public class FragmentNews : Fragment
    {
        RecyclerView recyclerView;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentNews NewInstance()
        {
            var frag = new FragmentNews { Arguments = new Bundle() };
            return frag;
        }


        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_news, container, false);
            recyclerView = view.FindViewById<RecyclerView>(Resource.Id.NrvList);
            return view;
        }



        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
        }


        public override async void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Show();
            ((MainActivity)Activity).SupportActionBar.Title = "str_news".Translate();

            var flip = new Flip();
            flip.Show();
            var logic = new Logic();
            var res = await logic.GetNewsList(Settings.Lang);
            if (res != null)
            {
                var layoutManager = new LinearLayoutManager(Activity);
                recyclerView.SetLayoutManager(layoutManager);

                var adapter = new NewsAdapter(res);
                adapter.eventHandler += (s, e) =>
                {
                    ((MainActivity)Activity).Go(FragmentNewItem.NewInstance(e.Id));
                };
                recyclerView.SetAdapter(adapter);
            }
            flip.Dismis();
        }
    }
}