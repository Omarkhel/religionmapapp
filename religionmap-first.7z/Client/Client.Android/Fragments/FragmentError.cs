using Android.Content;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.App;
using Android.Support.V7.Widget;
using Android.Views;
using Android.Views.Animations;
using Android.Widget;
using System.Collections.Generic;
using System.Linq;

namespace Client.Droid.Fragments
{
    public class FragmentError : Fragment
    {
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentError NewInstance()
        {
            var frag = new FragmentError { Arguments = new Bundle() };
            return frag;
        }


        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_error, container, false);
            //var btnReport = view.FindViewById<Button>(Resource.Id.btnEReport);
            //var btnExit = view.FindViewById<Button>(Resource.Id.btnEClose);
            //var btnRepeat = view.FindViewById<Button>(Resource.Id.btnERepeat);
            //var animAlpha = AnimationUtils.LoadAnimation(Context, Resource.Animation.alpha);


            //btnRepeat.Click += (sender, e) =>
            //{
            //    Activity.OnBackPressed();
            //};

            //btnExit.Click += (sender, e) =>
            //{
            //    Activity.FinishAffinity();
            //};

            //btnReport.Click += (sender, e) =>
            // {
            //     //btnReport.StartAnimation(animAlpha);
            //     //((MainActivity)Activity).Go(FragmentReport.NewInstance());
            // };


            return view;
        }

        public override void OnResume()
        {
            //base.OnResume();
            //((MainActivity)Activity).SupportActionBar.Title = GetString(Resource.String.str_error_later);
        }
    }
}