using Android.Content;
using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using Client.Droid.Helpers;
using System;

namespace Client.Droid.Fragments
{
    public class FragmentStart : Fragment
    {

    
        public static Context context { get; set; }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentStart NewInstance()
        {
            //context = ctx;
            var frag = new FragmentStart { Arguments = new Bundle() };
            return frag;
        }


        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_start, container, false);

            var btn = (Button)view.FindViewById(Resource.Id.btnStart);
            btn.Click += async (e, s) =>
            {
                var logic = new Logic();
                var d = await logic.GetFilters(Settings.Lang);
                var ss = "";
            };
           

            //};


            return view;
        }

        public override void OnResume()
        {
            base.OnResume();
        }



        //private void SendEmail(string email, string title)
        //{
        //    var emailIntent = new Intent(Android.Content.Intent.ActionSend);
        //    emailIntent.PutExtra(Android.Content.Intent.ExtraEmail, new[] { email });
        //    emailIntent.PutExtra(Android.Content.Intent.ExtraCc, new[] { email });
        //    emailIntent.PutExtra(Android.Content.Intent.ExtraSubject, title);
        //    emailIntent.SetType("text/plain");
        //    StartActivity(Intent.CreateChooser(emailIntent, GetString(Resource.String.str_email)));
        //}

        //private void PhoneDial(Int64 phone)
        //{
        //    var uri = Android.Net.Uri.Parse($"tel:{phone}");
        //    var intent = new Intent(Intent.ActionDial, uri);
        //    StartActivity(intent);
        //}

        //private void UrlOpen(string url)
        //{
        //    var uri = Android.Net.Uri.Parse(url);
        //    var intent = new Intent(Intent.ActionView, uri);
        //    StartActivity(intent);
        //}
    }
}