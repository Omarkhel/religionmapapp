using Android.Content;
using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using Client.Droid.Helpers;
using I18NPortable;
using System;

namespace Client.Droid.Fragments
{
    public class FragmentAbout : Fragment
    {

    
        public static Context context { get; set; }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentAbout NewInstance()
        {

            var frag = new FragmentAbout { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.abtvDesc).Text = "str_app_description".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvdesc1).Text = "str_p1".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvdesc2).Text = "str_p2".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvdesc3).Text = "str_p3".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvdesc4).Text = "str_p4".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvAb).Text = "str_about".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvOpisCel).Text = "str_op_cel".Translate();
            view.FindViewById<TextView>(Resource.Id.abtbAb1).Text = "str_ab1".Translate();
            view.FindViewById<TextView>(Resource.Id.abtbAb2).Text = "str_ab2".Translate();
            view.FindViewById<TextView>(Resource.Id.abtbAb3).Text = "str_ab3".Translate();
            view.FindViewById<TextView>(Resource.Id.abtbAb4).Text = "str_ab4".Translate();
            view.FindViewById<TextView>(Resource.Id.abtbAb5).Text = "str_ab5".Translate();
            view.FindViewById<TextView>(Resource.Id.abtbAb6).Text = "str_ab6".Translate();
            view.FindViewById<TextView>(Resource.Id.abtbAb7).Text = "str_ab7".Translate();
            view.FindViewById<TextView>(Resource.Id.abtbAb8).Text = "str_ab8".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvGor).Text = "str_gor_sit".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvG1).Text = "str_g1".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvG2).Text = "str_g2".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvPodTitle).Text = "str_pp_title".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvupr).Text = "str_abtvupr".Translate();
            view.FindViewById<TextView>(Resource.Id.abtvPodText).Text = "str_str_abtvupr2".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_about, container, false);

            Translate(view);
            return view;
        }

        public override void OnResume()
        {
            base.OnResume();

            ((MainActivity)Activity).SupportActionBar.Title = "str_about".Translate();
            ((MainActivity)Activity).SupportActionBar.Show();
        }




    }
}