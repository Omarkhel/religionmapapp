using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using Android.Webkit;

namespace Client.Droid.Fragments
{
    public class FragmentWeb : Fragment
    {
        private static string URL { get; set; }
        private static string Title { get; set; }
        private WebView web;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentWeb NewInstance(string url,string title)
        {
            URL = url;
            Title = title;
            var frag = new FragmentWeb { Arguments = new Bundle() };
            return frag;
        }


        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_web, container, false);
            web = (WebView)view.FindViewById(Resource.Id.webView);
            return view;
        }

        public override void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Title = Title;
            ((MainActivity)Activity).SupportActionBar.Show();
            web.LoadUrl(URL);
        }
    }
}