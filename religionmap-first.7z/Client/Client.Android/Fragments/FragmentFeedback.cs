using Android.Content;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using Client.Droid.Helpers;
using I18NPortable;
using Plugin.FilePicker;
using Plugin.FilePicker.Abstractions;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System;
using System.Collections.Generic;
using System.IO;

namespace Client.Droid.Fragments
{
    public class FragmentFeedback : Fragment, IOnMapReadyCallback
    {
        private LatLng Coordinate { get; set; }

        MapView mMapView;
        string Location { get; set; } = "";
        private GoogleMap GMap;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentFeedback NewInstance()
        {
            var frag = new FragmentFeedback { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.fbtvFeedback).Text = "str_feedback".Translate();
            view.FindViewById<TextView>(Resource.Id.fbtvFeedbackTitle).Text = "str_feedback_title".Translate();
            view.FindViewById<TextView>(Resource.Id.fbtvName).Text = "str_fedback_name".Translate();
            view.FindViewById<TextView>(Resource.Id.fbtvNum).Text = "str_feedback_num".Translate();
            view.FindViewById<TextView>(Resource.Id.fbtvMessage).Text = "str_message".Translate();
            view.FindViewById<TextView>(Resource.Id.FBtvAttach).Text = "str_attach".Translate();
            view.FindViewById<TextView>(Resource.Id.FBbtnSend).Text = "str_send".Translate();
            view.FindViewById<TextView>(Resource.Id.FBtvPhoto).Text = "str_photo".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_feedback, container, false);
            base.OnCreateView(inflater, container, savedInstanceState);

            Translate(view);

            var FilesList = new List<string>();

            mMapView = view.FindViewById<MapView>(Resource.Id.mapFeedBack);
            mMapView.OnCreate(savedInstanceState);
            mMapView.OnResume();
            try
            {
                MapsInitializer.Initialize(MainActivity._activity);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            mMapView.GetMapAsync(this);

            var etName = view.FindViewById<EditText>(Resource.Id.FBetName);
            var etEmail = view.FindViewById<EditText>(Resource.Id.FBetEmail);
            var etPhone = view.FindViewById<EditText>(Resource.Id.FBetNum);
            var etMessage = view.FindViewById<EditText>(Resource.Id.FBetMessage);

            var tvFiles = view.FindViewById<TextView>(Resource.Id.tvAttachedFiles);


            var tvAttach = view.FindViewById<TextView>(Resource.Id.FBtvAttach);
            tvAttach.Click += async (s, e) =>
            {
                try
                {
                    await CrossMedia.Current.Initialize();

                    var file = await CrossMedia.Current.PickPhotoAsync();
                    if (file == null)
                        return;

                    string fileName = file.Path;
                   

                    if (FilesList.Contains(fileName))
                    {
                        Snackbar.Make(view, "str_file_exists".Translate(), Snackbar.LengthLong).Show();
                        return;
                    }
                    if (FilesList.Count > 2)
                    {
                        Snackbar.Make(view, "str_file_count".Translate(), Snackbar.LengthLong).Show();
                        return;
                    }
                    tvFiles.Text += Path.GetFileName(fileName) + "\r\n";
                    FilesList.Add(fileName);
                }
                catch (Exception ex)
                {
                    System.Console.WriteLine("Exception choosing file: " + ex.ToString());
                }
            };

            var tvPhoto = view.FindViewById<TextView>(Resource.Id.FBtvPhoto);

            tvPhoto.Click += async (s, e) =>
            {
                try
                {
                    await CrossMedia.Current.Initialize();

                    if (!CrossMedia.Current.IsPickPhotoSupported)
                    {
                        Snackbar.Make(MainActivity._activity.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar),
    ":( No camera available.", Snackbar.LengthLong).Show();
                        return;
                    }

                    var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions()); ;
                    if (file == null)
                        return;

                    string fileName = file.Path;


                    if (FilesList.Contains(fileName))
                    {
                        Snackbar.Make(view, "str_file_exists".Translate(), Snackbar.LengthLong).Show();
                        return;
                    }
                    if (FilesList.Count > 2)
                    {
                        Snackbar.Make(view, "str_file_count".Translate(), Snackbar.LengthLong).Show();
                        return;
                    }
                    tvFiles.Text += Path.GetFileName(fileName) + "\r\n";
                    FilesList.Add(fileName);
                }
                catch (Exception ex)
                {
                    System.Console.WriteLine("Exception choosing file: " + ex.ToString());
                }
            };
            //  SEND MESSAGE
            var btnSend = view.FindViewById<Button>(Resource.Id.FBbtnSend);
            btnSend.Click += async (s, e) =>
            {
                if (Location == "")
                {
                    Snackbar.Make(MainActivity._activity.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar),
                    "str_locat".Translate(), Snackbar.LengthLong).Show();
                    return;
                }

                if (etName.Text == string.Empty)
                {
                    EdittextSetError(Context, etName, "str_require".Translate());
                    return;
                }
                EdittextSetError(etName, false);

                if (etEmail.Text == string.Empty)
                {
                    EdittextSetError(Context, etEmail, "str_require".Translate());
                    return;
                }
                EdittextSetError(etEmail, false);

                if (etPhone.Text == string.Empty)
                {
                    EdittextSetError(Context, etPhone, "str_require".Translate());
                    return;
                }
                EdittextSetError(etPhone, false);

                if (etMessage.Text == string.Empty)
                {
                    EdittextSetError(Context, etMessage, "str_require".Translate());
                    return;
                }
                EdittextSetError(etMessage, false);

                var flip = new Flip();
                flip.Show();

                var logic = new Logic();

                List<KeyValuePair<String, String>> pair = new List<KeyValuePair<string, string>>
                {
                     new KeyValuePair<string, string>("location",Location),
                     new KeyValuePair<string, string>("full_name",etName.Text),
                     new KeyValuePair<string, string>("mail",etMessage.Text),
                     new KeyValuePair<string, string>("phone",etPhone.Text),
                     new KeyValuePair<string, string>("text",etMessage.Text),
                };

                var res = await logic.FeedBack(pair, FilesList);
                flip.Dismis();
                if (res == null)
                {
                    Snackbar.Make(MainActivity._activity.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar),
                        "str_notsend".Translate(), Snackbar.LengthLong).Show();
                    return;
                }

                if (res.Result == true)
                {
                    Snackbar.Make(MainActivity._activity.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar),
                          "str_send_ok".Translate(), Snackbar.LengthLong).Show();

                }
                else
                {
                    Snackbar.Make(MainActivity._activity.FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar),
                       "str_notsend".Translate(), Snackbar.LengthLong).Show();
                }
                    



            };
            return view;
        }

        public void OnMapReady(GoogleMap googleMap)
        {
            this.GMap = googleMap;

            var latlng = new LatLng(43.25654, 76.92848);
            CameraUpdate camera = CameraUpdateFactory.NewLatLngZoom(latlng, 10);
            GMap.AnimateCamera(camera);

            GMap.MapClick += (object sender, GoogleMap.MapClickEventArgs e) =>
            {

                googleMap.Clear();

                using (var markerOption = new MarkerOptions())
                {
                    markerOption.SetPosition(e.Point);
                    var marker = googleMap.AddMarker(markerOption);
                    Coordinate = e.Point;
                    Location = $"{e.Point.Latitude},{e.Point.Longitude}";
                }
            };
        }

        public override void OnSaveInstanceState(Bundle outState)
        {
            base.OnSaveInstanceState(outState);
        }

        // SET EDITTEXT ERROR
        public void EdittextSetError(EditText et, bool show)
        {
            if (!show)
            {
                et.SetCompoundDrawables(null, null, null, null);
            }
        }

        // SET EDITTEXT ERROR
        public void EdittextSetError(Context context, EditText et, string message)
        {
            Drawable img;
            if (Build.VERSION.SdkInt < BuildVersionCodes.LollipopMr1)
                img = context.Resources.GetDrawable(Resource.Drawable.ic_error);
            else
                img = context.GetDrawable(Resource.Drawable.ic_error);

            img.SetBounds(0, 0, 30, 30);
            et.SetCompoundDrawables(null, null, img, null);
            et.SetError(message, null);
        }

        public override async void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Show();
            ((MainActivity)Activity).SupportActionBar.Title = "str_feedback".Translate();
        }
    }
}