using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using Android.Widget;
using Client.Droid.Helpers;
using Client.Models.Json;
using I18NPortable;
using System.Collections.Generic;

namespace Client.Droid.Fragments
{
    public class FragmentConfess : Fragment
    {
        LinearLayout viewHris, viewNew;

        List<Confess> confess { get; set; }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public static FragmentConfess NewInstance()
        {
            var frag = new FragmentConfess { Arguments = new Bundle() };
            return frag;
        }

        private void Translate(View view)
        {
            view.FindViewById<TextView>(Resource.Id.ctvHris).Text = "str_hrist".Translate();
            view.FindViewById<TextView>(Resource.Id.ctvIslam).Text = "str_islam".Translate();
            view.FindViewById<TextView>(Resource.Id.ctvBud).Text = "str_b".Translate();
            view.FindViewById<TextView>(Resource.Id.ctvIud).Text = "str_iud".Translate();
            view.FindViewById<TextView>(Resource.Id.ctvNew).Text = "str_newr".Translate();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_confes, container, false);

            viewHris = view.FindViewById<LinearLayout>(Resource.Id.cviewHris);
            viewNew = view.FindViewById<LinearLayout>(Resource.Id.cviewNew);

            var hris = view.FindViewById<TextView>(Resource.Id.ctvHris);
            hris.Click += (s, e) =>
             {
                 Go(confess[1]);
             };

            var islam = view.FindViewById<TextView>(Resource.Id.ctvIslam);
            islam.Click += (s, e) =>
            {
                Go(confess[0]);
            };
            var bud = view.FindViewById<TextView>(Resource.Id.ctvBud);
            bud.Click += (s, e) =>
            {
                Go(confess[2]);
            };
            var iudaizm = view.FindViewById<TextView>(Resource.Id.ctvIud);
            iudaizm.Click += (s, e) =>
            {
                Go(confess[3]);
            };
            var newRelig = view.FindViewById<TextView>(Resource.Id.ctvNew);
            newRelig.Click += (s, e) =>
            {
                Go(confess[4]);
            };

            Translate(view);
            return view;
        }

        void Go(Confess data)
        {
            ((MainActivity)Activity).Go(FragmentConfessIt.NewInstance(data));
        }

        public async override void OnResume()
        {
            base.OnResume();
            ((MainActivity)Activity).SupportActionBar.Title = "str_cofesss".Translate();
            ((MainActivity)Activity).SupportActionBar.Show();

            var flip = new Flip();
            flip.Show();

            var logic = new Logic();
            confess = await logic.GetConfessions(Settings.Lang);
            var subconfess = await logic.GetSubConfessions(Settings.Lang);
            if (subconfess == null) return;
            flip.Dismis();

            var layParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MatchParent,
                LinearLayout.LayoutParams.WrapContent, 0);
            layParams.SetMargins(0, 10, 0, 10);


            foreach (var item in subconfess)
            {
                if (item.Protest == 0)
                {
                    var btn = new TextView(MainActivity._activity);
                    btn.LayoutParameters = layParams;
                    btn.Text = item.Name;
                    btn.Click += (s, e) =>
                    {
                        Go(new Confess { Image = item.Image, Name = item.Name, Short_text = item.Short_text, Full_text = item.Full_text });
                    };
                    viewHris.AddView(btn);

                }

                if (item.Protest == 1)
                {
                    var btn = new TextView(MainActivity._activity);
                    btn.LayoutParameters = layParams;
                    btn.Text = item.Name;
                    btn.Click += (s, e) =>
                    {
                        Go(new Confess { Image = item.Image, Name = item.Name, Short_text = item.Short_text, Full_text = item.Full_text });
                    };
                    viewNew.AddView(btn);
                }
            }
        }

    }
}