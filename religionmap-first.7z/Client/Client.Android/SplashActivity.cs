﻿using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Content.Res;
using Android.OS;
using Java.Util;

namespace Client.Droid
{
    [Activity(Theme = "@style/Theme.Splash", Label = "@string/app_name",
             MainLauncher = true, //Set it as boot activity
             NoHistory = true)] //Doesn't place it in back stack
    public class SplashActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            RequestedOrientation = ScreenOrientation.Portrait;
            //var lang = Locale.Default.Country;
            if (Settings.FirstStart)
                this.StartActivity(typeof(ActivityWelcome));
            else
            {
                this.StartActivity(typeof(MainActivity));
                //ChangeLang(Settings.Lang);
            }
            //this.StartActivity(typeof(MainActivity));
        }

        //private void ChangeLang(string lang)
        //{
        //    var locale = new Locale(lang);
        //    Locale.Default = locale;
        //    var config = new Configuration();
        //    config.Locale = locale;
        //    this.Resources.UpdateConfiguration(config, null);
        //    Intent intent = new Intent(this, typeof(MainActivity));
        //    intent.AddFlags(ActivityFlags.NoAnimation);
        //    Finish();
        //    StartActivity(intent);
        //}
    }
}