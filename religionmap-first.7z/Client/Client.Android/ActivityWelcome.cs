﻿using Android.App;
using Android.Content.PM;
using Android.OS;
using Android.Support.V7.App;
using Client.Droid.Fragments;
using I18NPortable;
using Plugin.Permissions;

namespace Client.Droid
{
    [Activity(Label = "ActivityWelcome")]
    public class ActivityWelcome : AppCompatActivity
    {
        public static ActivityWelcome _activity;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.welcome);
            RequestedOrientation = ScreenOrientation.Portrait;

            var app = new App();
            I18N.Current.Locale = Settings.Lang;
            Plugin.CurrentActivity.CrossCurrentActivity.Current.Init(this, savedInstanceState);
            //var ss = CrossPermissions.Current.RequestPermissionsAsync(Plugin.Permissions.Abstractions.Permission.Location);

            _activity = this;
            var fragment = new FragmentWelcome();

            Go(fragment);


        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            PermissionsImplementation.Current.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        // OPEN PAGE
        public void Go(Android.Support.V4.App.Fragment fragment)
        {
            SupportFragmentManager.BeginTransaction()
                .Replace(Resource.Id.fragment_welcome, fragment)
                .Commit();
        }
    }
}