﻿using Foundation;
using System;
using UIKit;

namespace relig_ios
{
    public partial class ContentController : UIViewController
    {
        public ContentController (IntPtr handle) : base (handle)
        {
        }
    }
}