﻿using Foundation;
using System;
using UIKit;

namespace relig_ios
{
    partial class IntroController : BaseController
    {
        public IntroController(IntPtr handle) : base(handle)
        {
        }
    }
}